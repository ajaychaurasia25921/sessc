module.exports = function (api) {
    return {
      plugins: ['macros'],
    }
  }
  