import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.scss';
import InterceptorService from './services/interceptor.service';
import Footer from './shared/footer/footer';
import Header from './shared/header/header';
import Dashboard from './pages/dashboard/dashboard';
import { Ledger } from './pages/Ledger/ledger';
import { Report } from './pages/report/report';

function App() {
  const [isHeader, setIsHeader] = React.useState(false)
  const [isFooter, setIsFooter] = React.useState(false)
  const interceptorService = new InterceptorService("app");
 
  React.useEffect(() => {
    interceptorService.myResponse()
  }, [interceptorService])

  return (
    <>
      {isHeader ? <Header /> : <></>}
      
        <Routes>
        <Route path="/" element={<Dashboard headerFunc={setIsHeader} footerFunc={setIsFooter} />} />
        <Route path="/ledger" element={<Ledger headerFunc={setIsHeader} footerFunc={setIsFooter} />} />
        <Route path="/report" element={<Report headerFunc={setIsHeader} footerFunc={setIsFooter} />} />
        </Routes>
    
      {isFooter ? <Footer /> : <></>}
    </>
  );
}

export default App;
