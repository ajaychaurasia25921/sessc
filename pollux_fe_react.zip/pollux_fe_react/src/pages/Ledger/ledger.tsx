import { DataGrid, gridClasses, GridColDef, GridToolbar, GridToolbarContainer, GridToolbarExport, GridToolbarDensitySelector } from '@mui/x-data-grid';
import dateFormat from 'dateformat';
import { alpha, styled } from '@mui/material/styles';
import { useFormik } from 'formik';
import React from 'react'
import Icon from 'react-icons-kit';
import MainService from '../../services/main-service';
import "./ledger.scss";
import { Button, Modal } from 'react-bootstrap';
import {PrintableLedger} from './printable-ledger';


const ODD_OPACITY = 0.2;

type ledgerDetail = {
    memberId: number,
    firstName: string,
    lastName: string,
    staffType: string,
    personalNumber: string,
    ticketNumber: string,
    post: string,
    section: string,
    accountId: string,
    accountType: string,
    transactions: {
        content: Array<transaction>,
        pageable: {
            sort: {
                empty: boolean,
                sorted: boolean,
                unsorted: boolean
            },
            offset: number,
            pageNumber: number,
            pageSize: number,
            paged: boolean,
            unpaged: boolean
        },
        last: boolean,
        totalElements: number,
        totalPages: number,
        size: number,
        number: number,
        sort: {
            empty: boolean,
            sorted: boolean,
            unsorted: boolean
        },
        first: boolean,
        numberOfElements: number,
        empty: boolean
    },
    memberPhoto: string,
    memberPhotoExt: string,
    signature: string,
    signatureExt: string
}

type transaction = {
    transactionId: string,
    amount: number,
    balance: number,
    mode: string,
    indicator: string,
    notes: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string,
    accountId: string
}

const columns: GridColDef[] = [
    { field: 'id', headerName: 'Txn Id', width: 110 },
    { field: 'accountId', headerName: 'Account Id', width: 150 },
    { field: 'amount', headerName: 'Amount', width: 150 },
    { field: 'balance', headerName: 'Balance', width: 150 },
    { field: 'mode', headerName: 'Mode', width: 150 },
    { field: 'indicator', headerName: 'DR | CR.', width: 150 },
    { field: 'notes', headerName: 'Notes', width: 150 },
    { field: 'createdOn', headerName: 'Created On', width: 150 },
    { field: 'createdBy', headerName: 'Created By', width: 150 },

];

type userType = {
    accountId: string,
    fromDate: Date,
    toDate: Date
}

type Rows = { id: string, amount: number, balance: number, mode: string, indicator: string, notes: string, createdOn: string, createdBy: string, accountId: string }

let date = new Date();
let accountIdPlaceholder = "" as const;
let dataObj: ledgerDetail;
export const Ledger = (props: any) => {
    var [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [reload, setReload] = React.useState(false)
    var [hasPrevious, setHasPrevious] = React.useState(false);
    const [rowsData, setRows] = React.useState(Array);
    var [showPDFBtn, setShowPDFBtn] = React.useState(false);
    var [lastUser, setLastUser] = React.useState<userType>({ accountId: accountIdPlaceholder, fromDate: date, toDate: date })
    const ledgerDetails = useFormik({
        initialValues: {
            accountId: "",
            fromDate: "",
            toDate: ""
        },
        onSubmit: (values: any, { resetForm }) => {
            getRows(pageSize, recordsSize, values.accountId, values.fromDate, values.toDate)
            // resetForm();
        }
    });
    var [enablePrintPreview, setEnablePrintPreview] = React.useState(false);

    React.useEffect(() => {
        props.headerFunc(true);
        props.footerFunc(true);
        setHasNext(false);
        setHasPrevious(false);
    }, []);

    function CustomToolbar() {
        var currentdate = new Date();
        var filetime = currentdate.getDate() + "-"
            + (currentdate.getMonth() + 1) + "-"
            + currentdate.getFullYear() + "_"
            + currentdate.getHours() + ":"
            + currentdate.getMinutes();
        console.log(filetime)
        return (
            <GridToolbarContainer>
                <GridToolbarExport
                    csvOptions={{
                        fileName: lastUser.accountId + "_Ledger_" + filetime
                    }}
                    printOptions={{
                        disableToolbarButton: true
                    }}
                />
                <GridToolbarDensitySelector />
            </GridToolbarContainer>
        );
    }

    const StripedDataGrid = styled(DataGrid)(({ theme }) => ({
        [`& .${gridClasses.row}.even`]: {
          backgroundColor: theme.palette.grey[200],
          '&:hover, &.Mui-hovered': {
            backgroundColor: alpha(theme.palette.primary.main, ODD_OPACITY),
            '@media (hover: none)': {
              backgroundColor: 'transparent',
            },
          },
          '&.Mui-selected': {
            backgroundColor: alpha(
              theme.palette.primary.main,
              ODD_OPACITY + theme.palette.action.selectedOpacity,
            ),
            '&:hover, &.Mui-hovered': {
              backgroundColor: alpha(
                theme.palette.primary.main,
                ODD_OPACITY +
                  theme.palette.action.selectedOpacity +
                  theme.palette.action.hoverOpacity,
              ),
              // Reset on touch devices, it doesn't add specificity
              '@media (hover: none)': {
                backgroundColor: alpha(
                  theme.palette.primary.main,
                  ODD_OPACITY + theme.palette.action.selectedOpacity,
                ),
              },
            },
          },
        },
      }));

    const mainService = new MainService("");
    async function getRows(pageSize: number, recordsSize: number, id: string, fromDate: Date, toDate: Date) {
        // console.log(pageSize, recordsSize, id, fromDate, toDate);
        // console.log( Date.now())

        setLastUser({ accountId: id, fromDate: fromDate, toDate: toDate })
        let abc: any[] = [];
        let url = `ledger/filter?page=${pageSize}&size=${recordsSize}`;
        let data = {
            "accountId": `${id}`,
            "fromDate": `${fromDate}`,
            "toDate": `${toDate}`
        }
        try {
            let response = await mainService.postRequest(url, data, null);
            console.log(response.data);
            dataObj = (response.data as ledgerDetail);

            if (dataObj.transactions.content.length != 0) {
                setShowPDFBtn(true);
                dataObj.transactions.content.forEach(element => {
                    let finalData: Rows = {
                        id: element.transactionId,
                        amount: element.amount,
                        balance: element.balance,
                        mode: element.mode,
                        indicator: element.indicator,
                        notes: element.notes,
                        createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                        createdBy: element.createdBy,
                        accountId: element.accountId
                    }
                    abc.push(finalData);
                });
            }
            setRows(abc);
            if (!dataObj.transactions.empty && dataObj.transactions.totalPages > 0) {
                setHasNext(true);
            } else {
                setHasNext(false);
            }
            setIsLoading(false);
            setReload(!reload);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    function memberDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        getRows(pageSize + 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function memberDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        getRows(pageSize - 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function PrintPreview(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Print Preview
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    <PrintableLedger data={dataObj}></PrintableLedger>
                </Modal.Body>
                <Modal.Footer className='d-block'>
                    <Button variant="outline-secondary" onClick={() => { setEnablePrintPreview(!enablePrintPreview) }}>Cancel</Button>
                    {/* <Button variant="danger" onClick={() => { deactivateRecordOnConfirm(RDDeactivateRecordId); setDeleteModal(!deleteModal); getRows(10, 0); }}>Delete</Button> */}
                </Modal.Footer>
            </Modal>
        );
    }

    function makePDF() {
        setEnablePrintPreview(true);
    }

    return (
        <div className='ledger'>
            <div className='main-view'>
            {
                <PrintPreview show={enablePrintPreview} onHide={() => setEnablePrintPreview(false)} />
            }
                {/* <PrintableLedger data={}></PrintableLedger> */}
                <div className="row heading-section">
                    <div className="col-5">
                        <h3 className="heading m-0 lh-base">Ledger</h3>
                    </div>
                    <div className="col-7">
                        <div className='d-flex flex-row-reverse'>
                            <form className="row g-3" onSubmit={ledgerDetails.handleSubmit}>
                                <div className="col-auto mt-1">
                                    <label htmlFor="staticEmail2" className="font-12">Account Id</label>
                                    <input
                                        type="text"
                                        className="form-control height-30"
                                        placeholder='Ex: tf_1001'
                                        id="accountId"
                                        name="accountId"
                                        onChange={ledgerDetails.handleChange}
                                        value={ledgerDetails.values.accountId}
                                        required={true}
                                    />
                                </div>
                                <div className="col-auto mt-1">
                                    <label htmlFor="staticEmail2" className="font-12">Start Date</label>
                                    <input
                                        type="Date"
                                        id="fromDate"
                                        name="fromDate"
                                        className="form-control height-30"
                                        onChange={ledgerDetails.handleChange}
                                        value={ledgerDetails.values.fromDate}

                                    />
                                </div>
                                <div className="col-auto mt-1">
                                    <label htmlFor="inputPassword2" className="font-12">End Date</label>
                                    <input
                                        type="Date"
                                        id="toDate"
                                        name="toDate"
                                        className="form-control height-30"
                                        onChange={ledgerDetails.handleChange}
                                        value={ledgerDetails.values.toDate}

                                    />
                                </div>
                                <div className="col-auto">
                                    <button type="submit" className="btn btn-outline-light lh-1 height-30">Get Data</button>
                                </div>
                                <div className="col-auto">
                                     { showPDFBtn ? <button type="submit" className="btn btn-outline-light lh-1 height-30" onClick={() =>makePDF()} >PDF</button> : <></>}
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <hr className='border border-light divider' />
                <div id='printme'>
                <div className="row">
                    <div className="col-4">
                        <h4 className='text-white'>Member Details</h4>
                        <div className="text-white bg-white table-view p-1 " id='tableView'>
                            {
                                dataObj ?
                                    <div className="details-list">
                                        <table className="table">
                                            <tbody>
                                                <tr>
                                                    <th>First Name</th>
                                                    <td>{dataObj.firstName}</td>
                                                    <th>Last Name</th>
                                                    <td>{dataObj.lastName}</td>
                                                </tr>
                                                <tr>
                                                    <th>Member Id</th>
                                                    <td>{dataObj.memberId}</td>
                                                    <th>Staff Type</th>
                                                    <td>{dataObj.staffType}</td>
                                                </tr>
                                                <tr>
                                                    <th>Personal Number</th>
                                                    <td>{dataObj.personalNumber}</td>
                                                    <th>Ticket Number</th>
                                                    <td>{dataObj.ticketNumber}</td>
                                                </tr>
                                                <tr>
                                                    <th>Post</th>
                                                    <td>{dataObj.post}</td>
                                                    <th>Section</th>
                                                    <td>{dataObj.section}</td>
                                                </tr>
                                                <tr>
                                                    <th>AccountId</th>
                                                    <td>{dataObj.accountId}</td>
                                                    <th>Account Title</th>
                                                    <td>{dataObj.accountType}</td>
                                                </tr>
                                                <tr>
                                                    <th>Member Photo</th>
                                                    <td><img className='uploaded-images rounded-circle' src={`data:image/png;image/jpg;image/jpeg;base64,${dataObj.memberPhoto}`} alt="" srcSet="" /></td>
                                                    <th>Signature</th>
                                                    <td><img className='uploaded-images' src={`data:image/png;image/jpg;image/jpeg;base64,${dataObj.signature}`} alt="" srcSet="" /></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>

                                    : <div className='text-black-50 text-center'>
                                        <img className='img-fluid d-block text-center w-25 m-auto' src="https://png.pngtree.com/png-vector/20190810/ourlarge/pngtree-find-search-view-glass-flat-color-icon-vector-icon-png-image_1654989.jpg" alt="" srcSet="" />
                                        <h4>Please User Filter for Seraching Details</h4>
                                    </div>
                            }

                        </div>
                    </div>
                    <div className="col-8">
                        <div className="row">
                            <div className="col-4"><h4 className='text-white'>Transactions</h4></div>
                            <div className="col-8">
                                <div className='d-flex flex-row-reverse mb-2'>
                                    <div className="btn-group px-2 height-30 lh-1" role="group" aria-label="Basic outlined example">
                                        <button type="button" className="btn btn-outline-light lh-1" disabled={!hasPrevious} onClick={() => memberDataPrevious()}>Previous</button>
                                        <button type="button" disabled={true} className="btn btn-outline-light px-1 lh-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
                                        <button type="button" className="btn btn-outline-light lh-1" disabled={!hasNext} onClick={() => memberDataNext()}>Next</button>
                                    </div>
                                    <select
                                        className="form-select records-select height-30"
                                        onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(0, Number(e.target.value), lastUser.accountId, lastUser.fromDate, lastUser.toDate); }}
                                        value={recordsSize}
                                        aria-label="Default select example"
                                        disabled={!(dataObj)}
                                    >
                                        <option value={5}>5</option>
                                        <option value={10}>10</option>
                                        <option value={25}>25</option>
                                        <option value={50}>50</option>
                                    </select>

                                </div>
                            </div>
                        </div>


                        <div className="text-white bg-white table-view" id='tableView'>

                            {
                                dataObj ?

                                    <StripedDataGrid
                                        className=''
                                        rows={rowsData as any}
                                        columns={columns}
                                        pageSize={recordsSize}
                                        getRowId={(row) => row.id}
                                        hideFooter={true}
                                        components={{ Toolbar: CustomToolbar }}
                                        componentsProps={{ toolbar: { printOptions: { disableToolbarButton: true } } }}
                                        getRowClassName={(params) =>
                                            params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
                                          }
                                    />


                                    : <div className='text-black-50 text-center'>
                                        <img className='img-fluid d-block text-center w-25 m-auto' src="https://png.pngtree.com/png-vector/20190810/ourlarge/pngtree-find-search-view-glass-flat-color-icon-vector-icon-png-image_1654989.jpg" alt="" srcSet="" />
                                        <h4>Please User Filter for Seraching Details</h4>
                                    </div>
                            }

                        </div>
                    </div>
                </div></div>
            </div>
            {
                isLoading ? <div>
                    <div className='loading-overlay'>
                        <div className='loader'>
                            <img src="/assets/rolling.svg" alt="" srcSet="" />
                        </div>
                    </div>
                </div> : <></>
            }
        </div>
    )
}
