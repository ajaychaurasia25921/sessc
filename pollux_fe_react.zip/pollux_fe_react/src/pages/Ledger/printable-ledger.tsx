import * as React from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../services/main-service';
import dateFormat from "dateformat";
import ReactToPrint from 'react-to-print';
import "./ledger.scss";


export const PrintableLedger = (props: any) => {

    var [fullData, setFullData] = React.useState();
    var [userData, setUserData] = React.useState();
    var [txnData, setTxnData] = React.useState(Array<any>());

    var componentRef: any;

    var date = new Date();

    React.useEffect(() => {
        if (props.data) {
            setFullData(props.data);
            setTxnData(props.data.transactions.content);
            console.log(props.data)
            // let obj = {
            //     account
            // }
        }
    }, [props.data]);

    return (
        <div>
            <div>
                <ReactToPrint
                    content={() => componentRef}
                    trigger={() => <button className="btn btn-primary align-right">Print to PDF!</button>}
                />
            </div>
            <div className='stylePrintableArea'>
                <div ref={(response) => (componentRef = response)}>
                    <div className='headerPrintPage'>
                        <img className="factoryLogo" src="/assets/picture11.png" />
                        <div className='header-block-print-ledger'>
                        <span className="center-heading">SALARY EARNER'S CREDIT CO-OPERATIVE SOCIETY LIMITED.</span><br/>
                        <span className="center-heading">ORDNANCE FACTORY, MURADNAGAR, DISTT. GHAZIABAD.</span><br/>
                        <span className="center-heading">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<u>MEMBER</u> <u>LEDGER</u></span>
                        </div>
                    </div>
                    <br /><br />
                    <div className='parent-ledger-print bgImg'>
                        <div className='child-ledger-print'>
                            <table className="tableledger">
                                <tr>
                                    <td><b>Name: </b></td>
                                    <td>
                                        <b>{fullData ? fullData['firstName'] + ' ' + fullData['lastName'] : ''}</b>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Member ID: </td>
                                    <td>
                                        {fullData ? fullData['memberId'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Account ID: </td>
                                    <td>
                                        {fullData ? fullData['accountId'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Account Type: </td>
                                    <td>
                                        {fullData ? fullData['accountType'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Guardian: </td>
                                    <td>
                                        {fullData ? fullData['fatherOrHusbandName'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Personal Number: </td>
                                    <td>
                                        {fullData ? fullData['personalNumber'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Post: </td>
                                    <td>
                                        {fullData ? fullData['post'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Section: </td>
                                    <td>
                                        {fullData ? fullData['section'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Staff Type: </td>
                                    <td>
                                        {fullData ? fullData['staffType'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Ticket Number: </td>
                                    <td>
                                        {fullData ? fullData['ticketNumber'] : ''}
                                    </td>
                                </tr>
                                <tr>
                                    <td>D.O.B: </td>
                                    <td>
                                        {fullData ? dateFormat(fullData['dateOfBirth'], "dd-mmm-yyyy"): ''}
                                    </td>
                                </tr>
                                <tr>    
                                    <td>Opening Balance: </td>
                                    <td>    
                                        {txnData[0] ?  (txnData[0]['indicator'] === 'Credit' ? txnData[0]['balance'] - txnData[0]['amount'] : txnData[0]['balance'] + txnData[0]['amount']) : ''}
                                    </td>
                                </tr>
                                <tr>    
                                    <td>Closing Balance: </td>
                                    <td>    
                                        {txnData[txnData.length-1] ? txnData[txnData.length-1]['balance']: ''}
                                    </td>
                                </tr>
                            </table>
                        </div>
                            <div className='child-ledger-print'>
                                <span className='date-print'>Date: <b>{date ? date.getDate()+'-'+date.getMonth()+'-'+date.getFullYear()+' '+date.getHours()+':'+date.getMinutes(): ''}</b></span>
                                <img className='uploaded-images' src={`data:image/png;image/jpg;image/jpeg;base64,${fullData ? fullData['memberPhoto'] : ''}`} alt="" srcSet="" /><br/>
                                <img className='uploaded-images' src={`data:image/png;image/jpg;image/jpeg;base64,${fullData ? fullData['signature'] : ''}`} alt="" srcSet="" />
                            </div>
                    </div>
                    <br />

                    {/* <span> Transactions</span><br/> */}
                    <table className="txn-table">
                        <tr>
                            <th>Txn Id</th>
                            <th>Amount</th>
                            <th>Balance</th>
                            <th>Mode</th>
                            <th>DR|CR</th>
                            <th>Notes</th>
                            <th>Created On</th>
                            <th>Created By</th>
                        </tr>

                        {
                            txnData ? txnData.map(e => <tr>
                                <td>{e.transactionId}</td>
                                <td>{e.amount}</td>
                                <td>{e.balance}</td>
                                <td>{e.mode}</td>
                                <td>{e.indicator}</td>
                                <td>{e.notes}</td>
                                <td>{dateFormat(e.createdOn, "mmm d, yyyy HH:MM")}</td>
                                <td>{e.createdBy}</td>
                            </tr>) : ''
                        }
                    </table>
                </div>
            </div>
        </div>
    );
}