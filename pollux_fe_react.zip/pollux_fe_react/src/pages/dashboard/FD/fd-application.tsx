import React, { useState } from "react";
import "./fd.scss";
import MainService from "../../../services/main-service";
import dateFormat from "dateformat";
import stateArr from "../../../data/state.json";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  solid,
  regular,
  brands,
} from "@fortawesome/fontawesome-svg-core/import.macro"; // <-- import styles to be used
import relationArr from "../../../data/relation.json";

const mainService = new MainService("");

export const FixedDepositApplication = () => {
  var [showFDAlert, setShowFDAlert] = React.useState(false);
  var [alertMessage, setAlertMessage] = React.useState("");
  var [showFDSuccessDialog, setShowFDSuccessDialog] = React.useState(false);
  var [FDApplicationResponse, setFDApplicationResponse] = React.useState();
  var [commonFDMemberId, setFDCommonMemberId] = React.useState("");
  var [memberName, setFDMemberName] = React.useState("");
  var [ticketNumber, setFDTicketNumber] = React.useState("");
  var [section, setFDSection] = React.useState("");
  var [post, setFDPost] = React.useState("");
  var [personalNumber, setFDPersonalNumber] = React.useState("");
  var [contactNumber, setFDContactNumber] = React.useState("");
  var [dob, setFDDOB] = React.useState("");
  var [mailingAddressLine1, setMailingAddressLine1] = React.useState("");
  var [mailingCity, setMailingCity] = React.useState("");
  var [mailingState, setMailingState] = React.useState("");
  var [mailingDistrict, setMailingDistrict] = React.useState("");
  var [mailingPinCode, setMailingPinCode] = React.useState("");
  var [mailingContact, setMailingContact] = React.useState("");
  var [permanentAddressLine1, setPermanentAddressLine1] = React.useState("");
  var [permanentCity, setPermanentCity] = React.useState("");
  var [permanentState, setPermanentState] = React.useState("");
  var [permanentDistrict, setPermanentDistrict] = React.useState("");
  var [permanentPinCode, setPermanentPinCode] = React.useState("");
  var [permanentContact, setPermanentContact] = React.useState("");
  var [FDAmount, setFDAmount] = React.useState("");
  var [FDmemberPhoto, setFDMemberPhoto] = React.useState("");
  var [FDmemberSignature, setFDMemberSignature] = React.useState("");
  var [memberData, setMemberData] = React.useState();
  var [disableSaveButtonForFD, setDisableSaveButtonForFD] =
    React.useState(true);
  var [existingNominees, setExistingNominees] = React.useState(Array<any>());
  var [nomineeName, setNomineeName] = React.useState("");
  var [nomineeRelation, setNomineeRelation] = React.useState("");
  var [FDYears, setFDYears] = React.useState("");
  var [FDMonths, setFDMonths] = React.useState("");
  var [FDType, setFDType] = React.useState("");
  var [createdOn, setCreatedOn] = React.useState("");
  var [nomineeAddress, setNomineeAddress] = React.useState("");

  async function getDetailsFromMemeberIDForFD() {
    try {
      let url = `member/${commonFDMemberId}`;
      let data = await mainService.getRequest(url, null, null);
      assignFormValues(data);
    } catch (e: any) {
      console.log(e);
    }
  }

  const resetFDFormSubmition = () => {
    setFDCommonMemberId("");
    setFDMemberName("");
    setFDTicketNumber("");
    setFDSection("");
    setFDPost("");
    setFDPersonalNumber("");
    setFDContactNumber("");
    setFDDOB("");
    setMailingAddressLine1("");
    setMailingCity("");
    setMailingState("");
    setMailingDistrict("");
    setMailingPinCode("");
    setMailingContact("");
    setPermanentAddressLine1("");
    setPermanentCity("");
    setPermanentState("");
    setPermanentDistrict("");
    setPermanentPinCode("");
    setPermanentContact("");
    setFDAmount("");
  };

  async function checkFDFormSubmition() {
    let newNomineesArr = [];
    for (let s of existingNominees) {
      newNomineesArr.push({
        name: s.name,
        relation: s.relation,
        address: s.address,
      });
    }

    let userInput = {
      fdAmount: parseFloat(FDAmount),
      tenure: FDMonths,
      tenureType: FDType,
      createdOn: createdOn,
      memberId: memberData ? memberData["memberId"] + "" : "",
      nomination: newNomineesArr,
    };
    let url = "fd/application";
    let response = await mainService.postRequest(url, userInput, null);
    console.log(response);
    setFDApplicationResponse(response.data);
    if (response.status == 200) {
      setShowFDSuccessDialog(true);
      let obj: any = "";
      setMemberData(obj);
    }
    resetFDFormSubmition();
  }

  const assignFormValues = (data: any) => {
    data = data.data;
    setMemberData(data);
    setFDMemberName(
      data.personalDetail.firstName + " " + data.personalDetail.lastName
    );
    setFDTicketNumber(data.officialDetail.ticketNumber);
    setFDPost(data.officialDetail.post);
    setFDSection(data.officialDetail.section);
    let newD = dateFormat(data.personalDetail.dateOfBirth, "yyyy-mm-dd");
    setFDDOB(newD);
    setFDPersonalNumber(data.personalDetail.personalDetailId + "");
    setFDContactNumber(data.personalDetail.contactNumber);
    setFDMemberPhoto(data.memberPhoto);
    setFDMemberSignature(data.memberSignature);

    //address
    setMailingAddressLine1(data.memberAddress.mailing.addressLine1);
    setMailingCity(data.memberAddress.mailing.postOrCity);
    setMailingState(data.memberAddress.mailing.state);
    setMailingDistrict(data.memberAddress.mailing.district);
    setMailingPinCode(data.memberAddress.mailing.pinCode);
    setMailingContact(data.memberAddress.mailing.contact);
    setPermanentAddressLine1(data.memberAddress.permanent.addressLine1);
    setPermanentCity(data.memberAddress.permanent.postOrCity);
    setPermanentState(data.memberAddress.permanent.state);
    setPermanentDistrict(data.memberAddress.permanent.district);
    setPermanentPinCode(data.memberAddress.permanent.pinCode);
    setPermanentContact(data.memberAddress.permanent.contact);
    checkDisabilityOfSaveBtn();
  };

  function checkDisabilityOfSaveBtn() {
    if (FDAmount && FDAmount != "") {
      setDisableSaveButtonForFD(false);
    } else {
      setDisableSaveButtonForFD(true);
    }
  }
  const addNominee = () => {
    let obj = {
      name: nomineeName,
      relation: nomineeRelation,
      address: nomineeAddress,
    };
    // for (let s of existingNominees) {
    //     if (s.memberId == obj.memberId) {
    //         let emptyarr: never[] = [];
    //         setSearchMemberArr([...emptyarr]);
    //         setMemberIdSearch('');
    //         setAlertMessage("Duplicate Guarantors can't be added.");
    //         setShowAlert(true);
    //         setTimeout(() => {
    //             setShowAlert(false);
    //         }, 5000);
    //         return;
    //     }
    // }
    // if (existingGuaranterArr.length == 10) {
    //     let emptyarr: never[] = [];
    //     setSearchMemberArr([...emptyarr]);
    //     setMemberIdSearch('');
    //     setAlertMessage("Cannot add more than 10 Guarantors.");
    //     setShowAlert(true);
    //     setTimeout(() => {
    //         setShowAlert(false);
    //     }, 5000);
    //     return;
    //     return;
    // }
    existingNominees.push(obj);
    setExistingNominees([...existingNominees]);
    setNomineeName("");
    setNomineeRelation("");
  };

  const deleteNominee = (el: any) => {
    let index = 0;
    for (let s of existingNominees) {
      if (s.name == el.name && s.personalNumber == el.personalNumber) {
        break;
      }
      index++;
    }
    existingNominees.splice(index, 1);
    console.log(existingNominees);
    setExistingNominees([...existingNominees]);
  };

  function closeAlert() {
    setShowFDAlert(false);
  }

  const closeFDApplicationModal = () => {
    setShowFDSuccessDialog(false);
  };
  //Handlers
  const handleFDCommonMemberId = (e: any) => {
    setFDCommonMemberId(e.target.value);
  };
  const handleFDMemberName = (e: any) => {
    setFDMemberName(e.target.value);
  };
  const handleFDTicketnumber = (e: any) => {
    setFDTicketNumber(e.target.value);
  };
  const handleFDSection = (e: any) => {
    setFDSection(e.target.value);
  };
  const handleFDPost = (e: any) => {
    setFDPost(e.target.value);
  };
  const handleFDPersonalNumber = (e: any) => {
    setFDPersonalNumber(e.target.value);
  };
  const handleFDContactNumber = (e: any) => {
    setFDContactNumber(e.target.value);
  };
  const handleFDDOB = (e: any) => {
    setFDDOB(e.target.value);
  };
  const handleMailingAddressLine1 = (e: any) => {
    setMailingAddressLine1(e.target.value);
  };
  const handleMailingCity = (e: any) => {
    setMailingCity(e.target.value);
  };
  const handleMailingDistrict = (e: any) => {
    setMailingDistrict(e.target.value);
  };
  const handleMailingState = (e: any) => {
    setMailingState(e.target.value);
  };
  const handleMailingPinCode = (e: any) => {
    setMailingPinCode(e.target.value);
  };
  const handleMailingContact = (e: any) => {
    setMailingContact(e.target.value);
  };
  const handlePermanentAddressLine1 = (e: any) => {
    setPermanentAddressLine1(e.target.value);
  };
  const handlePermanentCity = (e: any) => {
    setPermanentCity(e.target.value);
  };
  const handlePermanentDistrict = (e: any) => {
    setPermanentDistrict(e.target.value);
  };
  const handlePermanentState = (e: any) => {
    setPermanentState(e.target.value);
  };
  const handlePermanentPinCode = (e: any) => {
    setPermanentPinCode(e.target.value);
  };
  const handlePermanentContact = (e: any) => {
    setPermanentContact(e.target.value);
  };
  const handleFDAmount = (e: any) => {
    setFDAmount(e.target.value);
    checkDisabilityOfSaveBtn();
  };
  const handleNomineeName = (e: any) => {
    setNomineeName(e.target.value);
  };
  const handleNomineeRelation = (e: any) => {
    setNomineeRelation(e.target.value);
  };
  const handleFDYears = (e: any) => {
    setFDYears(e.target.value);
  };
  const handleFDMonths = (e: any) => {
    setFDMonths(e.target.value);
  };
  const handleFDType = (e: any) => {
    setFDType(e.target.value);
  };
  const handleCreatedOn = (e: any) => {
    setCreatedOn(e.target.value);
  };
  const handleNomineeAddress = (e: any) => {
    setNomineeAddress(e.target.value);
  };

  return (
    <div>
      <br />
      {showFDAlert ? (
        <div className="d-flex justify-content-end my-4cphx-pagination">
          <div>
            <div
              className="alert alert-success alert-notification alert-dismissible fade show"
              role="alert"
            >
              <span>{alertMessage}</span>
              <button
                aria-label="Close"
                className="close close-position"
                type="button"
                data-dismiss="alert"
                onClick={() => closeAlert()}
              >
                &times;
              </button>
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}
      {showFDSuccessDialog ? (
        <div className="modal" id="response-modal" role="dialog">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">FD Application Saved</h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={() => closeFDApplicationModal()}
                ></button>
              </div>
              <div className="modal-body">
                {FDApplicationResponse ? (
                  <div>
                    <div>
                      <span>
                        <strong>FD Application ID: </strong>
                      </span>
                      <span>{FDApplicationResponse["applicationId"]}</span>
                    </div>
                    <div>
                      <span>
                        <strong>Application Date: </strong>
                      </span>
                      <span>
                        {dateFormat(
                          FDApplicationResponse["createdOn"],
                          "mmmm dS, yyyy, h:MM:ss TT"
                        )}
                      </span>
                    </div>
                  </div>
                ) : (
                  <></>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}
      <div id="seperate-loan-box">
        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-3"></div>
            <div className="col-lg-6">
              <div className="common-member-box">
                <div className="input-group mx-5">
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    id="commonMemberID"
                    name="commonMemberID"
                    placeholder="Member ID"
                    onChange={handleFDCommonMemberId}
                    value={commonFDMemberId}
                  />
                  <button
                    className="btn btn-outline-light"
                    type="button"
                    onClick={() => getDetailsFromMemeberIDForFD()}
                  >
                    Get Details
                  </button>
                </div>
                <button
                  type="button"
                  id="saveApplication"
                  className="btn btn-outline-light"
                  disabled={disableSaveButtonForFD}
                  onClick={() => checkFDFormSubmition()}
                >
                  Save
                </button>
                <button
                  type="button"
                  id="resetApplication"
                  className="btn btn-outline-light mx-3"
                  // disabled={disableSaveButton}
                  onClick={() => resetFDFormSubmition()}
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <br />
        {memberData ? (
          <div>
            <div className="accordion" id="accordionPersonalDetails">
              <div className="accordion-item">
                <h2 className="accordion-header" id="personalDetails">
                  <button
                    className="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapsePersonalDetails"
                    aria-expanded="true"
                    aria-controls="collapsePersonalDetails"
                  >
                    Personal Details
                  </button>
                </h2>
                <div
                  id="collapsePersonalDetails"
                  className="accordion-collapse collapse show"
                  aria-labelledby="personalDetails"
                  data-bs-parent="#accordionPersonalDetails"
                >
                  <div className="accordion-body">
                    <table className="table">
                      <tbody>
                        <tr>
                          <td>
                            <div className="container-fluid">
                              <div className="row">
                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Member Name
                                    </label>
                                    <input
                                      type="text"
                                      autoComplete="off"
                                      className="form-control"
                                      id="memberName"
                                      name="memberName"
                                      placeholder="Member Name"
                                      onChange={handleFDMemberName}
                                      value={memberName}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Ticket Number
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      id="ticketNumber"
                                      name="ticketNumber"
                                      autoComplete="off"
                                      placeholder="Ticket Number"
                                      onChange={handleFDTicketnumber}
                                      value={ticketNumber}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Section
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      id="section"
                                      name="section"
                                      autoComplete="off"
                                      placeholder="Section"
                                      onChange={handleFDSection}
                                      value={section}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>

                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">Post</label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      id="post"
                                      name="post"
                                      autoComplete="off"
                                      placeholder="Post"
                                      onChange={handleFDPost}
                                      value={post}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Personal Number
                                    </label>
                                    <input
                                      type="text"
                                      autoComplete="off"
                                      className="form-control"
                                      id="personalNumber"
                                      name="personalNumber"
                                      placeholder="Personal Number"
                                      onChange={handleFDPersonalNumber}
                                      value={personalNumber}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Contact Number
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      autoComplete="off"
                                      id="contactNumber"
                                      name="contactNumber"
                                      placeholder="Phone No."
                                      onChange={handleFDContactNumber}
                                      value={contactNumber}
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>

                                <div className="col-lg-3">
                                  <div className="pd-b-10 pd-r-5">
                                    <label className="form-label">
                                      Date Of Birth
                                    </label>
                                    <input
                                      className="form-control"
                                      id="dateOfBirth"
                                      name="dateOfBirth"
                                      autoComplete="off"
                                      type="Date"
                                      onChange={handleFDDOB}
                                      value={dob}
                                      placeholder="Date of Birth"
                                      disabled
                                      readOnly
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                          <td>
                            <img
                              className="uploaded-images"
                              src={`data:image/png;image/jpg;image/jpeg;base64,${FDmemberPhoto}`}
                              alt=""
                              srcSet=""
                            />
                            <br />
                            <img
                              className="uploaded-images"
                              src={`data:image/png;image/jpg;image/jpeg;base64,${FDmemberSignature}`}
                              alt=""
                              srcSet=""
                            />
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <div className="accordion" id="accordionAddressDetails">
                      <div className="accordion-item">
                        <h2 className="accordion-header" id="FDAddress">
                          <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#collapseTwow"
                            aria-expanded="true"
                            aria-controls="collapseTwow"
                          >
                            Address
                          </button>
                        </h2>
                        <div
                          id="collapseTwow"
                          className="accordion-collapse collapse show"
                          aria-labelledby="FDAddress"
                          data-bs-parent="#accordionAddressDetails"
                        >
                          <div className="accordion-body">
                            <div className="container-fluid">
                              <div className="row">
                                <div className="col-lg-12">
                                  <form>
                                    <div className="row g-3">
                                      <div className="col-md-6">
                                        <div className="row">
                                          <div className="col-12">
                                            <label htmlFor="title">
                                              Mailing Address
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="mailingAddressLine1"
                                              name="mailingAddressLine1"
                                              type="text"
                                              autoComplete="off"
                                              onChange={
                                                handleMailingAddressLine1
                                              }
                                              value={mailingAddressLine1}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">City</label>
                                            <input
                                              className="form-control my-1"
                                              id="mailingCity"
                                              name="mailingCity"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handleMailingCity}
                                              value={mailingCity}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              District
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="mailingDistrict"
                                              name="mailingDistrict"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handleMailingDistrict}
                                              value={mailingDistrict}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">State</label>
                                            <select
                                              className="form-select"
                                              id="mailingState"
                                              name="mailing.state"
                                              onChange={handleMailingState}
                                              value={mailingState}
                                              disabled
                                            >
                                              <option value="">
                                                --Select--
                                              </option>
                                              {stateArr.map((element) => {
                                                return (
                                                  <option value={element.state}>
                                                    {element.state}
                                                  </option>
                                                );
                                              })}
                                            </select>
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Country
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="mailing.country"
                                              name="mailing.country"
                                              autoComplete="off"
                                              type="text"
                                              value="India"
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Pincode
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="mailing.pinCode"
                                              name="mailing.pinCode"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handleMailingPinCode}
                                              value={mailingPinCode}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Contact No.
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="mailing.contact"
                                              name="mailing.contact"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handleMailingContact}
                                              value={mailingContact}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          {/* <div className="col-12">
                                    <input type="checkbox" name="sameAddress" onChange={() => setSameAddressValue()} />
                                    <label className="form-check-label ps-2" htmlFor="inlineRadio1">Keep Mailing Address as Permanent Address</label>
                                  </div> */}
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        <div className="row">
                                          <div className="col-12">
                                            <label htmlFor="title">
                                              Permanent Address
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.addressLine1"
                                              name="permanent.addressLine1"
                                              type="text"
                                              autoComplete="off"
                                              onChange={
                                                handlePermanentAddressLine1
                                              }
                                              value={permanentAddressLine1}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">City</label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.postOrCity"
                                              name="permanent.postOrCity"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handlePermanentCity}
                                              value={permanentCity}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              District
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.district"
                                              name="permanent.district"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handlePermanentDistrict}
                                              value={permanentDistrict}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">State</label>
                                            <select
                                              className="form-select"
                                              id="mailing.state"
                                              name="mailing.state"
                                              onChange={handlePermanentState}
                                              value={permanentState}
                                              disabled
                                            >
                                              <option value="">
                                                --Select--
                                              </option>
                                              {stateArr.map((element) => {
                                                return (
                                                  <option value={element.state}>
                                                    {element.state}
                                                  </option>
                                                );
                                              })}
                                            </select>
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Country
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.country"
                                              name="permanent.country"
                                              type="text"
                                              autoComplete="off"
                                              value="India"
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Pincode
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.pinCode"
                                              name="permanent.pinCode"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handlePermanentPinCode}
                                              value={permanentPinCode}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                          <div className="col-6">
                                            <label htmlFor="title">
                                              Contact No.
                                            </label>
                                            <input
                                              className="form-control my-1"
                                              id="permanent.contact"
                                              name="permanent.contact"
                                              type="text"
                                              autoComplete="off"
                                              onChange={handlePermanentContact}
                                              value={permanentContact}
                                              disabled
                                              readOnly
                                            />
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br></br>
            <div className="accordion" id="accordionAccountDetails">
              <div className="accordion-item">
                <h2 className="accordion-header" id="accountDetails">
                  <button
                    className="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseAccountDetails"
                    aria-expanded="false"
                    aria-controls="collapseAccountDetails"
                  >
                    Account Details
                  </button>
                </h2>
                <div
                  id="collapseAccountDetails"
                  className="accordion-collapse collapse"
                  aria-labelledby="accountDetails"
                  data-bs-parent="#accordionAccountDetails"
                >
                  <div className="accordion-body">
                    <div className="container-fluid">
                      <div className="row">
                        <div className="col-lg-3">
                          <div className="pd-b-10">
                            <label className="form-label">FD Amount</label>
                            <input
                              type="text"
                              className="form-control"
                              id="FDAmount"
                              name="FDAmount"
                              autoComplete="off"
                              placeholder="FD Amount"
                              onChange={handleFDAmount}
                              value={FDAmount}
                            />
                          </div>
                        </div>
                        <div className="col-lg-3">
                          <div className="pd-b-10">
                            <label className="form-label">Tenure</label>
                            <div>
                              <input
                                type="text"
                                className="form-control mx-1"
                                id="FDMonths"
                                name="FDMonths"
                                autoComplete="off"
                                onChange={handleFDMonths}
                                value={FDMonths}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-3">
                          <label htmlFor="title">Tenure Type</label>
                          <select
                            className="form-select"
                            id="tenureType"
                            name="tenureType"
                            onChange={handleFDType}
                            value={FDType}
                          >
                            <option value="">--Select--</option>
                            <option value="D">Day</option>
                            <option value="M">Month</option>
                            <option value="Y">Year</option>
                          </select>
                        </div>
                        <div className="col-lg-3">
                          <label htmlFor="title">Created On</label>
                          <input
                            className="form-control"
                            id="createdOn"
                            name="createdOn"
                            autoComplete="off"
                            type="Date"
                            onChange={handleCreatedOn}
                            value={createdOn}
                            placeholder="Create Date"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br />
            <div className="accordion" id="accordionGuarantor">
              <div className="accordion-item">
                <h2 className="accordion-header" id="Guarantor">
                  <button
                    className="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseGuarantor"
                    aria-expanded="false"
                    aria-controls="collapseGuarantor"
                  >
                    Nomination Details
                  </button>
                </h2>
                <div
                  id="collapseGuarantor"
                  className="accordion-collapse collapse"
                  aria-labelledby="Guarantor"
                  data-bs-parent="#accordionGuarantor"
                >
                  <div className="accordion-body">
                    <div className="container-fluid">
                      <div className="row">
                        <div className="col-lg-1"></div>
                        <div className="col-lg-4">
                          <div className="existingGBox">
                            <h5>
                              Existing Nominees ({existingNominees.length}/10)
                            </h5>
                            <br />
                            <div className="existing-guarantor-subBox">
                              <div className="container-fluid">
                                <div className="row">
                                  {existingNominees.map((el, index) => {
                                    return (
                                      <div className="col-lg-12">
                                        <div className="guaranter-box">
                                          <div className="text-boxGuarantor">
                                            <span>
                                              {el.name +
                                                " (" +
                                                el.relation +
                                                ")"}
                                            </span>
                                          </div>
                                          <div className="inline-block">
                                            <FontAwesomeIcon
                                              className="fa-icon"
                                              icon={solid("trash-can")}
                                              onClick={() => deleteNominee(el)}
                                            />
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-1"></div>
                        <div className="col-lg-4">
                          <div className="existingGBox">
                            <h5>Add Nominee</h5>
                            {/* <div className="input-group mb-3"> */}
                            <label className="form-label">Nominee Name</label>
                            <input
                              type="text"
                              className="form-control"
                              id="nomineeName"
                              name="nomineeName"
                              placeholder="Nominee Name"
                              autoComplete="off"
                              onChange={handleNomineeName}
                              value={nomineeName}
                              aria-label="Nominee Name"
                            />
                            <label className="form-label">
                              Nominee Relation
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              id="nomineeRelation"
                              name="nomineeRelation"
                              autoComplete="off"
                              placeholder="Nominee Relation"
                              onChange={handleNomineeRelation}
                              value={nomineeRelation}
                              aria-label="Nominee Relation"
                            />
                            <label className="form-label">
                              Nominee Address
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              id="nomineeAddress"
                              name="nomineeAddress"
                              placeholder="Nominee Name"
                              autoComplete="off"
                              onChange={handleNomineeAddress}
                              value={nomineeAddress}
                              aria-label="Nominee Address"
                            />
                            <br />
                            <button
                              className="btn btn-outline-secondary"
                              type="button"
                              onClick={() => addNominee()}
                            >
                              Add
                            </button>
                            <br />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
};