import React, { useState } from "react";
import "./fd.scss";
import MainService from "../../../services/main-service";
import dateFormat from "dateformat";

const mainService = new MainService("");

export const FDAssignment = () => {
  var [FDApplicationId, setFDApplicationId] = React.useState("");
  var [FDSchemeId, setFDSchemeId] = React.useState("");
  var [responseFDScheme, setResponseFDScheme] = React.useState();
  var [responseFDApplication, setResponseFDApplication] = React.useState();
  var [FDAmount, setFDAmount] = React.useState("");
  // var [tenure, setTenure] = React.useState('');
  var [interestRate, setInterestRate] = React.useState("");
  var [FDSchemeName, setFDSchemeName] = React.useState("");
  var [alertMessageAssignmentTab, setAlertMessageAssignmentTab] =
    React.useState("");
  var [showAlertAssignmentTab, setShowAlertAssignmentTab] =
    React.useState(false);
  var [allFDSchemes, setAllFDSchemes] = React.useState(Array<any>());
  var [maturityAmount, setMaturityAmount] = React.useState("");
  var [FDYears, setFDYears] = React.useState("");
  var [FDMonths, setFDMonths] = React.useState("");
  var [FDRemark, setFDRemark] = React.useState("");
  var [showSuccessDialogFD, setShowSuccessDialogFD] = React.useState(false);
  var [showAssignBtnFD, setShowAssignBtnFD] = React.useState(false);
  var [FDAssignmentResponse, setFDAssignmentResponse] = React.useState();
  var [FDAccountId, setFDAccountId] = React.useState("");
  var [FDLedgerNumber, setFDLedgerNumber] = React.useState("");

  React.useEffect(() => {
    getAllFDSchemes();
  }, []);
  React.useEffect(() => {
    if (FDAmount && FDMonths && interestRate) {
      let newFDAmount = parseInt(FDAmount);
      // let newTenure = (parseFloat(FDYears) * 12) + parseFloat(FDMonths);
      let newTenure = parseFloat(FDMonths);
      let newRate = parseFloat(interestRate);

      newTenure = newTenure / 12;
      let interestOnFD = (newFDAmount * newTenure * newRate) / 100;
      setMaturityAmount(Math.round(newFDAmount + interestOnFD) + "");
    }
  }, [FDAmount, FDMonths, interestRate]);

  async function getAllFDSchemes() {
    let url = `fd/scheme`;
    try {
      let response = await mainService.getRequest(url, null, null);
      setAllFDSchemes(response.data.content);
    } catch (e: any) {
      console.log(e);
    }
  }

  const handleFDApplicationId = (e: any) => {
    setFDApplicationId(e.target.value);
  };

  const handleFDSchemeId = (e: any) => {
    setFDSchemeId(e.target.value);
  };

  async function getFDAssignmentDetails() {
    console.log(FDSchemeName);
    let url = `fd/application/${FDApplicationId}`;
    let response1 = await mainService.getRequest(url, null, null);
    setResponseFDApplication(response1.data);
    let url1: string = "";
    if (FDSchemeId) {
      url1 = `fd/scheme/${FDSchemeId}`;
    }
    if (FDSchemeName) {
      url1 = `fd/scheme/${FDSchemeName}`;
    }
    if (FDSchemeId == "" && FDSchemeName == "") {
      setAlertMessageAssignmentTab("Provide Scheme ID or Scheme Name.");
      setShowAlertAssignmentTab(true);
      setTimeout(() => {
        setShowAlertAssignmentTab(false);
      }, 5000);
    }
    if (response1.data["status"] && response1.data["status"] == "Approved") {
      setAlertMessageAssignmentTab("FD Application already assigned.");
      setShowAlertAssignmentTab(true);
      setTimeout(() => {
        setShowAlertAssignmentTab(false);
      }, 5000);
      return;
    }
    let response2 = await mainService.getRequest(url1, null, null);
    setResponseFDScheme(response2.data);
    setFDAmount(response1.data["fdAmount"]);
    setInterestRate(response2.data["fdInterestRate"]);
    setFDMonths(response1.data["tenure"]);
    setShowAssignBtnFD(true);
  }

  const closeAlertAssignTab = () => {
    setShowAlertAssignmentTab(false);
  };

  async function assignFDDetails() {
    let payload = {
      status: "Approved",
      fdApplication: responseFDApplication,
      schemeId: responseFDScheme,
      assignedAmount: FDAmount,
      assignedTenure: parseInt(FDMonths) + "",
      interest: parseFloat(maturityAmount) - parseFloat(FDAmount),
      onMaturityAmount: parseFloat(maturityAmount),
      remark: FDRemark,
      fdAccountNumber: FDAccountId,
      fdLedgerNumber: FDLedgerNumber,
    };
    let url = `fd/assignment`;
    let response = await mainService.postRequest(url, payload, null);
    if (response.status == 200) {
      setFDAssignmentResponse(response.data);
      setShowSuccessDialogFD(true);
      let anyObj: any = "";
      setResponseFDApplication(anyObj);
      setResponseFDScheme(anyObj);
      setFDAmount("");
      setFDYears("");
      setFDMonths("");
      setInterestRate("");
      setMaturityAmount("");
      setFDRemark("");
      setShowAssignBtnFD(false);
      setFDApplicationId("");
      setFDSchemeId("");
      setFDSchemeName("");
    } else {
      setAlertMessageAssignmentTab("Something went wrong. Please try again.");
      setShowAlertAssignmentTab(true);
      setTimeout(() => {
        setShowAlertAssignmentTab(false);
      }, 5000);
    }
    console.log(response);
  }

  const closeFDAssignmentModal = () => {
    setShowSuccessDialogFD(false);
  };

  const handleFDAmount = (e: any) => {
    setFDAmount(e.target.value);
  };
  const handleFDAccountId = (e: any) => {
    setFDAccountId(e.target.value);
  };
  const handleFDLedgerNumber = (e: any) => {
    setFDLedgerNumber(e.target.value);
  };
  const handleInterestRate = (e: any) => {
    setInterestRate(e.target.value);
  };
  const handleFDSchemeName = (e: any) => {
    setFDSchemeName(e.target.value);
  };
  const handleMaturityAmount = (e: any) => {
    setMaturityAmount(e.target.value);
  };
  const handleFDYears = (e: any) => {
    setFDYears(e.target.value);
  };
  const handleFDMonths = (e: any) => {
    setFDMonths(e.target.value);
  };
  const handleFDRemark = (e: any) => {
    setFDRemark(e.target.value);
  };
  return (
    <div className="">
      {showAlertAssignmentTab ? (
        <div className="d-flex justify-content-end my-4cphx-pagination">
          <div>
            <div
              className="alert alert-success alert-notification alert-dismissible fade show"
              role="alert"
            >
              <span>{alertMessageAssignmentTab}</span>
              <button
                aria-label="Close"
                className="close close-position"
                type="button"
                data-dismiss="alert"
                onClick={() => closeAlertAssignTab()}
              >
                &times;
              </button>
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}

      {showSuccessDialogFD ? (
        <div className="modal" id="response-modal" role="dialog">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">FD Application Saved</h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={() => closeFDAssignmentModal()}
                ></button>
              </div>
              <div className="modal-body">
                {FDAssignmentResponse ? (
                  <div>
                    <div>
                      <span>
                        <strong>FD ID: </strong>
                      </span>
                      <span>{FDAssignmentResponse["fdId"]}</span>
                    </div>
                    <div>
                      <span>
                        <strong>FD Account Number: </strong>
                      </span>
                      <span>{FDAssignmentResponse["fdAccountNumber"]}</span>
                    </div>
                    <div>
                      <span>
                        <strong>FD Assignment Creation Date: </strong>
                      </span>
                      <span>
                        {dateFormat(
                          FDAssignmentResponse["createdOn"],
                          "mmmm dS, yyyy, h:MM:ss TT"
                        )}
                      </span>
                    </div>
                    <div>
                      <span>
                        <strong>FD Assignment Created By: </strong>
                      </span>
                      <span>{FDAssignmentResponse["createdBy"]}</span>
                    </div>
                  </div>
                ) : (
                  <></>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}

      <div className="container-fluid">
        <div className="row my-2">
          <div className="col-lg-3">
            <label className="form-label color-white">FD Application ID</label>
            <input
              type="text"
              className="form-control"
              autoComplete="off"
              id="FDApplicationId"
              name="FDApplicationId"
              placeholder="FD Application Id"
              onChange={handleFDApplicationId}
              value={FDApplicationId}
            />
          </div>
          <div className="col-lg-3">
            <label className="form-label color-white">FD Scheme ID</label>
            <input
              type="text"
              className="form-control"
              id="FDSchemeId"
              autoComplete="off"
              name="FDSchemeId"
              placeholder="FD Scheme Id"
              onChange={handleFDSchemeId}
              value={FDSchemeId}
            />
          </div>
          <div className="col-lg-3">
            <label className="form-label color-white">FD Scheme Name</label>
            <select
              className="form-select mb-3"
              aria-label="Default select example"
              id="FDSchemeName"
              name="FDSchemeName"
              onChange={handleFDSchemeName}
              value={FDSchemeName}
            >
              <option value="" key="">
                Select
              </option>
              {allFDSchemes.map((e) => (
                <option value={e.schemeId} key={e.fdName}>
                  {e.fdName}
                </option>
              ))}
            </select>
          </div>
          <div className="col-lg-3">
            <button
              className="btn btn-outline-light mt-4"
              type="button"
              onClick={() => getFDAssignmentDetails()}
            >
              Go
            </button>
          </div>
        </div>

        {responseFDApplication && responseFDScheme ? (
          <div>
            <div className="row fd-assignment-details-box mx-2 my-3 p-2">
              <div className="col-lg-6 side-border">
                <div className="row">
                  <div className="col-lg-6">
                    <span>
                      <strong>FD Amount: </strong>
                      {responseFDApplication
                        ? responseFDApplication["fdAmount"]
                        : ""}
                    </span>
                  </div>
                  <div className="col-lg-6">
                    <span>
                      <strong>Tenure: </strong>
                      {responseFDApplication
                        ? responseFDApplication["tenure"] + " months"
                        : ""}
                    </span>
                  </div>
                </div>
              </div>

              <div className="col-lg-6">
                <div className="row">
                  <div className="col-lg-6">
                    <span>
                      <strong>FD Scheme: </strong>
                      {responseFDScheme ? responseFDScheme["fdName"] : ""}
                    </span>
                  </div>
                  <div className="col-lg-6">
                    <span className="ml-6">
                      <strong>Interest Rate: </strong>
                      {responseFDScheme
                        ? responseFDScheme["fdInterestRate"]
                        : ""}
                      %
                    </span>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-6">
                    <span>
                      <strong>Max Tenure: </strong>
                      {responseFDScheme ? responseFDScheme["tenure"] : ""}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <></>
        )}

        {responseFDScheme && responseFDApplication ? (
          <div>
            <div className="row my-2">
              <div className="col-lg-2">
                <label className="form-label color-white">FD Amount</label>
                <input
                  type="text"
                  className="form-control mb-3"
                  autoComplete="off"
                  id="FDAmount"
                  name="FDAmount"
                  placeholder="FD Amount"
                  onChange={handleFDAmount}
                  value={FDAmount}
                  aria-label="FD Amount"
                  aria-describedby="button-addon2"
                />
              </div>
              <div className="col-lg-2">
                <label className="form-label color-white">Tenure</label>
                <div>
                  <input
                    type="text"
                    className="form-control mx-1"
                    autoComplete="off"
                    id="FDMonths"
                    name="FDMonths"
                    placeholder="Months"
                    onChange={handleFDMonths}
                    value={FDMonths}
                  />
                </div>
              </div>
              <div className="col-lg-2">
                <label className="form-label color-white">Interest Rate</label>
                <input
                  type="text"
                  className="form-control mb-3"
                  autoComplete="off"
                  id="interestRate"
                  name="interestRate"
                  placeholder="Interest Rate"
                  onChange={handleInterestRate}
                  value={interestRate}
                />
              </div>
              <div className="col-lg-2">
                <label className="form-label color-white">
                  Maturity Amount
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="maturityAmount"
                  autoComplete="off"
                  name="maturityAmount"
                  placeholder="Interest Rate"
                  onChange={handleMaturityAmount}
                  value={maturityAmount}
                  disabled
                  readOnly
                />
              </div>
              <div className="col-lg-2">
                <label className="form-label color-white">FD Account Id</label>
                <input
                  type="text"
                  className="form-control mb-3"
                  autoComplete="off"
                  id="FDAccountId"
                  name="FDAccountId"
                  placeholder="FD Account Id"
                  onChange={handleFDAccountId}
                  aria-label="FD Account Id"
                  value={FDAccountId}
                />
              </div>
              <div className="col-lg-2">
                <label className="form-label color-white">
                  FD Ledger Number
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  autoComplete="off"
                  id="FDLedgernumber"
                  name="FDLedgernumber"
                  placeholder="FD Ledger Number"
                  onChange={handleFDLedgerNumber}
                  aria-label="FD Account Id"
                  value={FDLedgerNumber}
                />
              </div>
            </div>
            <div className="row my-2">
              <div className="col-lg-12">
                <label className="form-label color-white">Remark</label>
                <textarea
                  className="form-control my-1 fs-6"
                  name="FDRemark"
                  rows={3}
                  placeholder="Remark"
                  onChange={handleFDRemark}
                  value={FDRemark}
                />
              </div>
            </div>
          </div>
        ) : (
          <></>
        )}
        {showAssignBtnFD ? (
          <div className="row my-2">
            <div className="col-lg-5"></div>
            <div className="col-lg-1">
              <button
                className="btn btn-outline-light"
                type="button"
                onClick={() => assignFDDetails()}
              >
                Assign
              </button>
            </div>
          </div>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
};
