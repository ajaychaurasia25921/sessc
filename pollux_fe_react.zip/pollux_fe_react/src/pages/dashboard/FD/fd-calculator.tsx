import React, { useState } from 'react';
import './fd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

type RowsObjFD = {
    id: string,
    fdName: string,
    fdInterestRate: number,
    tenure: string,
    fee: string,
    preClosureCharges: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string
};

export const FDCalculator = (props: any) => {

    var [FDAmount, setFDAmount] = React.useState('5000');
    var [FDRange, setFDRange] = React.useState('5000');
    var [estReturns, setEstReturns] = React.useState('');
    var [FDSchemeName, setFDSchemeName] = React.useState('');
    var [interestStartRange, setInterestStartRange] = React.useState('');
    var [FDTenureType, setFDTenureType] = React.useState('');
    var [FDMonths, setFDMonths] = React.useState('');
    var [maturedAmount, setMaturedAmount] = React.useState('');
    var [allFDSchemes, setAllFDSchemes] = React.useState(Array<any>());
    var [maturityDate, setMaturityDate] = React.useState('');

    const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
    React.useEffect(() => {
        getAllFDSchemes();
    }, []);
    React.useEffect(() => {
        for (let s of allFDSchemes) {
            if (s.schemeId == FDSchemeName) {
                setInterestStartRange(s.fdInterestRate);
                break;
            }
        }
    }, [FDSchemeName]);

    async function getAllFDSchemes() {
        let url = `fd/scheme`;
        try {
            let response = await mainService.getRequest(url, null, null);
            setAllFDSchemes(response.data.content);
        } catch (e: any) {
            console.log(e)
        }
    }

    const handleFDAmount = (e: any) => {
        setFDAmount(e.target.value);
        setFDRange(e.target.value);
    }
    const handleFDSchemeName = (e: any) => {
        setFDSchemeName(e.target.value);
    }
    const handleFDRange = (e: any) => {
        setFDRange(e.target.value);
        setFDAmount(e.target.value);
    }
    const handleFDMonths = (e: any) => {
        setFDMonths(e.target.value);
    }
    const handleInterestStartRange = (e: any) => {
        setInterestStartRange(e.target.value);
    }
    const handleTenureType = (e: any) => {
        setFDTenureType(e.target.value);
    }
    async function calculateInputs() {
        let tenure: any = "";
        var d = new Date();
        if (FDTenureType == "Years") {
            tenure = FDMonths;
            d.setFullYear(d.getFullYear() + parseInt(FDMonths));
        }
        if (FDTenureType == "Months") {
            tenure = parseFloat(FDMonths) / 12;
            d.setMonth(d.getMonth() + parseInt(FDMonths));
        }
        if (FDTenureType == "Days") {
            if(parseInt(FDMonths) < 46) {
                setEstReturns("0");
                setMaturedAmount(parseFloat(FDAmount) + "");
                d.setDate(d.getDate() + parseInt(FDMonths));
                setMaturityDate(d.getDate()+" "+ monthNames[d.getMonth()]+" "+d.getFullYear());
                return;
            } else {
                tenure = parseFloat(FDMonths) / (365);
                // d.setMonth(d.getMonth() + parseInt(FDMonths));
            }
            d.setDate(d.getDate() + parseInt(FDMonths));
            console.log(d)
    // return date;
        }
        setMaturityDate(d.getDate()+" "+ monthNames[d.getMonth()]+" "+d.getFullYear());

        let interest = (parseFloat(FDAmount) * parseFloat(interestStartRange) * parseFloat(tenure)) / 100;
        setEstReturns(Math.round(interest) + "");
        let OnMaturityAmount = parseFloat(FDAmount) + interest;
        setMaturedAmount(Math.round(OnMaturityAmount) + "");
    }

    function resetInputs() {
        setFDAmount('');
        setFDRange('');
        setFDSchemeName('');
        setInterestStartRange('');
        setFDTenureType('');
        setFDMonths('');
    }


    return (
        <div>
            <div className="container-fluid">
                <div className='row'>
                    {/* <div className='col-md-1'></div> */}
                    <div className='col-md-3'>
                        <div className="form-body">
                            <div className="row">
                                <div className="form-holder fd-scheme-form">
                                    <div className="form-content">
                                        <div className="form-items color-white">
                                            <form className="mt-1">
                                                <div className="col-md-12">
                                                    <label className='form-label'>FD Amount</label>
                                                    <input className="form-control my-1 fs-6"
                                                        id="fdAmount"
                                                        autoComplete='off'
                                                        name="fdAmount"
                                                        type="text"
                                                        onChange={handleFDAmount}
                                                        value={FDAmount}
                                                        placeholder="FD Amount" />
                                                </div>

                                                <label className="form-label">Example range</label>
                                                <input type="range"
                                                    onChange={handleFDRange}
                                                    value={FDRange}
                                                    className="form-range"
                                                    min="0"
                                                    max="10000000"
                                                    step="1000"
                                                    id="customRange3"></input>

                                                <div className='col-md-12'>
                                                    <label className="form-label color-white">FD Scheme Name</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="FDSchemeName"
                                                        name="FDSchemeName"
                                                        onChange={handleFDSchemeName}
                                                        value={FDSchemeName}>
                                                        <option value="" key="" >Select</option>
                                                        {
                                                            allFDSchemes.map(e => <option
                                                                value={e.schemeId} key={e.fdName}>{e.fdName}</option>)
                                                        }
                                                    </select>
                                                </div>

                                                <div className="col-md-12">
                                                    <label className='form-label'>Interest Rate</label>
                                                    <div>
                                                        <input type="text"
                                                            className="form-control"
                                                            id="interestStartRange"
                                                            autoComplete='off'
                                                            name="interestStartRange"
                                                            placeholder="Interest Rate"
                                                            onChange={handleInterestStartRange}
                                                            value={interestStartRange} disabled readOnly />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <label className='form-label'>Tenure (in months)</label>
                                                    <div>
                                                        <div className='inline-prop'>
                                                            <input type="text"
                                                                className="form-control"
                                                                id="FDMonths"
                                                                name="FDMonths"
                                                                autoComplete='off'
                                                                onChange={handleFDMonths}
                                                                value={FDMonths} />
                                                        </div>
                                                        <div className='inline-prop'>
                                                            <select className="form-select"
                                                                aria-label="Default select example"
                                                                id="FDFilterType" name="FDFilterType"
                                                                onChange={handleTenureType}
                                                                value={FDTenureType}>
                                                                <option value="Select" key="Select">Select</option>
                                                                <option value="Years" key="Years">Year</option>
                                                                <option value="Months" key="Months">Month</option>
                                                                <option value="Days" key="Days">Days</option>
                                                            </select>
                                                        </div>
                                                        {/* <div className='col-md-1'></div> */}

                                                    </div>
                                                </div>

                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => calculateInputs()}>Calculate</button>
                                                        <button type="button" className="btn btn-outline-light"
                                                        onClick={() => resetInputs()}>Reset</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-7'>
                        <div className="output-card">
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                    <strong>
                                        <div>
                                            <span className='smallfont'>ESTIMATED RETURNS</span>
                                        </div>
                                        Rs. <span className='xxlargefont'>{estReturns}</span>
                                    </strong>
                                    </div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                    <strong>
                                        <div>
                                            <span className='smallfont'>MATURITY AMOUNT</span>
                                        </div>
                                        Rs. <span className='xxlargefont'>{maturedAmount}</span>
                                    </strong>
                                    </div>  
                                </div>
                                <br/><br/>
                                <div className='interest-div'>
                                <span><strong>Interest @ {interestStartRange} p.a.</strong></span>
                                </div>
                            </div>
                            <hr/>
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='interest-div'>
                                    <span><strong>Matured Upto : {maturityDate}</strong></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}
