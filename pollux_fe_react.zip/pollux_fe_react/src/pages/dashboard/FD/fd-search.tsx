import React, { useState } from 'react';
import './fd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Button, Modal } from 'react-bootstrap';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

type RowsObj = {
    id: string,
    fdAccountNumber: string,
    memberId: string,
    fdAmount: number,
    tenure: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string
};

export const FDSearch = (props: any) => {

    var [FDFilterType, setFDFilterType] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [FDId, setFDId] = React.useState('');
    const [rowsData, setRows] = React.useState(Array);
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [hasPrevious, setHasPrevious] = React.useState(false);
    var [deleteModal, setDeleteModal] = React.useState(false);
    var [FDDeactivateRecordId, setFDDeactivateRecordId] = React.useState("");
    // var [FDDeactiRecordId, setFDDeactivateRecordId] = React.useState("");
    var [FDassignmentViewModal, setFDAssignmentViewModal] = React.useState(false);
    var [FDassignmentBreakModal, setFDAssignmentBreakModal] = React.useState(false);
    var [FDassignmentSchemeChangeModal, setFDAssignmentSchemeChangeModal] = React.useState(false);
    var [FDViewRecord, setFDViewRecord] = React.useState();
    var [FDBreakRecord, setFDBreakRecord] = React.useState();
    var [FDSchemeChangeRecord, setFDSchemeChangeRecord] = React.useState();
    var [FDapplicationAssigned, setFDApplicationAssigned] = React.useState(true);
    var [interestTilldate, setInterestTilldate] = React.useState('');
    var [maturitytilldate, setMaturitytilldate] = React.useState('');
    var [tillDay, setTillday] = React.useState('');
    var [FDSchemeName, setFDSchemeName] = React.useState('');
    var [allFDSchemes, setAllFDSchemes] = React.useState(Array<any>());
    var [FDUpdatedScheme, setFDUpdatedScheme] = React.useState();


    React.useEffect(() => {
        getRows(10, 0);
    }, []);

    React.useEffect(() => {
        let newScheme: any = "";
        for(let nv of allFDSchemes) {
            if(nv.schemeId == FDSchemeName) {
                newScheme = nv;
                setFDUpdatedScheme(nv);
                break;
            }
        };
        if(parseInt(tillDay) < 46) {
            setInterestTilldate('0');
            setMaturitytilldate(FDSchemeChangeRecord?FDSchemeChangeRecord['assignedAmount']:'');
        } else {
            let calculateInterest = ((FDSchemeChangeRecord ? (FDSchemeChangeRecord['assignedAmount'] * newScheme['fdInterestRate']) : 0) / (100 * 365)) * 50;//parseInt(tillDay)
            setInterestTilldate(Math.round(calculateInterest)+"");
            setMaturitytilldate(FDSchemeChangeRecord?FDSchemeChangeRecord['assignedAmount']+Math.round(calculateInterest)+"":'');
        }
    },[FDSchemeName]);

    React.useEffect(() => {
        setMemberId("");
        setFDId("");
    }, [FDFilterType]);


    const columnsList: GridColDef[] = [
        { field: 'id', headerName: 'FD Application ID', width: 150 },
        { field: 'fdAccountNumber', headerName: 'FD Account Number', width: 150 },
        { field: 'memberId', headerName: 'Member ID', width: 150 },
        { field: 'fdAmount', headerName: 'FD Amount', width: 150 },
        { field: 'tenure', headerName: 'Tenure (in months)', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'modifiedOn', headerName: 'Modified On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        { field: 'modifiedBy', headerName: 'Modified By', width: 150 },
        {
            field: 'Actions',
            width: 130,
            sortable: false,

            renderCell: (params) => {
                async function deActivateRecord() {
                    setFDDeactivateRecordId(params.row.id);
                    setDeleteModal(!deleteModal);
                };
                async function viewRecord() {
                    let tempurl = `fd/assignment/member?memberId=${params.row.memberId}`;
                    let response = await mainService.getRequest(tempurl, null, null);
                    let fdRec: any = "";
                    if (response.data.length > 0) {
                        // setFDApplicationAssigned(true);
                        for (let s of response.data) {
                            if (params.row.id == s.fdApplication.applicationId) {
                                fdRec = s;
                                setFDViewRecord(s);
                                break;
                            }
                        }
                    }
                    else {
                        let obj: any = "";
                        setFDViewRecord(obj);
                    }
                    if (fdRec) {
                        setFDApplicationAssigned(true);
                        setFDAssignmentViewModal(true);
                    } else {
                        setFDApplicationAssigned(false);
                        setFDAssignmentViewModal(true);
                        let obj: any = "";
                        setFDViewRecord(obj);

                    }
                }

                async function breakFD() {
                    let tempurl = `fd/assignment/member?memberId=${params.row.memberId}`;
                    let response = await mainService.getRequest(tempurl, null, null);

                    let fdRec: any = "";
                    if (response.data.length > 0) {
                        // setFDApplicationAssigned(true);
                        let targetData: any = "";
                        for (let s of response.data) {
                            if (params.row.id == s.fdApplication.applicationId) {
                                fdRec = s;
                                targetData = s;
                                setFDBreakRecord(s);
                                break;
                            }
                        }
                        let secondUrl = "fd/breakage?id=" + targetData['fdId'];
                        let response2 = await mainService.getRequest(secondUrl, null, null);
                        console.log(response2.data.tillDay);
                        setTillday(response2.data.tillDay);
                        if (response2.data.tillDay < 46) {
                            setInterestTilldate('0');
                            setMaturitytilldate(response2.data.assignmentDetail.assignedAmount+ '');
                        } else {
                            let calculateInterest = ((response2.data.assignmentDetail.assignedAmount * response2.data.assignmentDetail.schemeId.fdInterestRate) / (100 * 365)) * response2.data.assignmentDetail.tillDay;
                            setInterestTilldate("");
                            setMaturitytilldate(calculateInterest+"");
                        }
                    }
                    else {
                        let obj: any = "";
                        setFDBreakRecord(obj);
                    }
                    if (fdRec) {
                        setFDAssignmentBreakModal(true);
                        setFDApplicationAssigned(true);
                    } else {
                        setFDAssignmentBreakModal(true);
                        setFDApplicationAssigned(false);
                        let obj: any = "";
                        setFDBreakRecord(obj);

                    }
                }

                async function schemeChangeFD() {
                    let tempurl = `fd/assignment/member?memberId=${params.row.memberId}`;
                    let response = await mainService.getRequest(tempurl, null, null);

                    let fdRec: any = "";
                    if (response.data.length > 0) {
                        let targetData: any = "";
                        for (let s of response.data) {
                            if (params.row.id == s.fdApplication.applicationId) {
                                fdRec = s;
                                targetData = s;
                                setFDSchemeChangeRecord(s);
                                break;
                            }
                        }
                        getAllFDSchemes();
                        let secondUrl = "fd/breakage?id=" + targetData['fdId'];
                        let response2 = await mainService.getRequest(secondUrl, null, null);
                        if(response2.status == 200) {
                            setTillday(response2.data.tillDay);
                        }
                    }
                    else {
                        let obj: any = "";
                        setFDSchemeChangeRecord(obj);
                    }
                    if (fdRec) {
                        setFDApplicationAssigned(true);
                        setFDAssignmentSchemeChangeModal(true);
                    } else {
                        setFDApplicationAssigned(false);
                        setFDAssignmentSchemeChangeModal(true);
                        let obj: any = "";
                        setFDSchemeChangeRecord(obj);

                    }
                }

                async function getAllFDSchemes() {
                    let url = `fd/scheme`;
                    try {
                        let response = await mainService.getRequest(url, null, null);
                        setAllFDSchemes(response.data.content);
                    } catch (e: any) {
                        console.log(e)
                    }
                }
                return (
                    <>
                        <FontAwesomeIcon className='fa-icon-table' title="View" icon={solid('eye')} onClick={() => viewRecord()} />
                        <button className="btn p-0" onClick={() => deActivateRecord()} title="Deactivate"><img className="mx-1" src="/assets/remove.svg" alt="" /></button>
                        <FontAwesomeIcon className='fa-icon-table' title="Break FD" icon={solid('bolt')} onClick={() => breakFD()} />
                        <FontAwesomeIcon className='fa-icon-table' title="Change Scheme" icon={solid('retweet')} onClick={() => schemeChangeFD()} />

                    </>
                );
            },
        },
    ];

    const handleFDFilterType = (e: any) => {
        setFDFilterType(e.target.value);
    }
    const handleFDSchemeName = (e: any) => {
        setFDSchemeName(e.target.value);
    }
    const handleMemberId = (e: any) => {
        setMemberId(e.target.value);
    }
    const handleFDId = (e: any) => {
        setFDId(e.target.value);
    }

    async function searchFDPlan() {
        try {
            setPageSize(0);
            getRows(10, 0);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function getRows(rowSize: number, pageSize: number) {
        try {
            let url = "";
            let abc: any[] = [];
            let processResponse: any[] = [];
            if (FDFilterType == "") {
                return;
            }
            if (FDFilterType == "Get All") {
                url = `fd/application?size=${rowSize}&page=${pageSize}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else if (FDFilterType == "FD Application ID") {
                url = `fd/application/${FDId}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse.push(response.data);
            } else if (FDFilterType == "Member ID") {
                url = `fd/application/member?id=${memberId}&page=${pageSize}&size=${rowSize}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else {
            }

            processResponse.forEach((element: any) => {
                let data: RowsObj = {
                    id: element.applicationId,
                    fdAccountNumber: element.fdAccountNumber,
                    memberId: element.memberId,
                    tenure: element.tenure,
                    fdAmount: element.fdAmount,
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    modifiedOn: dateFormat(element.modifiedOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    modifiedBy: element.createdBy
                }
                // console.log("ele  ",element)
                // if(element.active) {
                    abc.push(data);
                // }
                
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }


    function txnDataNext() {
        setPageSize(pageSize + 1);
        getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    async function deactivateRecordOnConfirm(id: any) {
        let url = `fd/revoke/${FDDeactivateRecordId}`;
        try {
            let response = await mainService.getRequest(url, null, null);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function breakFDRecordOnConfirm(id: any) {
        let url = `fd/breakage`; ///${FDBreakRecord ? FDBreakRecord['fdId']: ''}`;
        console.log(FDBreakRecord)
        let obj = {
            "accountNumber": FDBreakRecord ? FDBreakRecord['fdAccountNumber'] : "",
            "amount": FDBreakRecord ? parseFloat(FDBreakRecord['assignedAmount']) : '',
            "fundingAccount": "SBI",
            "id": FDBreakRecord ? FDBreakRecord['fdId']: '',
            "indicator": "Debit",
            "interest": parseFloat(interestTilldate),
            "memberId": FDBreakRecord ? FDBreakRecord['fdApplication']['memberId'] : '',
            "mode": "Bank_Transfer",
            // "notes": "string"
          }
        try {
            let response = await mainService.postRequest(url, obj, null);
            if(response.status == 200) {
                let url2 = `fd/application/status`;
                let obj2 = [{
                    "active": false,
                    "applicationId": FDBreakRecord ? FDBreakRecord['fdApplication']['applicationId']: '',
                    "memberId": FDBreakRecord ? FDBreakRecord['fdApplication']['memberId'] : '',
                    "status": "Break"
                }];
                // try {
                    let response2 = await mainService.postRequest(url2, obj2, null);
                    if(response2.status== 200) {
                        getRows(10, 0);
                    }
                // }
                // catch (e: any) {
                //     console.log(e);
                // }
            }
        }
        catch (e: any) {
            console.log(e);
        }
        
        
    }

    async function updateSchemeFDRecordOnConfirm(id: any) {
        let url = "fd/assignment/scheme?id="+(FDSchemeChangeRecord?FDSchemeChangeRecord['fdId']:'')+"&schemeId="+FDSchemeName;
        try {
            let response = await mainService.postRequest(url, null, null);
            if(response.status == 200) {
                setFDAssignmentSchemeChangeModal(false);
            }
        }
        catch (e: any) {
            console.log(e);
        }
    }

    function DeleteModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Are you sure want to <strong className='text-danger'>Delete</strong> the Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block text-center'>
                    <p>
                        You are about to delete FD Application <strong>{FDBreakRecord ? FDBreakRecord['fdApplication']['applicationId'] : ""}</strong>. This process is irrevesable!
                    </p>
                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setDeleteModal(!deleteModal) }}>Cancel</Button>
                    <Button variant="danger" onClick={() => { deactivateRecordOnConfirm(FDDeactivateRecordId); setDeleteModal(!deleteModal); getRows(10, 0); }}>Delete</Button>
                </Modal.Footer>
            </Modal>
        );
    }

    function ViewFDAssignmentModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        View FD Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    {FDassignmentViewModal && !FDapplicationAssigned ? <h3>FD Application not assigned to any scheme. Please Assign to view details.</h3> : <></>}
                    {FDassignmentViewModal && FDapplicationAssigned ? <div className='row'>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">FD Account Number</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['fdAccountNumber'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['assignedAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Tenure (in months)</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['assignedTenure'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Rate</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['schemeId']['fdInterestRate'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Amount To Be Credited</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['interest'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">On-Maturity Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['onMaturityAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId" disabled
                                    value={FDViewRecord ? dateFormat(FDViewRecord['maturityDate'], "mmmm dS, yyyy") : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme ID</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['schemeId']['schemeId'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme Name</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDViewRecord ? FDViewRecord['schemeId']['fdName'] : ""} />
                            </div>
                        </div>
                    </div> : <></>}

                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setFDApplicationAssigned(false); setFDAssignmentViewModal(!FDassignmentViewModal) }}>Cancel</Button>
                </Modal.Footer>
            </Modal>
        );
    }

    function BreakFDAssignmentModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Are you sure you want to <strong className='text-danger'>Break</strong> FD.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    {FDassignmentBreakModal && !FDapplicationAssigned ? <h3>FD Application not assigned to any scheme. Please Assign to view details.</h3> : <></>}
                    {FDassignmentBreakModal && FDapplicationAssigned ? <div className='row'>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">FD Account Number</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['fdAccountNumber'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['assignedAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Tenure (in months)</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['assignedTenure'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Rate</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['schemeId']['fdInterestRate'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Amount To Be Credited</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['interest'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">On-Maturity Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['onMaturityAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId" disabled
                                    value={FDBreakRecord ? dateFormat(FDBreakRecord['maturityDate'], "mmmm dS, yyyy") : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme ID</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['schemeId']['schemeId'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme Name</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDBreakRecord ? FDBreakRecord['schemeId']['fdName'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Total Days</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="totaldays"
                                    name="totaldays" disabled
                                    value={tillDay} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Amount Till Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="interestTillDate"
                                    name="interestTillDate" disabled
                                    value={interestTilldate} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Amount Till Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="Maturitytilldate"
                                    name="Maturitytilldate" disabled
                                    value={maturitytilldate} />
                            </div>
                        </div>
                        <p className='d-block text-center'>
                            You are about to break FD <strong>{FDBreakRecord ? FDBreakRecord['fdApplication']['applicationId'] : ""}</strong>. This process is irrevesable!
                        </p>
                    </div>

                        : <></>}

                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    {
                        FDassignmentBreakModal && !FDapplicationAssigned ?  
                        <Button variant="outline-secondary" onClick={() => { setFDAssignmentBreakModal(!FDassignmentBreakModal) }}>Cancel</Button> : <></>
                    }
                    {
                        FDassignmentBreakModal && FDapplicationAssigned ? <div>
                        <Button variant="danger" onClick={() => { breakFDRecordOnConfirm(FDBreakRecord); setFDAssignmentBreakModal(!FDassignmentBreakModal); }}>Confirm</Button>
                    <Button variant="outline-secondary" onClick={() => { setFDAssignmentBreakModal(!FDassignmentBreakModal) }}>Cancel</Button> </div>:
                    <></>
                    }
                    
                </Modal.Footer>
            </Modal>
        );
    }

    function SchemeChangeFDAssignmentModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Are you sure you want to <strong className='text-danger'>change scheme</strong> for FD.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    {FDassignmentSchemeChangeModal && !FDapplicationAssigned ? <h3>FD Application not assigned to any scheme. Please Assign to view details.</h3> : <></>}
                    {FDassignmentSchemeChangeModal && FDapplicationAssigned ? <div className='row'>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">FD Account Number</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['fdAccountNumber'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['assignedAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Tenure (in months)</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['assignedTenure'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Rate</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['schemeId']['fdInterestRate'] : ""} />
                            </div>
                        </div>
                        {/* <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Amount To Be Credited</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['interest'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">On-Maturity Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['onMaturityAmount'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId" disabled
                                    value={FDSchemeChangeRecord ? dateFormat(FDSchemeChangeRecord['maturityDate'], "mmmm dS, yyyy") : ""} />
                            </div>
                        </div> 
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Current Scheme ID</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['schemeId']['schemeId'] : ""} />
                            </div>
                        </div> */}
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Current Scheme Name</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={FDSchemeChangeRecord ? FDSchemeChangeRecord['schemeId']['fdName'] : ""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Total Days</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="totaldays"
                                    name="totaldays" disabled
                                    value={tillDay} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                        <label className="form-label">Updated Scheme</label>
                        <select className="form-select mb-3"
                            aria-label="Default select example"
                            id="FDSchemeName"
                            name="FDSchemeName"
                            onChange={handleFDSchemeName}
                            value={FDSchemeName}>
                            <option value="" key="" >Select</option>
                            {
                                allFDSchemes.map(e => <option
                                    value={e.schemeId} key={e.fdName}>{e.fdName}</option>)
                            }
                        </select>
                    </div>
                    <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Updated Interest</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="interestTillDate"
                                    name="interestTillDate" disabled
                                    value={FDUpdatedScheme?FDUpdatedScheme['fdInterestRate']:''} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Amount Till Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="interestTillDate"
                                    name="interestTillDate" disabled
                                    value={interestTilldate} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Amount Till Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="Maturitytilldate"
                                    name="Maturitytilldate" disabled
                                    value={maturitytilldate} />
                            </div>
                        </div>
                        <p className='d-block text-center'>
                            You are about to change scheme for FD <strong>{FDSchemeChangeRecord ? FDSchemeChangeRecord['fdApplication']['applicationId'] : ""}</strong>.
                        </p>
                    </div>

                        : <></>}

                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                {FDassignmentSchemeChangeModal && !FDapplicationAssigned ? 
                    <Button variant="outline-secondary" onClick={() => { setFDAssignmentSchemeChangeModal(!FDassignmentSchemeChangeModal) }}>Cancel</Button>
                    : <></>}
                    {FDassignmentSchemeChangeModal && FDapplicationAssigned ? <div>

                    <Button variant="danger" onClick={() => { updateSchemeFDRecordOnConfirm(FDSchemeChangeRecord); setFDAssignmentSchemeChangeModal(!FDassignmentSchemeChangeModal); getRows(10, 0); }}>Update</Button>
                    <Button variant="outline-secondary" onClick={() => { setFDAssignmentSchemeChangeModal(!FDassignmentSchemeChangeModal) }}>Cancel</Button> </div> : <></>
    }
                </Modal.Footer>
            </Modal>
        );
    }

    return (
        <div>
            {
                deleteModal && <DeleteModalView show={deleteModal} onHide={() => setDeleteModal(false)} />
            }
            {
                FDassignmentViewModal && <ViewFDAssignmentModalView show={FDassignmentViewModal} onHide={() => setFDAssignmentViewModal(false)} />
            }
            {
                FDassignmentBreakModal && <BreakFDAssignmentModalView show={FDassignmentBreakModal} onHide={() => setFDAssignmentBreakModal(false)} />
            }
            {
                FDassignmentSchemeChangeModal && <SchemeChangeFDAssignmentModalView show={FDassignmentSchemeChangeModal} onHide={() => setFDAssignmentSchemeChangeModal(false)} />
            }
            <div className="container-fluid">
                <div className='row'>
                    <div className='col-md-3'>
                        <div className="form-body">
                            <div className="row">
                                <div className="form-holder">
                                    <div className="form-content">
                                        <div className="form-items">
                                            <form className="requires-validation">
                                                <div className="col-md-12">
                                                    <label className='form-label color-white'>Filter Type</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="FDFilterType" name="FDFilterType"
                                                        onChange={handleFDFilterType}
                                                        value={FDFilterType}>
                                                        <option value="Select" key="Select">Select</option>
                                                        <option value="Get All" key="Get All">Get All</option>
                                                        <option value="FD Application ID" key="FD Application ID">FD Application ID</option>
                                                        <option value="Member ID" key="Member ID">Member ID</option>
                                                    </select>
                                                </div>
                                                {
                                                    FDFilterType == "Member ID" ?
                                                        <div className="col-md-12">
                                                            <label className='form-label color-white'>Member ID</label>
                                                            <input className="form-control my-1 fs-6"
                                                                id="memberId"
                                                                name="memberId"
                                                                autoComplete='off'
                                                                type="text"
                                                                placeholder="Member ID"
                                                                onChange={handleMemberId}
                                                                value={memberId} />
                                                        </div> : <></>
                                                }
                                                {
                                                    FDFilterType == "FD Application ID" ?
                                                        <div className="col-md-12">
                                                            <label className='form-label color-white'>FD Application ID</label>
                                                            <input className="form-control my-1 fs-6"
                                                                id="FDId"
                                                                name="FDId"
                                                                autoComplete='off'
                                                                type="text"
                                                                placeholder="FD Application ID"
                                                                onChange={handleFDId}
                                                                value={FDId} />
                                                        </div> : <></>
                                                }
                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => searchFDPlan()}>Search</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {
                        rowsData ? <div className='col-md-9 border-left'>
                            <br />
                            <div className='d-flex mb-2 flex-row-reverse'>
                                <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
                                    <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
                                    <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
                                    <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
                                </div>
                                <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
                                    <option value={5}>5</option>
                                    <option value={10}>10</option>
                                    <option value={25}>25</option>
                                    <option value={50}>50</option>
                                </select>
                            </div>
                            <div className="text-white bg-white grid-view" id='gridView'>
                                <DataGrid
                                    className=''
                                    rows={rowsData as any}
                                    columns={columnsList}
                                    pageSize={numberOfRows}
                                    getRowId={(row) => row.id}
                                    hideFooter={true}
                                />
                            </div>
                        </div> : <></>
                    }

                </div>
            </div>
        </div>
    );
}
