import React, { useState } from 'react';
import './fd.scss';
import {FixedDepositApplication} from './fd-application';
import MainService from '../../../services/main-service';
import { FDScheme } from './fd-scheme';
import { FDAssignment } from './fd-assignment';
import { FDSearch } from './fd-search';
import { FDBookKeeping } from './fd-Book-keeping';
import { FDCalculator } from './fd-calculator';

const mainService = new MainService("");

export const FixedDeposit = () => {

    var [currentFDModule, setCurrentFDModule] = React.useState('FDApplication');

    return( 
        <div>
        <ul className="nav nav-tabs" id="myTab" role="tablist">
          <li className="nav-item" role="presentation">
            <button className="nav-link active" 
            id="fdApplication-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdApplication" 
            type="button" role="tab" 
            aria-controls="fdApplication" 
            onClick={()=> setCurrentFDModule('FDApplication')} 
            aria-selected="true">
              FD Application
            </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="fdScheme-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdScheme" 
            type="button" 
            role="tab" 
            aria-controls="fdScheme" 
            onClick={()=> setCurrentFDModule('FDScheme')}
            aria-selected="false">
              FD Scheme
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="fdAssignment-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdAssignment" 
            type="button" 
            role="tab" 
            aria-controls="fdAssignment"
            onClick={()=> setCurrentFDModule('FDAssignment')}
            aria-selected="false">
              FD Assignment
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="fdSearch-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdSearch" 
            type="button" 
            role="tab" 
            aria-controls="fdSearch"
            onClick={()=> setCurrentFDModule('FDSearch')}
            aria-selected="false">
              FD Search
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="fdBookKeeping-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdBookKeeping" 
            type="button" 
            role="tab" 
            aria-controls="fdBookKeeping"
            onClick={()=> setCurrentFDModule('FDBookKeeping')}
            aria-selected="false">
              FD Book Keeping
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="fdCalculator-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#fdCalculator" 
            type="button" 
            role="tab" 
            aria-controls="fdCalculator"
            onClick={()=> setCurrentFDModule('FDCalculator')}
            aria-selected="false">
              FD Calculator
              </button>
          </li>
        </ul>
        <div className="tab-content" id="myTabContent">
          <div className='fd-application tab-pane fade show active'
            id="fdApplication"
            role="tabpanel"
            aria-labelledby="fdApplication-tab">
            {
              currentFDModule === "FDApplication" ? <FixedDepositApplication /> : <></>
            }
          </div>
          <div className="tab-pane fade"
            id="fdScheme"
            role="tabpanel"
            aria-labelledby="fdScheme-tab">
            {
              currentFDModule === "FDScheme" ? <FDScheme /> : <></>
            }
          </div>
          <div className="fd-assignment tab-pane fade"
            id="fdAssignment"
            role="tabpanel"
            aria-labelledby="fdAssignment-tab">
            {
              currentFDModule === "FDAssignment" ? <FDAssignment /> : <></>
            }
          </div>
          <div className="fd-search tab-pane fade"
            id="fdSearch"
            role="tabpanel"
            aria-labelledby="fdSearch-tab">
            {
              currentFDModule === "FDSearch" ? <FDSearch /> : <></>
            }
          </div>
          <div className="fdBookKeeping tab-pane fade"
            id="fdBookKeeping"
            role="tabpanel"
            aria-labelledby="fdBookKeeping-tab">
            {
              currentFDModule === "FDBookKeeping" ? <FDBookKeeping /> : <></>
            }
          </div>
          <div className="fdCalculator tab-pane fade"
            id="fdCalculator"
            role="tabpanel"
            aria-labelledby="fdCalculator-tab">
            {
              currentFDModule === "FDCalculator" ? <FDCalculator /> : <></>
            }
          </div>
        </div>
      </div>
    )
}