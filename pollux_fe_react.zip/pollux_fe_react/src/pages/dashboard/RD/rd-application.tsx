import React, { useState } from 'react';
import './rd.scss';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import stateArr from '../../../data/state.json';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro';

const mainService = new MainService("");

export const RDApplication = () => {

    var [showRDAlert, setShowRDAlert] = React.useState(false);
    var [alertMessage, setAlertMessage] = React.useState('');
    var [showRDSuccessDialog, setShowRDSuccessDialog] = React.useState(false);
    var [RDApplicationResponse, setRDApplicationResponse] = React.useState();
    var [commonRDMemberId, setRDCommonMemberId] = React.useState('');
    var [RDmemberName, setRDMemberName] = React.useState('');
    var [RDticketNumber, setRDTicketNumber] = React.useState('');
    var [RDsection, setRDSection] = React.useState('');
    var [RDpost, setRDPost] = React.useState('');
    var [RDpersonalNumber, setRDPersonalNumber] = React.useState('');
    var [RDcontactNumber, setRDContactNumber] = React.useState('');
    var [RDdob, setRDDOB] = React.useState('');
    var [RDmailingAddressLine1, setMailingAddressLine1] = React.useState('');
    var [RDmailingCity, setMailingCity] = React.useState('');
    var [RDmailingState, setMailingState] = React.useState('');
    var [RDmailingDistrict, setMailingDistrict] = React.useState('');
    var [RDmailingPinCode, setMailingPinCode] = React.useState('');
    var [RDmailingContact, setMailingContact] = React.useState('');
    var [RDpermanentAddressLine1, setPermanentAddressLine1] = React.useState('');
    var [RDpermanentCity, setPermanentCity] = React.useState('');
    var [RDpermanentState, setPermanentState] = React.useState('');
    var [RDpermanentDistrict, setPermanentDistrict] = React.useState('');
    var [RDpermanentPinCode, setPermanentPinCode] = React.useState('');
    var [RDpermanentContact, setPermanentContact] = React.useState('');
    var [RDAmount, setRDAmount] = React.useState('');
    var [RDmemberPhoto, setRDMemberPhoto] = React.useState('');
    var [RDmemberSignature, setRDMemberSignature] = React.useState('');
    var [memberData, setMemberData] = React.useState();
    var [disableSaveButtonForRD, setDisableSaveButtonForRD] = React.useState(true);
    var [RDYears, setRDYears] = React.useState('');
    var [RDMonths, setRDMonths] = React.useState('');
    var [createdOnDate, setCreatedOn] = React.useState('');
    


    async function getDetailsFromMemeberIDForRD() {
        try {
            let url = `member/${commonRDMemberId}`;
            let data = await mainService.getRequest(url, null, null);
            assignFormValues(data);
        } catch (e: any) {
            console.log(e)
        }
    }

    const assignFormValues = (data: any) => {
        data = data.data;
        setMemberData(data);
        setRDMemberName(data.personalDetail.firstName + " " + data.personalDetail.lastName);
        setRDTicketNumber(data.officialDetail.ticketNumber);
        setRDPost(data.officialDetail.post);
        setRDSection(data.officialDetail.section);
        let newD = dateFormat(data.personalDetail.dateOfBirth, "yyyy-mm-dd");
        setRDDOB(newD);
        setRDPersonalNumber(data.personalDetail.personalDetailId + "");
        setRDContactNumber(data.personalDetail.contactNumber);
        setRDMemberPhoto(data.memberPhoto);
        setRDMemberSignature(data.memberSignature);

        //address
        setMailingAddressLine1(data.memberAddress.mailing.addressLine1);
        setMailingCity(data.memberAddress.mailing.postOrCity);
        setMailingState(data.memberAddress.mailing.state);
        setMailingDistrict(data.memberAddress.mailing.district);
        setMailingPinCode(data.memberAddress.mailing.pinCode);
        setMailingContact(data.memberAddress.mailing.contact);
        setPermanentAddressLine1(data.memberAddress.permanent.addressLine1);
        setPermanentCity(data.memberAddress.permanent.postOrCity);
        setPermanentState(data.memberAddress.permanent.state);
        setPermanentDistrict(data.memberAddress.permanent.district);
        setPermanentPinCode(data.memberAddress.permanent.pinCode);
        setPermanentContact(data.memberAddress.permanent.contact);
        checkDisabilityOfSaveBtn();
    }

    function checkDisabilityOfSaveBtn() {
        if ((RDAmount && RDAmount != '')) {
            setDisableSaveButtonForRD(false);
        } else {
            setDisableSaveButtonForRD(true);
        }
    }

    const resetRDFormSubmition = () => {
        setRDCommonMemberId("");
        setRDMemberName(''); setRDTicketNumber(''); setRDSection(''); setRDPost(''); setRDPersonalNumber('');
        setRDContactNumber('');
        setRDDOB(''); setMailingAddressLine1(''); setMailingCity(''); setMailingState('');
        setMailingDistrict(''); setMailingPinCode(''); setMailingContact(''); setPermanentAddressLine1('');
        setPermanentCity(''); setPermanentState(''); setPermanentDistrict(''); setPermanentPinCode('');
        setPermanentContact(''); setRDAmount('');setRDYears('');setRDMonths('');setCreatedOn('');
    }

    async function checkRDFormSubmition() {
        let userInput = {
            "rdAmount": parseFloat(RDAmount),
            "tenure": RDMonths,
            "memberId": memberData ? memberData['memberId'] + "" : "",
            "createdOn" : createdOnDate
        }
        let url = "rd/application";
        let response = await mainService.postRequest(url, userInput, null);
        console.log(response);
        setRDApplicationResponse(response.data);
        if (response.status == 200) {
            setShowRDSuccessDialog(true);
            let obj : any = "";
            setMemberData(obj);
        }
        resetRDFormSubmition();
    }
    
    function closeAlert() {
        setShowRDAlert(false);
    }

    const closeRDApplicationModal = () => {
        setShowRDSuccessDialog(false);
        setDisableSaveButtonForRD(true);
    }
    //Handlers
    const handleRDCommonMemberId = (e: any) => {
        setRDCommonMemberId(e.target.value);
    }
    const handleRDMemberName = (e: any) => {
        setRDMemberName(e.target.value)
    }
    const handleRDTicketnumber = (e: any) => {
        setRDTicketNumber(e.target.value)
    }
    const handleRDSection = (e: any) => {
        setRDSection(e.target.value)
    }
    const handleRDPost = (e: any) => {
        setRDPost(e.target.value)
    }
    const handleRDPersonalNumber = (e: any) => {
        setRDPersonalNumber(e.target.value)
    }
    const handleRDContactNumber = (e: any) => {
        setRDContactNumber(e.target.value)
    }
    const handleRDDOB = (e: any) => {
        setRDDOB(e.target.value);
    }
    const handleMailingAddressLine1 = (e: any) => {
        setMailingAddressLine1(e.target.value);
    }
    const handleMailingCity = (e: any) => {
        setMailingCity(e.target.value);
    }
    const handleMailingDistrict = (e: any) => {
        setMailingDistrict(e.target.value);
    }
    const handleMailingState = (e: any) => {
        setMailingState(e.target.value);
    }
    const handleMailingPinCode = (e: any) => {
        setMailingPinCode(e.target.value);
    }
    const handleMailingContact = (e: any) => {
        setMailingContact(e.target.value);
    }
    const handlePermanentAddressLine1 = (e: any) => {
        setPermanentAddressLine1(e.target.value);
    }
    const handlePermanentCity = (e: any) => {
        setPermanentCity(e.target.value);
    }
    const handlePermanentDistrict = (e: any) => {
        setPermanentDistrict(e.target.value);
    }
    const handlePermanentState = (e: any) => {
        setPermanentState(e.target.value);
    }
    const handlePermanentPinCode = (e: any) => {
        setPermanentPinCode(e.target.value);
    }
    const handlePermanentContact = (e: any) => {
        setPermanentContact(e.target.value);
    }
    const handleRDAmount = (e: any) => {
        setRDAmount(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleRDYears = (e: any) => {
        setRDYears(e.target.value);
    }
    const handleRDMonths = (e: any) => {
        setRDMonths(e.target.value);
    }
    const handleCreatedOnDate = (e: any) => {
        setCreatedOn(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    return (
        <div>
            <br />
            {
                showRDAlert ?
                    <div className="d-flex justify-content-end my-4cphx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessage}</span>
                                <button aria-label="Close" className='close close-position' type='button' data-dismiss="alert" onClick={() => closeAlert()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
            {
                showRDSuccessDialog ?
                    <div className="modal" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">RD Application Saved</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeRDApplicationModal()}></button>
                                </div>
                                <div className="modal-body">
                                    {
                                        RDApplicationResponse ?
                                            <div>
                                                <div>
                                                    <span><strong>RD Application ID: </strong></span>
                                                    <span>{RDApplicationResponse['applicationId']}</span>
                                                </div>
                                                <div>
                                                    <span><strong>Application Date: </strong></span>
                                                    <span>{dateFormat(RDApplicationResponse['createdOn'], "mmmm dS, yyyy, h:MM:ss TT")}</span>
                                                </div>
                                            </div> : <></>
                                    }
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div id="seperate-loan-box">
                <div className='container-fluid'>
                    <div className="row">
                        <div className="col-lg-3"></div>
                        <div className="col-lg-6">
                            <div className="common-member-box">
                                <div className="input-group mx-5">
                                    <input type="text"
                                        className="form-control"
                                        autoComplete='off'
                                        id="commonMemberID"
                                        name="commonMemberID"
                                        placeholder="Member ID"
                                        onChange={handleRDCommonMemberId}
                                        value={commonRDMemberId}
                                        aria-label="Member ID"
                                        aria-describedby="button-addon2" />
                                    <button
                                        className="btn btn-outline-light"
                                        type="button"
                                        onClick={() => getDetailsFromMemeberIDForRD()}>
                                        Get Details</button>
                                </div>
                                <button type="button" id="saveApplication"
                                    className="btn btn-outline-light"
                                    disabled={disableSaveButtonForRD}
                                    onClick={() => checkRDFormSubmition()}>
                                    Save
                                </button>
                                <button type="button" id="resetApplication"
                                    className="btn btn-outline-light mx-3"
                                    // disabled={disableSaveButton}
                                    onClick={() => resetRDFormSubmition()}>
                                    Reset
                                </button>
                            </div>

                        </div>
                    </div>

                </div>
                <br />
                { memberData ?
                <div className='adjustRD-height'>
                <div className="accordion" id="accordionPersonalDetails">
                    <div className="accordion-item">
                        <h2 className="accordion-header" id="personalDetails">
                            <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePersonalDetails" aria-expanded="true" aria-controls="collapsePersonalDetails">
                                Personal Details
                            </button>
                        </h2>
                        <div id="collapsePersonalDetails" className="accordion-collapse collapse show" aria-labelledby="personalDetails" data-bs-parent="#accordionPersonalDetails">
                            <div className="accordion-body">
                                <table className='table'>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div className="container-fluid">
                                                    <div className="row">
                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Member Name</label>
                                                                <input type="text"
                                                                    className="form-control"
                                                                    id="memberName"
                                                                    autoComplete='off'
                                                                    name="memberName"
                                                                    placeholder="Member Name"
                                                                    onChange={handleRDMemberName}
                                                                    value={RDmemberName} disabled readOnly />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Ticket Number</label>
                                                                <input type="text" className="form-control"
                                                                    id="ticketNumber"
                                                                    autoComplete='off'
                                                                    name="ticketNumber"
                                                                    placeholder="Ticket Number"
                                                                    onChange={handleRDTicketnumber}
                                                                    value={RDticketNumber} disabled readOnly />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Section</label>
                                                                <input type="text"
                                                                    className="form-control"
                                                                    id="section"
                                                                    autoComplete='off'
                                                                    name="section"
                                                                    placeholder="Section"
                                                                    onChange={handleRDSection}
                                                                    value={RDsection} disabled readOnly />
                                                            </div>
                                                        </div>

                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Post</label>
                                                                <input type="text"
                                                                 autoComplete='off'
                                                                    className="form-control"
                                                                    id="post" name="post"
                                                                    placeholder="Post"
                                                                    onChange={handleRDPost}
                                                                    value={RDpost} disabled readOnly />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Personal Number</label>
                                                                <input type="text"
                                                                    className="form-control"
                                                                    autoComplete='off'
                                                                    id="personalNumber" name="personalNumber"
                                                                    placeholder="Personal Number"
                                                                    onChange={handleRDPersonalNumber}
                                                                    value={RDpersonalNumber} disabled readOnly />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Contact Number</label>
                                                                <input type="text"
                                                                    className="form-control"
                                                                    autoComplete='off'
                                                                    id="contactNumber" name="contactNumber"
                                                                    placeholder="Phone No."
                                                                    onChange={handleRDContactNumber}
                                                                    value={RDcontactNumber} disabled readOnly />
                                                            </div>
                                                        </div>

                                                        <div className="col-lg-3">
                                                            <div className='pd-b-10 pd-r-5'>
                                                                <label className="form-label">Date Of Birth</label>
                                                                <input className="form-control"
                                                                    id="dateOfBirth"
                                                                    name="dateOfBirth"
                                                                    autoComplete='off'
                                                                    type="Date"
                                                                    onChange={handleRDDOB}
                                                                    value={RDdob}
                                                                    placeholder="Date of Birth"
                                                                    disabled readOnly
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <img className='uploaded-images' 
                                                src={`data:image/png;image/jpg;image/jpeg;base64,${RDmemberPhoto}`} 
                                                alt="" srcSet="" />
                                                <br />
                                                <img className='uploaded-images' 
                                                src={`data:image/png;image/jpg;image/jpeg;base64,${RDmemberSignature}`} 
                                                alt="" srcSet="" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div className="accordion" id="accordionAddressDetails">
                                    <div className="accordion-item">
                                        <h2 className="accordion-header" id="rdAddress">
                                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwow" aria-expanded="true" aria-controls="collapseTwow">
                                                Address
                                            </button>
                                        </h2>
                                        <div id="collapseTwow" className="accordion-collapse collapse show" data-bs-parent="#accordionAddressDetails">
                                            <div className="accordion-body">
                                                <div className="container-fluid">
                                                    <div className="row">
                                                        <div className="col-lg-12">
                                                            <form>

                                                                <div className='row g-3'>
                                                                    <div className="col-md-6">
                                                                        <div className="row">
                                                                            <div className="col-12">
                                                                                <label htmlFor="title">Mailing Address</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailingAddressLine1"
                                                                                    autoComplete='off'
                                                                                    name="mailingAddressLine1"
                                                                                    type="text"
                                                                                    onChange={handleMailingAddressLine1}
                                                                                    value={RDmailingAddressLine1}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">City</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailingCity"
                                                                                    autoComplete='off'
                                                                                    name="mailingCity"
                                                                                    type="text"
                                                                                    onChange={handleMailingCity}
                                                                                    value={RDmailingCity}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">District</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailingDistrict"
                                                                                    name="mailingDistrict"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    onChange={handleMailingDistrict}
                                                                                    value={RDmailingDistrict}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">State</label>
                                                                                <select className="form-select" id="mailingState"
                                                                                    name="mailing.state" onChange={handleMailingState} value={RDmailingState} disabled>
                                                                                    <option value="">--Select--</option>
                                                                                    {
                                                                                        stateArr.map((element) => {
                                                                                            return <option value={element.state}>{element.state}</option>
                                                                                        })
                                                                                    }
                                                                                </select>
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Country</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailing.country"
                                                                                    name="mailing.country"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    value="India"
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Pincode</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailing.pinCode"
                                                                                    name="mailing.pinCode"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    onChange={handleMailingPinCode}
                                                                                    value={RDmailingPinCode}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Contact No.</label>
                                                                                <input className="form-control my-1"
                                                                                    id="mailing.contact"
                                                                                    name="mailing.contact"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    onChange={handleMailingContact}
                                                                                    value={RDmailingContact}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            {/* <div className="col-12">
                                    <input type="checkbox" name="sameAddress" onChange={() => setSameAddressValue()} />
                                    <label className="form-check-label ps-2" htmlFor="inlineRadio1">Keep Mailing Address as Permanent Address</label>
                                  </div> */}
                                                                        </div>
                                                                    </div>
                                                                    <div className="col-md-6">
                                                                        <div className="row">
                                                                            <div className="col-12">
                                                                                <label htmlFor="title">Permanent Address</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.addressLine1"
                                                                                    name="permanent.addressLine1"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    onChange={handlePermanentAddressLine1}
                                                                                    value={RDpermanentAddressLine1}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">City</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.postOrCity"
                                                                                    autoComplete='off'
                                                                                    name="permanent.postOrCity"
                                                                                    type="text"
                                                                                    onChange={handlePermanentCity}
                                                                                    value={RDpermanentCity}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">District</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.district"
                                                                                    autoComplete='off'
                                                                                    name="permanent.district"
                                                                                    type="text"
                                                                                    onChange={handlePermanentDistrict}
                                                                                    value={RDpermanentDistrict}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">State</label>
                                                                                <select className="form-select" id="mailing.state"
                                                                                    name="mailing.state" onChange={handlePermanentState} value={RDpermanentState} disabled>
                                                                                    <option value="">--Select--</option>
                                                                                    {
                                                                                        stateArr.map((element) => {
                                                                                            return <option value={element.state}>{element.state}</option>
                                                                                        })
                                                                                    }
                                                                                </select>
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Country</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.country"
                                                                                    name="permanent.country"
                                                                                    type="text"
                                                                                    autoComplete='off'
                                                                                    value="India"
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Pincode</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.pinCode"
                                                                                    name="permanent.pinCode"
                                                                                    autoComplete='off'
                                                                                    type="text"
                                                                                    onChange={handlePermanentPinCode}
                                                                                    value={RDpermanentPinCode}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>
                                                                            <div className="col-6">
                                                                                <label htmlFor="title">Contact No.</label>
                                                                                <input className="form-control my-1"
                                                                                    id="permanent.contact"
                                                                                    autoComplete='off'
                                                                                    name="permanent.contact"
                                                                                    type="text"
                                                                                    onChange={handlePermanentContact}
                                                                                    value={RDpermanentContact}
                                                                                    disabled readOnly
                                                                                />
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div></div>

                            </div>
                        </div>
                    </div>
                </div>
                <br></br>
                <div className="accordion" id="accordionAccountDetails">
                    <div className="accordion-item">
                        <h2 className="accordion-header" id="accountDetails">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAccountDetails" aria-expanded="false" aria-controls="collapseAccountDetails">
                                Account Details
                            </button>
                        </h2>
                        <div id="collapseAccountDetails" className="accordion-collapse collapse" aria-labelledby="accountDetails" data-bs-parent="#accordionAccountDetails">
                            <div className="accordion-body">
                                <div className='container-fluid'>
                                    <div className='row'>
                                        <div className="col-lg-3">
                                            <div className='pd-b-10'>
                                                <label className="form-label">RD Amount (monthly)</label>
                                                <input type="text"
                                                    className="form-control"
                                                    id="RDAmount"
                                                    autoComplete='off'
                                                    name="RDAmount"
                                                    placeholder="RD Amount"
                                                    onChange={handleRDAmount}
                                                    value={RDAmount} />
                                            </div>
                                        </div>
                                        <div className="col-lg-3">
                                            <div className='pd-b-10'>
                                                <label className="form-label">Tenure (in months)</label>
                                                <div>
                                                    {/* <input type="text"
                                                        className="form-control tenure-inline"
                                                        id="RDYears"
                                                        autoComplete='off'
                                                        name="RDYears"
                                                        placeholder="Years"
                                                        onChange={handleRDYears}
                                                        value={RDYears} /> */}
                                                    <input type="text"
                                                        className="form-control"
                                                        id="RDMonths"
                                                        name="RDMonths"
                                                        autoComplete='off'
                                                        placeholder="Months"
                                                        onChange={handleRDMonths}
                                                        value={RDMonths} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Created On</label>
                                            <input className="form-control my-1"
                                                id="createdOnDate"
                                                autoComplete='off'
                                                name="createdOnDate"
                                                type="Date"
                                                onChange={handleCreatedOnDate}
                                                value={createdOnDate}
                                                placeholder="Created On"
                                            />
                                        </div>
                                    </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
                : <></>}
                
            </div>
        </div>
    )
}