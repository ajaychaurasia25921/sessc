import React, { useState } from 'react';
import './rd.scss';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";


const mainService = new MainService("");

export const RDAssignment = () => {

    var [RDApplicationId, setRDApplicationId] = React.useState('');
    var [RDSchemeId, setRDSchemeId] = React.useState('');
    var [responseRDScheme, setResponseRDScheme] = React.useState();
    var [responseRDApplication, setResponseRDApplication] = React.useState();
    var [RDAmount, setRDAmount] = React.useState('');
    var [tenure, setTenure] = React.useState('');
    var [interestRate, setInterestRate] = React.useState('');
    var [RDSchemeName, setRDSchemeName] = React.useState('');
    var [alertMessageAssignmentTab, setAlertMessageAssignmentTab] = React.useState('');
    var [showAlertAssignmentTab, setShowAlertAssignmentTab] = React.useState(false);
    var [allRDSchemes, setAllRDSchemes] = React.useState(Array<any>());
    var [maturityAmount, setMaturityAmount] = React.useState('');
    var [RDYears, setRDYears] = React.useState('');
    var [RDMonths, setRDMonths] = React.useState('');
    var [RDRemark, setRDRemark] = React.useState('');
    var [totalInstallments, setTotalInstallments] = React.useState('');
    var [interestAmount, setInterestAmount] = React.useState('');
    var [showSuccessDialogRD, setShowSuccessDialogRD] = React.useState(false);
    var [showAssignBtnRD, setShowAssignBtnRD] = React.useState(false);
    var [RDAssignmentResponse, setRDAssignmentResponse] = React.useState();

    React.useEffect(() => {
        getAllRDSchemes();
    }, []);

    React.useEffect(()=> {
        if (RDAmount && RDMonths && interestRate) {
            let newRDAmount = parseInt(RDAmount);
            let newTenure = parseFloat(RDMonths);
            let newRate = parseFloat(interestRate);

            let interestCalculationCount = parseInt(newTenure / 6 + "");
            let finalMaturityAmout: any;
            let currentBal: number = 0;
            let totalInterest = 0;
            for(let i=0;i<interestCalculationCount;i++) {
                finalMaturityAmout = cal(newRDAmount, newRate, 6, currentBal, newTenure);
                console.log("mat1 ",finalMaturityAmout['currentBalance'])
                console.log("int1 ",finalMaturityAmout['intrestOnPeriod'])

                currentBal = finalMaturityAmout['currentBalance'] + finalMaturityAmout['intrestOnPeriod'];
                totalInterest = totalInterest + finalMaturityAmout['intrestOnPeriod'];
            }

            // let maturityAmount = ((newRDAmount * newTenure) + totalInterest);
            let intAmount = totalInterest;
            // if((maturityAmount+ "").includes(".")) {
            //     let arr = (maturityAmount+"").split(".");
            //     maturityAmount = Math.round(maturityAmount)
            // } else {
            //     calculatedInterestAmount = calculatedInterestAmount;
            // }
            console.log("intAmout   ",intAmount);
            if((intAmount+ "").includes(".")) {
                let arr = (intAmount+"").split(".");
                intAmount = roundOff(arr[0],intAmount);
            } else {
                intAmount = roundOff(intAmount+"", intAmount);
            }

            setMaturityAmount(((newRDAmount * newTenure) + intAmount) + "");
            setInterestAmount(intAmount + "");
            setTotalInstallments(newTenure+"");
        }
    }, [RDAmount,RDMonths, interestRate])

    function roundOff(value: string, amount: number) {
        console.log("length",value.length)
        if(value.length == 2) {
            return Math.round(amount);
        }
        if(value.length >= 3) {
            return Math.round(amount/10)*10;
        }
        // if(value.length == 4) {
        //     return Math.round(amount/100)*100;
        // }
        // if(value.length == 5) {
        //     return Math.round(amount/1000)*1000;
        // }
        // if(value.length == 6) {
        //     return Math.round(amount/10000)*10000;
        // }
        // if(value.length == 7) {
        //     return Math.round(amount/100000)*100000;
        // }
        // if(value.length == 8) {
        //     return Math.round(amount/1000000)*1000000;
        // }
        return 0;
    }

    function cal(amount: any, interest: number, period: number, currentAmount:number, newTenure: number) {
        console.log("new Amount",currentAmount)
        let newPeriodAmount: any = currentAmount;
        let tempPeriodAmount = 0;
        for(let i=0;i<period;i++) {
            newPeriodAmount = newPeriodAmount + amount;
            tempPeriodAmount = tempPeriodAmount + newPeriodAmount;
        }
        console.log(tempPeriodAmount);
        let intrestOnPeriod = (tempPeriodAmount * interest) / (100 * newTenure);
        return {"intrestOnPeriod": intrestOnPeriod, "currentBalance": newPeriodAmount};
    }

    async function getAllRDSchemes() {
        let url = `rd/scheme`;
        try {
            let response = await mainService.getRequest(url, null, null);
            setAllRDSchemes(response.data.content);
        } catch (e: any) {
            console.log(e)
        }
    }

    async function getRDAssignmentDetails() {
        console.log(RDSchemeName);
        let url = `rd/application/${RDApplicationId}`;
        let response1 = await mainService.getRequest(url, null, null);
        setResponseRDApplication(response1.data);
        let url1: string = "";
        if (RDSchemeId) {
            url1 = `rd/scheme/${RDSchemeId}`;
        }
        if (RDSchemeName) {
            url1 = `rd/scheme/${RDSchemeName}`;
        }
        if (RDSchemeId == "" && RDSchemeName == "") {
            setAlertMessageAssignmentTab("Provide Scheme ID or Scheme Name.");
            setShowAlertAssignmentTab(true);
            setTimeout(() => {
                setShowAlertAssignmentTab(false);
            }, 5000);
            return;
        }
        if (response1.data['status'] && response1.data['status'] == "Approved") {
            setAlertMessageAssignmentTab("RD Application already assigned.");
            setShowAlertAssignmentTab(true);
            setTimeout(() => {
                setShowAlertAssignmentTab(false);
            }, 5000);
            return;
        }

        let response2 = await mainService.getRequest(url1, null, null);
        setResponseRDScheme(response2.data);
        setRDAmount(response1.data['rdAmount']);
        setTenure(response1.data['tenure']);
        setInterestRate(response2.data.rdInterestRate);
        setTotalInstallments(response1.data['tenure']);
        setRDMonths(response1.data['tenure']);
        setShowAssignBtnRD(true);
    }

    async function assignRDDetils() {
        let payload = {
            "status": "Approved",
            "rdApplication": responseRDApplication,
            "schemeId": responseRDScheme,
            "assignedAmount": parseFloat(RDAmount),
            "assignedTenure": tenure,
            "interest": parseFloat(interestAmount),
            "onMaturityAmount": parseFloat(maturityAmount),
            "remark": RDRemark
        }
        let url = `rd/assignment`
        let response = await mainService.postRequest(url, payload, null);
        if(response.status == 200) {
            setRDAssignmentResponse(response.data);
            setShowSuccessDialogRD(true);
            let anyObj: any = ""
        setResponseRDApplication(anyObj);
        setResponseRDScheme(anyObj);
        setShowAssignBtnRD(false);
        } else {
            setAlertMessageAssignmentTab("Something went wrong. Please try again.");
            setShowAlertAssignmentTab(true);
            setTimeout(() => {
                setShowAlertAssignmentTab(false);
            }, 5000);
        }
        console.log(response);
    }

    
    const closeRDAssignmentModal = () => {
        setShowSuccessDialogRD(false);
    }


    const handleRDApplicationId = (e: any) => {
        setRDApplicationId(e.target.value);
    }

    const handleRDSchemeId = (e: any) => {
        setRDSchemeId(e.target.value);
    }
    const handleRDAmount = (e: any) => {
        setRDAmount(e.target.value);
    }
    const handleTenure = (e: any) => {
        setTenure(e.target.value);
    }
    const handleInterestRate = (e: any) => {
        setInterestRate(e.target.value);
    }
    const handleRDSchemeName = (e: any) => {
        setRDSchemeName(e.target.value);
    }
    const handleMaturityAmount = (e: any) => {
        setMaturityAmount(e.target.value);
    }
    const handleRDYears = (e: any) => {
        setRDYears(e.target.value);
    }
    const handleRDMonths = (e: any) => {
        setRDMonths(e.target.value);
    }
    const handleRDRemark = (e: any) => {
        setRDRemark(e.target.value);
    }
    const closeAlertAssignTab = () => {
        setShowAlertAssignmentTab(false);
    }
    const handleTotalInstallments = (e:any) => {
        setTotalInstallments(e.target.value);
    }
    const handleInterestAmount = (e:any) => {
        setInterestAmount(e.target.value);
    }

    return(
        <div className='rd-assignment my-3'>
            {
                showAlertAssignmentTab ?
                    <div className="d-flex justify-content-end my-4cphx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessageAssignmentTab}</span>
                                <button aria-label="Close"
                                    className='close close-position'
                                    type='button' data-dismiss="alert"
                                    onClick={() => closeAlertAssignTab()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
                        {
                showSuccessDialogRD ?
                    <div className="modal" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">RD Application Saved</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeRDAssignmentModal()}></button>
                                </div>
                                <div className="modal-body">
                                    {
                                        RDAssignmentResponse ?
                                        <div>
                                            <div>
                                                <span><strong>RD ID: </strong></span>
                                                <span>{RDAssignmentResponse['rdId']}</span>
                                            </div>
                                            <div>
                                            <span><strong>RD Assignment Creation Date: </strong></span>
                                                <span>{dateFormat(RDAssignmentResponse['createdOn'], "mmmm dS, yyyy, h:MM:ss TT")}</span>
                                                </div>
                                                <div>
                                                <span><strong>RD Assignment Created By: </strong></span>
                                                <span>{RDAssignmentResponse['createdBy']}</span>
                                                </div>
                                            </div> : <></>
          }
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className='container-fluid'>
                <div className='row my-2'>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">RD Application ID</label>
                        <input type="text" autoComplete='off'
                            className="form-control"
                            id="RDApplicationId"
                            name="RDApplicationId"
                            placeholder="RD Application Id"
                            onChange={handleRDApplicationId}
                            value={RDApplicationId} />
                    </div>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">RD Scheme ID</label>
                        <input type="text" autoComplete='off'
                            className="form-control"
                            id="RDSchemeId"
                            name="RDSchemeId"
                            placeholder="RD Scheme Id"
                            onChange={handleRDSchemeId}
                            value={RDSchemeId} />
                    </div>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">RD Scheme Name</label>
                        <select className="form-select mb-3"
                            aria-label="Default select example"
                            id="RDSchemeName"
                            name="RDSchemeName"
                            onChange={handleRDSchemeName}
                            value={RDSchemeName}>
                            <option value="" key="" >Select</option>
                            {
                                allRDSchemes.map(e => <option
                                    value={e.schemeId} key={e.rdName}>{e.rdName}</option>)
                            }
                        </select>
                    </div>
                    <div className='col-lg-3'>
                        <button
                            className="btn btn-outline-light mt-4"
                            type="button"
                            onClick={() => getRDAssignmentDetails()}>Go</button>
                    </div>
                </div>

                {
                    responseRDScheme && responseRDApplication ? <div>
                        <div className='row assignment-application-box my-3 p-2'>
                            {/* <div className="assignment-application-box my-3 p-3"> */}
                            <div className='col-lg-6 side-border'>
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>RD Amount: </strong>{responseRDApplication ? responseRDApplication['rdAmount'] : ''}</span>
                                    </div>
                                    <div className='col-lg-6'>
                                        <span><strong>Tenure: </strong>
                                            {responseRDApplication ?
                                                responseRDApplication['tenure'] + " months" : ''}
                                        </span>
                                    </div>
                                </div>
                    </div>
                    <div className='col-lg-6'>
                    <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>RD Scheme: </strong>{responseRDScheme ? responseRDScheme['rdName'] : ''}</span>
                                    </div>
                                    <div className='col-lg-6'>
                                        <span className='ml-6'><strong>Interest Rate: </strong>{responseRDScheme ? responseRDScheme['rdInterestRate'] : ''}%</span>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>Max Tenure: </strong>{responseRDScheme ? responseRDScheme['tenure'] + " months" : ''}</span>
                                    </div>

                                </div>
                    </div>
                            {/* </div> */}
                        </div>
                    </div> : <></>
                }
                {responseRDScheme && responseRDApplication ? <div>
                    <div className='row my-2'>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">RD Amount (Monthly Deposit)</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="RDAmount"
                                name="RDAmount"
                                placeholder="RD Amount"
                                onChange={handleRDAmount}
                                value={RDAmount}/>
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">
                                Tenure (in months)</label>
                            <div>
                                {/* <input type="text" autoComplete='off'
                                    className="form-control tenure-inline"
                                    id="RDYears"
                                    name="RDYears"
                                    placeholder="Years"
                                    onChange={handleRDYears}
                                    value={RDYears} /> */}
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="RDMonths"
                                    name="RDMonths"
                                    placeholder="Months"
                                    onChange={handleRDMonths}
                                    value={RDMonths} />
                            </div>
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Interest Rate</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="interestRate"
                                name="interestRate"
                                placeholder="Interest Rate"
                                onChange={handleInterestRate}
                                value={interestRate} />
                        </div>
                        {/* <div className='col-lg-3'>
                            <label className="form-label color-white">Payment Mode</label>
                            <select className="form-select mb-3"
                                id="paymentMode" name="paymentMode"
                                onChange={handlePaymentMode}
                                value={paymentMode}>
                                <option value="" key="" >Select</option>
                                <option value="Salary" key="Salary" >Salary</option>
                                <option value="Self" key="Self" >Self</option>
                            </select>
                        </div> */}
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Total Installments</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="totalInstallments"
                                name="totalInstallments"
                                placeholder="Total Installments"
                                onChange={handleTotalInstallments}
                                value={totalInstallments} disabled />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Interest Amount</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="interestAmount"
                                name="interestAmount"
                                placeholder="Interest Amount"
                                onChange={handleInterestAmount}
                                value={interestAmount} disabled />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Maturity Amount</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="maturityAmount"
                                name="maturityAmount"
                                placeholder="Maturity Amount"
                                onChange={handleMaturityAmount}
                                value={maturityAmount} disabled />
                        </div>
                    </div>
                    <div className='row my-2'><div className='col-lg-12'>
                        <label className='form-label color-white'>Remark</label>
                        <textarea className="form-control my-1 fs-6"
                            name="RDRemark" rows={3}
                            placeholder="Remark"
                            onChange={handleRDRemark}
                            value={RDRemark} /></div>
                    </div></div>
                    : <></>

                }
{
    showAssignBtnRD?
                <div className='row my-2'>
                    <div className='col-lg-5'></div>
                    <div className='col-lg-1'>
                        <button
                            className="btn btn-outline-light"
                            type="button"
                            onClick={() => assignRDDetils()}>Assign</button>
                    </div>

                </div> : <></>
                }
            </div>
        </div>
    )
}