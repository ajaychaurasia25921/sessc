import React, { useState } from 'react';
import './rd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");
// const columnsList: GridColDef[] = [
//     { field: 'id', headerName: 'Txn Id', width: 110 },
//     { field: 'accountId', headerName: 'Account Id', width: 150 },
//     { field: 'amount', headerName: 'Amount', width: 150 },
//     { field: 'balance', headerName: 'Balance', width: 150 },
//     { field: 'mode', headerName: 'Mode', width: 150 },
//     { field: 'indicator', headerName: 'DR | CR.', width: 150 },
//     { field: 'fundingAccount', headerName: 'Funding Account', width: 150},
//     { field: 'notes', headerName: 'Notes', width: 150 },
//     { field: 'createdOn', headerName: 'Created On', width: 150 },
//     { field: 'createdBy', headerName: 'Created By', width: 150 },
//   ];
  type RowsObj = {
    memberId: string,
    name: string,
    ticket: string,
    personalNumber: string, 
    id: string, 
    amount: number,
    interest: number,
    intAmount: number,
    onMaturityAmount: number,
    mode: string,
    tenure: string,
    fundingAccount: string, 
    indicator: string, 
    notes: string, 
    createdOn: string, 
    createdBy: string, 
    accountId: string 
}


export const RDBookKeeping = (props: any) => {

    var [filterType, setFilterType] = React.useState('');
    var [fundingAccount, setFundingAccount] = React.useState('');
    var [paymentMode, setPaymentMode] = React.useState('');
    var [notes, setNotes] = React.useState('');
    const [rowsData, setRows] = React.useState(Array<any>());
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [showAlert, setShowAlert] = React.useState(false);
    var [alertMessage, setAlertMessage] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [post, setPost] = React.useState('');
    var [section, setSection] = React.useState('');
    var [staffType, setStaffType] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [checkedRecords, setCheckedRecords] = React.useState(Array<any>());
    var [showEditDialog, setShowEditDialog] = React.useState(false);
    var [recordOpened, setRecordOpened] = React.useState();

    React.useEffect(() => {
        // console.log(rowsData)
    }, [rowsData]);

    React.useEffect(() => {
        setRows([]);
    }, [filterType]);

    const handleFilterType = (e: any) => {
        setFilterType(e.target.value);
    }
    const handlePost = (e: any) => {
        setPost(e.target.value);
    }
    const handleSection = (e: any) => {
        setSection(e.target.value);
    }
    const handleStaffType = (e: any) => {
        setStaffType(e.target.value);
    }
    const handlePaymentMode = (e: any) => {
        setPaymentMode(e.target.value);
        if(e.target.value == "Cash" || e.target.value == "Cash_Transfer_Account") {
            setFundingAccount("CASH_IN_HAND");
        } else {
            setFundingAccount("SBI")    
        }
    }
    const handleFundingAccount = (e: any) => {
        setFundingAccount(e.target.value);
    }
    const handleNotes = (e: any) => {
        setNotes(e.target.value);
    }

    const columnsList: GridColDef[] = [
        { field: 'memberId', headerName: 'ID', width: 60 },
        { field: 'name', headerName: 'Name', width: 180 },
        { field: 'personalNumber', headerName: 'Personal Number', width: 110 },
        { field: 'ticket', headerName: 'Ticket Number', width: 110 },
        { field: 'id', headerName: 'RD Application ID', width: 110 },
        { field: 'amount', headerName: 'RD Amount', width: 150 },
        // { field: 'tenure', headerName: 'Tenure(in months)', width: 150 },
        // { field: 'interest', headerName: 'Rate Of Interest', width: 150 },
        // { field: 'intAmount', headerName: 'Estimated Returns', width: 150 },
        // { field: 'onMaturityAmount', headerName: 'On-Maturity Amount', width: 150 },    
        { field: 'indicator', headerName: 'DR | CR.', width: 150 },
        { field: 'mode', headerName: 'Payment Mode', width: 150 },
        { field: 'fundingAccount', headerName: 'Funding Account', width: 150 },
        { field: 'notes', headerName: 'Notes', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        {
            field: 'action',
            width: 130,
            sortable: false,

            renderCell: (params) => {
                function onClickEdit() {
                    setShowEditDialog(true);
                    setRecordOpened(params.row);
                    setFundingAccount(params.row.fundingAccount)
                    setPaymentMode(params.row.mode);
                    setNotes(params.row.notes);
                }

                return (
                    <>
                        <FontAwesomeIcon className='fa-icon-table' icon={solid('pencil')} onClick={() => onClickEdit()} />
                    </>
                );
            },
        }
    ];

    const handleMemberId = (e: any) => {
        setMemberId(e.target.value);
    }


    async function FilterRDAssignmentData() {
        try {
            if (filterType == "memberwise") {
                let tempurl = `rd/assignment/member?memberId=${memberId}`;
                let response = await mainService.getRequest(tempurl, null, null);
                let index = 0;
                for(let s of response.data) {
                    let nextUrl = `member/official_detail/${s.rdApplication.memberId}`;
                    let nextresponse = await mainService.getRequest(nextUrl, null, null);
                    response.data[index].name = nextresponse.data.firstName+" "+nextresponse.data.lastName;
                    response.data[index].personalNumber = nextresponse.data.personalNumber;
                    response.data[index].ticketNumber = nextresponse.data.ticketNumber;
                    index++;
                }                
                getRows(response);
            } else {
                let tempurl = `rd/assignment/group`;
                let obj = {
                    "post": post? post: null,
                    "section": section? section: null,
                    "staff": staffType? staffType: null
                };

                let response = await mainService.postRequest(tempurl, obj, null);
                let index = 0;
                for(let s of response.data) {
                    let nextUrl = `member/official_detail/${s.rdApplication.memberId}`;
                    let nextresponse = await mainService.getRequest(nextUrl, null, null);
                    response.data[index].name = nextresponse.data.firstName+" "+nextresponse.data.lastName;
                    response.data[index].personalNumber = nextresponse.data.personalNumber;
                    response.data[index].ticketNumber = nextresponse.data.ticketNumber;
                    index++;
                }
                getRows(response);
            }
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function getRows(response: any) {
        let abc: any = [];
        try {
            setNumberOfRows(response.data.size);
            setRows(abc);
            abc = Object.assign([], abc);

            response.data.forEach( async (element: any) => {
                let calculatedInterestAmount = 0;
                let calculatedPrincipleDeduction = 0;

                // calculatedPrincipleDeduction = element.principleAmount / element.remainingTenure;
                // calculatedInterestAmount = (element.principleAmount * element.schemeId.maxInterestRate) / (12 * 100);
                // console.log("p", calculatedPrincipleDeduction);
                // console.log("i", calculatedInterestAmount);

                // if((calculatedInterestAmount+ "").includes(".")) {
                //     calculatedInterestAmount = Math.round(calculatedInterestAmount)
                // } else {
                //     calculatedInterestAmount = calculatedInterestAmount;
                // }
 
                // if((calculatedPrincipleDeduction+ "").includes(".")) {
                //     let arr = (calculatedPrincipleDeduction+"").split(".");
                //     calculatedPrincipleDeduction = roundOff(arr[0], calculatedPrincipleDeduction);
                // } else {
                //     calculatedPrincipleDeduction = roundOff(calculatedPrincipleDeduction+"", calculatedPrincipleDeduction);
                // }
                console.log(element)
                let data: RowsObj = {
                    memberId: element.rdApplication.memberId,
                    name: element.name,
                    personalNumber: element.personalNumber,
                    ticket: element.ticketNumber,
                    id: element.rdId,
                    amount: element.assignedAmount,
                    tenure: element.assignedTenure,
                    interest: element.schemeId.rdInterestRate,
                    intAmount: element.interest,
                    onMaturityAmount: element.onMaturityAmount,
                    mode: "Bank_Transfer",
                    indicator: "Debit",
                    notes: element.notes,
                    fundingAccount: element.fundingAccount ? element.fundingAccount : "SBI",
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    accountId: element.accountId
                }
                abc.push(data);
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    function roundOff(value: string, amount: number) {
        if(value.length == 3) {
            return Math.round(amount/100)*100;
        }
        if(value.length == 4) {
            return Math.round(amount/1000)*1000;
        }
        if(value.length == 5) {
            return Math.round(amount/10000)*10000;
        }
        if(value.length == 6) {
            return Math.round(amount/100000)*100000;
        }
        if(value.length == 7) {
            return Math.round(amount/1000000)*1000000;
        }
        if(value.length == 8) {
            return Math.round(amount/10000000)*10000000;
        }
        return 0;
    }

    async function postData() {
        let allCheckedRecordsResponse = [];
        console.log(rowsData);
        for (let s of checkedRecords) {
            for (let allrecord of rowsData) {
                if (s == allrecord.id) {
                    let newObj = {
                        "fundingAccount": allrecord.fundingAccount,
                        "indicator": allrecord.indicator,
                        "interest": parseFloat("0"),
                        "accountNumber": "rd" + allrecord.memberId,
                        "id": allrecord.id,
                        "memberId": parseInt(allrecord.memberId),
                        "notes": allrecord.notes,
                        "mode": allrecord.mode,
                        "amount": parseFloat(allrecord.amount),
                    }
                    allCheckedRecordsResponse.push(newObj);
                }
            }
        }
        console.log(allCheckedRecordsResponse);
        let url = "posting/rd";
        let response = await mainService.postRequest(url, allCheckedRecordsResponse, null);
        if(response.status == 200) {
            setRows([]);
            setFilterType('');
        }
        console.log(response);
    }

    function saveEditedRecord() {
        let index = 0;
        for(let s of rowsData) {
            if(recordOpened && recordOpened['id'] == s.id) {
                rowsData[index]['fundingAccount'] = fundingAccount;
                rowsData[index]['mode'] = paymentMode;
                rowsData[index]['notes'] = notes;
            }
            index++;
        }
        setShowEditDialog(false);
    }

    function txnDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        // getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        // getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    function displayAlert(message: string) {
        setAlertMessage(message)
        setShowAlert(true);
        setTimeout(() => {
            setShowAlert(false);
        }, 5000);
    }

    function closeAlert() {
        setShowAlert(false);
    }

    function setSelectionModel(data: any) {
        console.log(data);
        setCheckedRecords(data);
    }
     const closeEditDialog = () => {
        setShowEditDialog(false);
     }

    return (
        <div>
            {
                showAlert ?
                    <div className="d-flex justify-content-end phx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessage}</span>
                                <button aria-label="Close" className='close close-position' type='button' data-dismiss="alert" onClick={() => closeAlert()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
                        {
                showEditDialog ?
                    <div className="modal fade show" data-bs-backdrop="static" data-bs-keyboard="false" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Edit Posting Record</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeEditDialog()}></button>
                                </div>
                                <div className="modal-body">
                                    <div className='row'>
                                <div className="col-md-12">
                                                <select className="form-select my-1 fs-6" id="paymentMode"
                                                    name="paymentMode"
                                                    onChange={handlePaymentMode}
                                                    value={paymentMode}>
                                                    <option disabled value="">--Select Mode--</option>
                                                    {['Cash', 'UPI', 'Bank_Transfer', 'Cheque', 'Cash_Transfer_Account'].map((item, index) => <option key={index} value={item}>{item}</option>)}

                                                </select>
                                            </div>

                                            <div className="col-md-12">
                                                <select className="form-select my-1 fs-6"
                                                    id="fundingAccount"
                                                    name="fundingAccount"
                                                    onChange={handleFundingAccount}
                                                    value={fundingAccount}>
                                                    <option disabled value="">--Select SBI / DCB--</option>
                                                    <option value="SBI">SBI C/A 10674451044</option>
                                                    <option value="DCB" disabled={true}>DCB C/A SOC-154</option>
                                                    <option value="CASH_IN_HAND">Cash In Hand</option>
                                                </select>
                                            </div>

                                            <div className="col-md-12">
                                                <textarea className="form-control my-1 fs-6"
                                                    name="notes" rows={4}
                                                    placeholder="Notes"
                                                    onChange={handleNotes}
                                                    value={notes} />

                                            </div>
                                            <button type="button" className="btn"
                            onClick={() => saveEditedRecord()}>Save</button>
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className="container-fluid">
                <div className='row'>
                    <div className='col-md-3'>
                        <div className="form-body scrollable-box">
                            <div className="row">
                                <div className="form-holder">
                                    <div className="form-content">
                                        <div className="form-items">
                                            <form className="requires-validation">
                                                <div className="col-md-12">
                                                    <label className='form-label color-white'>Filter Type</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="RDFilterType" name="RDFilterType"
                                                        onChange={handleFilterType}
                                                        value={filterType}>
                                                        <option value="Select" key="Select">Select</option>
                                                        <option value="memberwise" key="Member-Wise">Member-Wise</option>
                                                        <option value="groupwise" key="Group-Wise">Group-Wise</option>
                                                    </select>
                                                </div>

                                                {filterType == "memberwise" ?
                                                    <div className="col-sm-12">
                                                        <div className='pd-b-10'>
                                                            <label className="form-label color-white">Member ID</label>
                                                            <input type="text" autoComplete='off'
                                                                className="form-control"
                                                                id="memberId"
                                                                name="memberId"
                                                                placeholder="Member ID"
                                                                onChange={handleMemberId}
                                                                value={memberId} />
                                                        </div>
                                                    </div> : <></>
                                                }
                                                {
                                                    // filterType == "groupwise" ?
                                                    //     <div className='col-sm-2'>
                                                    //         <div className='pd-b-10'>
                                                    //             <label className="form-label color-white">Start Date</label>
                                                    //             <input className="form-control my-1"
                                                    //                 id="fromDate"
                                                    //                 name="fromDate"
                                                    //                 type="Date"
                                                    //                 autoComplete='off'
                                                    //                 onChange={handleFromDate}
                                                    //                 value={fromDate}
                                                    //                 placeholder="From"
                                                    //             />
                                                    //         </div></div> : <></>
                                                }
                                                {
                                                    filterType == "groupwise" ?
                                                        <div className="col-sm-12">
                                                            <div className='pd-b-10'>
                                                                <label className="form-label color-white">Section</label>
                                                                <input type="text" autoComplete='off'
                                                                    className="form-control"
                                                                    id="section"
                                                                    name="section"
                                                                    placeholder="Section"
                                                                    onChange={handleSection}
                                                                    value={section} />
                                                            </div>
                                                        </div> : <></>}
                                                {
                                                    filterType == "groupwise" ?
                                                        <div className="col-sm-12">
                                                            <div className='pd-b-10'>
                                                                <label className="form-label color-white">Post</label>
                                                                <input type="text" autoComplete='off'
                                                                    className="form-control"
                                                                    id="post"
                                                                    name="post"
                                                                    placeholder="Post"
                                                                    onChange={handlePost}
                                                                    value={post} />
                                                            </div>
                                                        </div> : <></>}
                                                {
                                                    filterType == "groupwise" ?
                                                        <div className="col-sm-12">
                                                            <label htmlFor="title" className='color-white'>Staff Type</label>
                                                            <select className="form-select" id="staffType" value={staffType}
                                                                name="staffType" onChange={handleStaffType}>
                                                                <option value="">--Select--</option>
                                                                <option value="IES">IES</option>
                                                                <option value="Staff">Staff</option>
                                                            </select>
                                                        </div>
                                                        : <></>
                                                }



                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => FilterRDAssignmentData()}>Filter</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-9 border-left'>
                        <br />
                        <button type="button" className="btn btn-outline-light"
                            onClick={() => postData()}>Post</button>

                        {
                            rowsData ?
                                <div className="text-white bg-white grid-view" id='gridView'>
                                    <DataGrid
                                        className=''
                                        disableSelectionOnClick={true}
                                        checkboxSelection={true}
                                        rows={rowsData as any}
                                        columns={columnsList}
                                        pageSize={numberOfRows}
                                        getRowId={(row) => row.id}
                                        hideFooter={true}
                                        onSelectionModelChange={(newSelectionModel) => {
                                            setSelectionModel(newSelectionModel);
                                        }}
                                    />
                                </div> : <div className="bg-white grid-view"></div>
                        }

                    </div>
                </div>
            </div>
        </div>
    )
}
