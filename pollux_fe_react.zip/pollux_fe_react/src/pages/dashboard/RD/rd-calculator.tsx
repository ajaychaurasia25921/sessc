import React, { useState } from 'react';
import './rd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

export const RDCalculator = (props: any) => {

    var [RDAmount, setRDAmount] = React.useState('500');
    var [RDRange, setRDRange] = React.useState('500');
    var [estReturns, setEstReturns] = React.useState('');
    var [RDSchemeName, setRDSchemeName] = React.useState('');
    var [interestStartRange, setInterestStartRange] = React.useState('');
    var [RDTenureType, setRDTenureType] = React.useState('');
    var [RDMonths, setRDMonths] = React.useState('');
    var [maturedAmount, setMaturedAmount] = React.useState('');
    var [allRDSchemes, setAllRDSchemes] = React.useState(Array<any>());
    var [maturityDate, setMaturityDate] = React.useState('');

    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    React.useEffect(() => {
        getAllRDSchemes();
    }, []);
    React.useEffect(() => {
        for (let s of allRDSchemes) {
            if (s.schemeId == RDSchemeName) {
                setInterestStartRange(s.rdInterestRate);
                break;
            }
        }
    }, [RDSchemeName]);

    async function getAllRDSchemes() {
        let url = `rd/scheme`;
        try {
            let response = await mainService.getRequest(url, null, null);
            setAllRDSchemes(response.data.content);
        } catch (e: any) {
            console.log(e)
        }
    }

    const handleRDAmount = (e: any) => {
        setRDAmount(e.target.value);
        setRDRange(e.target.value);
    }
    const handleRDSchemeName = (e: any) => {
        setRDSchemeName(e.target.value);
    }
    const handleRDRange = (e: any) => {
        setRDRange(e.target.value);
        setRDAmount(e.target.value);
    }
    const handleRDMonths = (e: any) => {
        setRDMonths(e.target.value);
    }
    const handleInterestStartRange = (e: any) => {
        setInterestStartRange(e.target.value);
    }
    const handleTenureType = (e: any) => {
        setRDTenureType(e.target.value);
    }
    async function calculateInputs() {
        let newRDAmount = parseInt(RDAmount);
        let newTenure = parseFloat(RDMonths);
        let newRate = parseFloat(interestStartRange);

        if (RDTenureType == "Years") {
            newTenure = newTenure * 12;
        }

        let interestCalculationCount = parseInt(newTenure / 6 + "");
        let finalMaturityAmout: any;
        let currentBal: number = 0;
        let totalInterest = 0;
        for (let i = 0; i < interestCalculationCount; i++) {
            finalMaturityAmout = cal(newRDAmount, newRate, 6, currentBal, newTenure);
            currentBal = finalMaturityAmout['currentBalance'] + finalMaturityAmout['intrestOnPeriod'];
            totalInterest = totalInterest + finalMaturityAmout['intrestOnPeriod'];
        }
        let intAmount = totalInterest;

        if((intAmount+ "").includes(".")) {
            let arr = (intAmount+"").split(".");
            intAmount = roundOff(arr[0], intAmount);
        } else {
            intAmount = roundOff(intAmount+"", intAmount);
        }

        setMaturedAmount(((newRDAmount * newTenure) + intAmount) + "");
        setEstReturns(intAmount + "");
        // setTotalInstallments(newTenure+"");
        // let tenure: any = "";
        var d = new Date();
        if (RDTenureType == "Years") {
            // tenure = RDMonths;
            d.setFullYear(d.getFullYear() + parseInt(RDMonths));
        }
        if (RDTenureType == "Months") {
            // tenure = parseFloat(RDMonths) / 12;
            d.setMonth(d.getMonth() + parseInt(RDMonths));
        }
        setMaturityDate(d.getDate() + " " + monthNames[d.getMonth()] + " " + d.getFullYear());

        // let interest = (parseFloat(RDAmount) * parseFloat(interestStartRange) * parseFloat(tenure)) / 100;
        // setEstReturns(Math.round(interest) + "");
        // let OnMaturityAmount = parseFloat(RDAmount) + interest;
        // setMaturedAmount(Math.round(OnMaturityAmount) + "");
    }

    function roundOff(value: string, amount: number) {
        if(value.length == 2) {
            return Math.round(amount);
        }
        if(value.length >= 3) {
            return Math.round(amount/10)*10;
        }
        // if(value.length == 4) {
        //     return Math.round(amount/100)*100;
        // }
        // if(value.length == 5) {
        //     return Math.round(amount/1000)*1000;
        // }
        // if(value.length == 6) {
        //     return Math.round(amount/10000)*10000;
        // }
        // if(value.length == 7) {
        //     return Math.round(amount/100000)*100000;
        // }
        // if(value.length == 8) {
        //     return Math.round(amount/1000000)*1000000;
        // }
        return 0;
    }

    function cal(amount: any, interest: number, period: number, currentAmount:number, newTenure: number) {
        let newPeriodAmount: any = currentAmount;
        let tempPeriodAmount = 0;
        for(let i=0;i<period;i++) {
            newPeriodAmount = newPeriodAmount + amount;
            tempPeriodAmount = tempPeriodAmount + newPeriodAmount;
        }
        console.log(tempPeriodAmount);
        let intrestOnPeriod = (tempPeriodAmount * interest) / (100 * newTenure);
        return {"intrestOnPeriod": intrestOnPeriod, "currentBalance": newPeriodAmount};
    }

    function resetInputs() {
        setRDAmount('');
        setRDRange('');
        setRDSchemeName('');
        setInterestStartRange('');
        setRDTenureType('');
        setRDMonths('');
    }

    function investNow() {

        // let tab = document.getElementById("RDBtn");
        // if(tab) {
        //     tab.dispatchEvent(new Event("click"));
        // }

        // document.getElementById("rdApplication-tab")?.classList.add("active");
        // document.getElementById("rdCalculator-tab")?.classList.remove("active");
        // document.getElementById("rdApplication")?.classList.add("show");
        // document.getElementById("rdCalculator")?.classList.remove("show");
        // document.getElementById("rdApplication")?.classList.add("active");
        // document.getElementById("rdCalculator")?.classList.remove("active");

    }

    return (
        <div>
            <div className="container-fluid">
                <div className='row'>
                    {/* <div className='col-md-1'></div> */}
                    <div className='col-md-3'>
                        <div className="form-body">
                            <div className="row">
                                <div className="form-holder rd-scheme-form">
                                    <div className="form-content">
                                        <div className="form-items color-white">
                                            <form className="mt-1">
                                                <div className="col-md-12">
                                                    <label className='form-label'>RD Amount</label>
                                                    <input className="form-control my-1 fs-6"
                                                        id="rdAmount"
                                                        autoComplete='off'
                                                        name="rdAmount"
                                                        type="text"
                                                        onChange={handleRDAmount}
                                                        value={RDAmount}
                                                        placeholder="RD Amount" />
                                                </div>

                                                <label className="form-label">Example range</label>
                                                <input type="range"
                                                    onChange={handleRDRange}
                                                    value={RDRange}
                                                    className="form-range"
                                                    min="0"
                                                    max="10000"
                                                    step="100"
                                                    id="customRange3"></input>

                                                <div className='col-md-12'>
                                                    <label className="form-label color-white">RD Scheme Name</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="RDSchemeName"
                                                        name="RDSchemeName"
                                                        onChange={handleRDSchemeName}
                                                        value={RDSchemeName}>
                                                        <option value="" key="" >Select</option>
                                                        {
                                                            allRDSchemes.map(e => <option
                                                                value={e.schemeId} key={e.rdName}>{e.rdName}</option>)
                                                        }
                                                    </select>
                                                </div>

                                                <div className="col-md-12">
                                                    <label className='form-label'>Interest Rate</label>
                                                    <div>
                                                        <input type="text"
                                                            className="form-control"
                                                            id="interestStartRange"
                                                            autoComplete='off'
                                                            name="interestStartRange"
                                                            placeholder="Interest Rate"
                                                            onChange={handleInterestStartRange}
                                                            value={interestStartRange} disabled readOnly />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <label className='form-label'>Tenure (in months)</label>
                                                    <div>
                                                        <div className='inline-prop'>
                                                            <input type="text"
                                                                className="form-control"
                                                                id="RDMonths"
                                                                name="RDMonths"
                                                                autoComplete='off'
                                                                onChange={handleRDMonths}
                                                                value={RDMonths} />
                                                        </div>
                                                        <div className='inline-prop'>
                                                            <select className="form-select"
                                                                aria-label="Default select example"
                                                                id="RDFilterType" name="RDFilterType"
                                                                onChange={handleTenureType}
                                                                value={RDTenureType}>
                                                                <option value="Select" key="Select">Select</option>
                                                                <option value="Years" key="Get All">Year</option>
                                                                <option value="Months" key="RD Application ID">Month</option>
                                                            </select>
                                                        </div>
                                                        {/* <div className='col-md-1'></div> */}

                                                    </div>
                                                </div>

                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => calculateInputs()}>Calculate</button>
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => resetInputs()}>Reset</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-7'>
                        <div className="output-card">
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                        <strong>
                                            <div>
                                                <span className='smallfont'>ESTIMATED RETURNS</span>
                                            </div>
                                            Rs. <span className='xxlargefont'>{estReturns}</span>
                                        </strong>
                                    </div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                        <strong>
                                            <div>
                                                <span className='smallfont'>MATURITY AMOUNT</span>
                                            </div>
                                            Rs. <span className='xxlargefont'>{maturedAmount}</span>
                                        </strong>
                                    </div>
                                </div>
                                <br /><br />
                                <div className='interest-div'>
                                    <span><strong>Interest @ {interestStartRange} p.a.</strong></span>
                                </div>
                            </div>
                            <hr />
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='interest-div'>
                                        <span><strong>Matured Upto : {maturityDate}</strong></span>
                                    </div>
                                </div>
                                {/* <div className="form-button mt-3 interest-div">
                                    <button type="button" className="btn"
                                        onClick={() => investNow()}>Invest Now</button>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}
