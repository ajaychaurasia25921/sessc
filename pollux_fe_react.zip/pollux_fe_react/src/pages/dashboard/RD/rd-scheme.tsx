import React, { useState } from 'react';
import './rd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

type RowsObjRD = {
    id: string,
    rdName: string,
    rdInterestRate: number,
    tenure: string,
    amount: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string
};

export const RDScheme = (props: any) => {

    var [RDName, setRDName] = React.useState('');
    var [editedRDName, setEditedRDName] = React.useState('');
    var [RDminAmount, setRDMinAmount] = React.useState('');
    var [editedRDminAmount, setEditedRDMinAmount] = React.useState('');
    const [rowsData, setRows] = React.useState(Array);
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [hasPrevious, setHasPrevious] = React.useState(false);
    var [interestStartRange, setInterestStartRange] = React.useState('');
    var [editedInterestStartRange, setEditedInterestStartRange] = React.useState('');
    // var [RDYears, setRDYears] = React.useState('');
    var [RDMonths, setRDMonths] = React.useState('');
    var [editedRDMonths, setEditedRDMonths] = React.useState('');
    var [disableSaveRDBtn, setDisableSaveRDBtn] = React.useState(true);
    var [showEditRDSchemeDialog, setShowEditRDSchemeDialog] = React.useState(false);
    var [recordOpened, setRecordOpened] = React.useState();

    React.useEffect(() => {
        getRows(10, 0);
    }, []);

    const RDcolumnsList: GridColDef[] = [
        { field: 'id', headerName: 'Scheme ID', width: 150 },
        { field: 'rdName', headerName: 'RD Name', width: 150 },
        { field: 'rdInterestRate', headerName: 'Interest Range', width: 150 },
        { field: 'tenure', headerName: 'Tenure', width: 150 },
        { field: 'amount', headerName: 'Minimum Amount', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'modifiedOn', headerName: 'Modified On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        { field: 'modifiedBy', headerName: 'Modified By', width: 150 },
        {
            field: 'action',
            width: 130,
            sortable: false,
    
            renderCell: (params) => {
                function onClickEdit() {
                    console.log(params.row)
                    setShowEditRDSchemeDialog(true);
                    setRecordOpened(params.row);
                    setEditedRDName(params.row.rdName)
                    setEditedInterestStartRange(params.row.rdInterestRate);
                    setEditedRDMonths(params.row.tenure);
                    setEditedRDMinAmount(params.row.amount);
                    // setEditedRDPreClosure(params.row.preClosureCharges);
                    // setEditedFee(params.row.fee);
                }
    
                return (
                    <>
                        <FontAwesomeIcon className='fa-icon-table' icon={solid('pencil')} onClick={() => onClickEdit()} />
                    </>
                );
            },
        }
    ];

    const handleRDName = (e: any) => {
        setRDName(e.target.value);
        checkDisabilityofSaveRDBtn();
    }
    // const handleRDYears = (e: any) => {
    //     setRDYears(e.target.value);
    //     checkDisabilityofSaveRDBtn();
    // }
    const handleRDMonths = (e: any) => {
        setRDMonths(e.target.value);
        checkDisabilityofSaveRDBtn();
    }

    const handleInterestStartRange = (e: any) => {
        setInterestStartRange(e.target.value);
        checkDisabilityofSaveRDBtn();
    }

    const handleRDMinAmount = (e: any) => {
        setRDMinAmount(e.target.value);
        checkDisabilityofSaveRDBtn();
    }
    const handleEditedRDName = (e: any) => {
        setEditedRDName(e.target.value);
    }
    const handleEditedInterestRate = (e: any) => {
        setEditedInterestStartRange(e.target.value);
    }
    const handleEditedTenure = (e: any) => {
        setEditedRDMonths(e.target.value);
    }
    const handleEditedRDMinAmount = (e: any) => {
        setEditedRDMinAmount(e.target.value);
    }

    async function saveRDPlan() {
        // if (RDYears == '') {
        //     setRDYears('0');
        // }
        if (RDMonths == '') {
            setRDMonths('0');
        }
        let reqPayload = {
            "rdName": RDName,
            "amount": parseInt(RDminAmount),
            "rdInterestRate": parseFloat(interestStartRange),
            "tenure": RDMonths
        }
        try {
            let tempurl = 'rd/scheme';
            let response = await mainService.postRequest(tempurl, reqPayload, null);
            if(response.status == 200) {
                setRDName('');
                setInterestStartRange('');
                // setRDYears('');
                setRDMonths('');setRDMinAmount('');
            }
            getRows(10, 0);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    const checkDisabilityofSaveRDBtn = (val?: any, type?: any) => {
        setTimeout(() => {
            if (RDName && RDName != ''
                && interestStartRange && interestStartRange != ''
                && (RDMonths)) {
                setDisableSaveRDBtn(false);
            } else {
                setDisableSaveRDBtn(true);
            }
        }, 1000)


    }

    async function getRows(rowSize: number, pageSize: number) {
        console.log(rowSize, pageSize);
        let url = `rd/scheme?size=${rowSize}&page=${pageSize}`;
        let abc: any[] = [];
        try {
            let response = await mainService.getRequest(url, null, null);
            console.log(response);
            setTotalElement(response.data.totalElements);
            setHasNext(response.data.hasNext);
            setHasPrevious(response.data.hasPrevious);
            setNumberOfRows(response.data.size);
            setRows([]);
            response.data.content.forEach((element: any) => {
                let data: RowsObjRD = {
                    id: element.schemeId,
                    rdName: element.rdName,
                    rdInterestRate: element.rdInterestRate,
                    tenure: element.tenure,
                    amount: element.amount,
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    modifiedOn: dateFormat(element.modifiedOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    modifiedBy: element.createdBy
                }
                abc.push(data);
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function saveEditedRecord() {
        let url = `rd/scheme`;
        let data = {
            "rdName": editedRDName,
            "amount": parseInt(editedRDminAmount),
            "rdInterestRate": parseFloat(editedInterestStartRange),
            "tenure": editedRDMonths,
            "schemeId": recordOpened?recordOpened['id']:''
            // "fee": parseFloat(editedFee),
            // "preClosureCharges": parseFloat(editedRDPreClosure),
        }
        let response = await mainService.postRequest(url, data, null);
        if (response.status == 200) {
            setEditedInterestStartRange('');
            setEditedRDMonths('');
            setEditedRDMinAmount('');
            // setEditedFDPreClosure('');
            setEditedRDName('');
            // setEditedFee('');
            setShowEditRDSchemeDialog(false);
        }
        getRows(recordsSize, pageSize);
    }

    function closeEditDialog() {
        setShowEditRDSchemeDialog(false);
    }

    function txnDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    return (
        <div>
            {
                showEditRDSchemeDialog ?
                    <div className="modal fade show" data-bs-backdrop="static" data-bs-keyboard="false" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Edit FD Scheme Record</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeEditDialog()}></button>
                                </div>
                                <div className="modal-body">
                                    <div className='row'>
                                            <div className="col-md-6">
                                            <label className='form-label'>Scheme Name</label>
                                            <input className="form-control my-1 fs-6"
                                                id="loanName" autoComplete='off'
                                                name="schemeName"
                                                type="text"
                                                onChange={handleEditedRDName}
                                                value={editedRDName}
                                                placeholder="Scheme Name"
                                            />
                                            </div>

                                            <div className="col-md-6">
                                            <label className='form-label'>RD Minimum Amount</label>
                                            <input className="form-control my-1 fs-6"
                                                id="loanName" autoComplete='off'
                                                name="schemeName"
                                                type="text"
                                                onChange={handleEditedRDMinAmount}
                                                value={editedRDminAmount}
                                                placeholder="Scheme Name"
                                            />
                                            </div>

                                            <div className="col-md-6">
                                        <label className='form-label'>Interest Rate</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxAmount" autoComplete='off'
                                                name="maxAmount"
                                                type="text"
                                                placeholder="Max Amount"
                                                onChange={handleEditedInterestRate}
                                                value={editedInterestStartRange}
                                            />
                                        </div>
                                        <div className="col-md-6">
                                        <label className='form-label'>Tenure</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxTenure"
                                                name="maxTenure"
                                                type="text"
                                                autoComplete='off'
                                                placeholder="Tenure(in months)"
                                                onChange={handleEditedTenure}
                                                value={editedRDMonths}
                                            />
                                        </div>
                                            <button type="button" className="btn"
                            onClick={() => saveEditedRecord()}>Save</button>
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className="container-fluid">
            <div className='row'>
                <div className='col-md-3'>
                    <div className="form-body">
                        <div className="row">
                            <div className="form-holder">
                                <div className="form-content">
                                    <div className="form-items color-white">
                                        <form className="requires-validation">
                                            <div className="col-md-12">
                                                <label className='form-label'>RD Scheme Name</label>
                                                <input className="form-control my-1 fs-6"
                                                    id="rdName"
                                                    autoComplete='off'
                                                    name="rdName"
                                                    type="text"
                                                    onChange={handleRDName}
                                                    value={RDName}
                                                    placeholder="RD Name"/>
                                            </div>
                                            <div className="col-md-12">
                                                <label className='form-label'>RD Minimum Amount</label>
                                                <input className="form-control my-1 fs-6"
                                                    id="RDminAmount"
                                                    autoComplete='off'
                                                    name="RDminAmount"
                                                    type="text"
                                                    onChange={handleRDMinAmount}
                                                    value={RDminAmount}
                                                    placeholder="RD Min Amount"/>
                                            </div>
                                            <div className="col-md-12">
                                                <label className='form-label'>Interest Rate</label>
                                                <div>
                                                    <input type="text"
                                                        className="form-control"
                                                        autoComplete='off'
                                                        id="interestStartRange"
                                                        name="interestStartRange"
                                                        placeholder="From"
                                                        onChange={handleInterestStartRange}
                                                        value={interestStartRange} />
                                                    {/* <input type="text"
                                                        className="form-control tenure-inline mx-1"
                                                        id="interestEndRange"
                                                        name="interestEndRange"
                                                        placeholder="To"
                                                        onChange={handleInterestEndRange}
                                                        value={interestEndRange} /> */}
                                                </div>
                                            </div>
                                            <div className="col-md-12">
                                                <label className='form-label'>Tenure</label>
                                                <div>
                                                    {/* <input type="text"
                                                        className="form-control tenure-inline"
                                                        id="RDYears"
                                                        autoComplete='off'
                                                        name="RDYears"
                                                        placeholder="Years"
                                                        onChange={handleRDYears}
                                                        value={RDYears} /> */}
                                                    <input type="text"
                                                        className="form-control"
                                                        id="RDMonths"
                                                        autoComplete='off'
                                                        name="RDMonths"
                                                        placeholder="Months"
                                                        onChange={handleRDMonths}
                                                        value={RDMonths} />
                                                </div>
                                            </div>
                                            {/* <div className="col-md-12">
                                                <label className='form-label'>Fee</label>
                                                <input className="form-control my-1 fs-6"
                                                    id="fee"
                                                    name="fee"
                                                    type="text"
                                                    onChange={handleFee}
                                                    value={fee}
                                                    placeholder="Fee Charges"/>
                                            </div> */}

                                            <div className="form-button mt-3">
                                                <button type="button" className="btn btn-outline-light"
                                                    onClick={() => saveRDPlan()} disabled={disableSaveRDBtn}>Save RD</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='col-md-9 border-left'>
                    <br />
                    <div className='d-flex mb-2 flex-row-reverse'>
                        <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
                            <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
                            <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
                            <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
                        </div>
                        <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
                            <option value={5}>5</option>
                            <option value={10}>10</option>
                            <option value={25}>25</option>
                            <option value={50}>50</option>
                        </select>
                    </div>
                    {rowsData.length?
                    <div className="text-white bg-white grid-view" id='gridViewRD'>
                        <DataGrid
                            className=''
                            rows={rowsData as any}
                            columns={RDcolumnsList}
                            pageSize={numberOfRows}
                            getRowId={(row) => row.id}
                            hideFooter={true}
                        />
                    </div>:<></>
}
                </div>
            </div></div>
        </div>
        
    );
}
