import React, { useState } from 'react';
import './rd.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Button, Modal } from 'react-bootstrap';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

type RowsObj = {
    id: string,
    memberId: string,
    rdAmount: number,
    tenure: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string
};

export const RDSearch = (props: any) => {

    var [RDFilterType, setRDFilterType] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [RDId, setRDId] = React.useState('');
    const [rowsData, setRows] = React.useState(Array);
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [hasPrevious, setHasPrevious] = React.useState(false);
    var [deleteModal, setDeleteModal] = React.useState(false);
    var [RDDeactivateRecordId, setRDDeactivateRecordId] = React.useState("");
    var [RDassignmentViewModal, setRDAssignmentViewModal] = React.useState(false);
    var [RDViewRecord, setRDViewRecord] = React.useState();
    var [RDapplicationAssigned, setRDApplicationAssigned] = React.useState(true);

    React.useEffect(() => {
        getRows(10, 0);
    }, []);
    React.useEffect(() => {
        setMemberId("");
        setRDId("");
        setRows([]);
    }, [RDFilterType]);

    const columnsList: GridColDef[] = [
        { field: 'id', headerName: 'RD Application ID', width: 150 },
        { field: 'memberId', headerName: 'Member ID', width: 150 },
        { field: 'rdAmount', headerName: 'RD Amount', width: 150 },
        { field: 'tenure', headerName: 'Tenure (in months)', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'modifiedOn', headerName: 'Modified On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        { field: 'modifiedBy', headerName: 'Modified By', width: 150 },
        {
            field: 'Actions',
            width: 130,
            sortable: false,

            renderCell: (params) => {
                async function deActivateRecord() {
                    console.log(params.row);
                    setRDDeactivateRecordId(params.row.id);
                    setDeleteModal(!deleteModal);
                };
                async function viewRecord() {
                    let tempurl = `rd/assignment/member?memberId=${params.row.memberId}`;
                    let response = await mainService.getRequest(tempurl, null, null);
                    let rdRec: any = "";
                    if(response.data.length > 0) {
                        setRDApplicationAssigned(true);
                        for (let s of response.data) {
                            if (params.row.id == s.rdApplication.applicationId) {
                                rdRec = s;
                                setRDViewRecord(s);
                                setRDAssignmentViewModal(true);
                                break;
                            }
                        }
                    } 
                    else {
                        setRDApplicationAssigned(false);
                        setRDAssignmentViewModal(true);
                        let obj : any = "";
                        setRDViewRecord(obj);
                    }
                    if(rdRec) {
                        setRDApplicationAssigned(true);
                    } else {
                        setRDApplicationAssigned(false);
                        setRDAssignmentViewModal(true);
                        let obj : any = "";
                        setRDViewRecord(obj);

                    }
                }
                return (
                    <>
                        <FontAwesomeIcon className='fa-icon-table' title="View" icon={solid('eye')} onClick={() => viewRecord()} />
                        <button className="btn p-0" onClick={() => deActivateRecord()} title="Deactivate"><img className="mx-1" src="/assets/remove.svg" alt="" /></button>

                    </>
                );
            },
        },
    ];

    const handleRDFilterType = (e: any) => {
        setRDFilterType(e.target.value);
    }
    const handleMemberId = (e: any) => {
        setMemberId(e.target.value);
    }
    const handleRDId = (e: any) => {
        setRDId(e.target.value);
    }

    async function searchRDPlan() {
        try {
            setPageSize(0);
            getRows(10, 0);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function getRows(rowSize: number, pageSize: number) {
        try {
            let url = "";
            let abc: any[] = [];
            let processResponse: any[] = [];
            if (RDFilterType == "") {
                return;
            }
            if (RDFilterType == "Get All") {
                url = `rd/application?size=${rowSize}&page=${pageSize}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else if (RDFilterType == "RD Application ID") {
                url = `rd/application/${RDId}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse.push(response.data);
            } else if (RDFilterType == "Member ID") {
                url = `rd/application/memberId?id=${memberId}&page=${pageSize}&size=${rowSize}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else {
            }

            processResponse.forEach((element: any) => {
                let data: RowsObj = {
                    id: element.applicationId,
                    memberId: element.memberId,
                    tenure: element.tenure,
                    rdAmount: element.rdAmount,
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    modifiedOn: dateFormat(element.modifiedOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    modifiedBy: element.createdBy
                }
                abc.push(data);
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }


    function txnDataNext() {
        setPageSize(pageSize + 1);
        getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    async function deactivateRecordOnConfirm(id: any) {
        let url = `rd/revoke/${RDDeactivateRecordId}`;
        try {
            let response = await mainService.getRequest(url, null, null);
        }
        catch (e: any) {
            console.log(e);
        }
    }


    function DeleteModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Are you sure want to <strong className='text-danger'>Delete</strong> the Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block text-center'>
                    <p>
                        You are about to delete RD Application <strong>{RDDeactivateRecordId}</strong>. This process is irrevesable!
                    </p>
                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setDeleteModal(!deleteModal) }}>Cancel</Button>
                    <Button variant="danger" onClick={() => { deactivateRecordOnConfirm(RDDeactivateRecordId); setDeleteModal(!deleteModal); getRows(10, 0); }}>Delete</Button>
                </Modal.Footer>
            </Modal>
        );
    }

    function ViewRDAssignmentModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        View RD Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    {RDassignmentViewModal && !RDapplicationAssigned ? <h3>RD Application not assigned to any scheme. Please Assign to view details.</h3> : <></>}
                    {RDassignmentViewModal && RDapplicationAssigned ? <div className='row'>
                    <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">RD Account Number</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['rdAccountNumber']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['assignedAmount']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Tenure</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['assignedTenure']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest To Be Credited</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['interest']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Rate</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['schemeId']['rdInterestRate']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">On-Maturity Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['onMaturityAmount']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Maturity Date</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?dateFormat(RDViewRecord['maturityDate'], "mmmm dS, yyyy"):""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme ID</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['schemeId']['schemeId']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme Name</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={RDViewRecord?RDViewRecord['schemeId']['rdName']:""} />
                            </div>
                        </div>
                    </div> : <></>}
                    
                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setRDApplicationAssigned(false); setRDAssignmentViewModal(!RDassignmentViewModal) }}>Cancel</Button>
                </Modal.Footer>
            </Modal>
        );
    }

    return (
        <div>
            {
                deleteModal && <DeleteModalView show={deleteModal} onHide={() => setDeleteModal(false)} />
            }
            {
                RDassignmentViewModal && <ViewRDAssignmentModalView show={RDassignmentViewModal} onHide={() => setRDAssignmentViewModal(false)}/>
            }
        <div className="container-fluid">
            <div className='row'>
                <div className='col-md-3'>
                    <div className="form-body">
                        <div className="row">
                            <div className="form-holder">
                                <div className="form-content">
                                    <div className="form-items">
                                        <form className="requires-validation">
                                            <div className="col-md-12">
                                                <label className='form-label color-white'>Filter Type</label>
                                                <select className="form-select"
                                                    aria-label="Default select example"
                                                    id="RDFilterType" name="RDFilterType"
                                                    onChange={handleRDFilterType}
                                                    value={RDFilterType}>
                                                    <option value="Select" key="Select">Select</option>
                                                    <option value="Get All" key="Get All">Get All</option>
                                                    <option value="RD Application ID" key="RD Application ID">RD Application ID</option>
                                                    <option value="Member ID" key="Member ID">Member ID</option>
                                                </select>
                                            </div>
                                            {
                                                RDFilterType == "Member ID" ?
                                                    <div className="col-md-12">
                                                        <label className='form-label color-white'>Member ID</label>
                                                        <input className="form-control my-1 fs-6"
                                                            id="memberId"
                                                            autoComplete='off'
                                                            name="memberId"
                                                            type="text"
                                                            placeholder="Member ID"
                                                            onChange={handleMemberId}
                                                            value={memberId} />
                                                    </div> : <></>
                                            }
                                            {
                                                RDFilterType == "RD Application ID" ?
                                                    <div className="col-md-12">
                                                        <label className='form-label color-white'>RD Application ID</label>
                                                        <input className="form-control my-1 fs-6"
                                                            id="RDId"
                                                            name="RDId"
                                                            autoComplete='off'
                                                            type="text"
                                                            placeholder="RD Application ID"
                                                            onChange={handleRDId}
                                                            value={RDId} />
                                                    </div> : <></>
                                            }
                                            <div className="form-button mt-3">
                                                <button type="button" className="btn btn-outline-light"
                                                    onClick={() => searchRDPlan()}>Search</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {
                    rowsData ? <div className='col-md-9 border-left'>
                        <br />
                        <div className='d-flex mb-2 flex-row-reverse'>
                            <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
                                <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
                                <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
                                <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
                            </div>
                            <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
                                <option value={5}>5</option>
                                <option value={10}>10</option>
                                <option value={25}>25</option>
                                <option value={50}>50</option>
                            </select>
                        </div>
                        <div className="text-white bg-white grid-view" id='gridView'>
                            <DataGrid
                                className=''
                                rows={rowsData as any}
                                columns={columnsList}
                                pageSize={numberOfRows}
                                getRowId={(row) => row.id}
                                hideFooter={true}
                            />
                        </div>
                    </div> : <></>
                }

            </div>
            </div>
            </div>
    );
}
