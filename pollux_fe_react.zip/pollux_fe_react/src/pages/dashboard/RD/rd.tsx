import React, { useState } from 'react';
import './rd.scss';
import {RDApplication} from './rd-application';
import MainService from '../../../services/main-service';
import { RDScheme } from './rd-scheme';
import { RDAssignment } from './rd-assignment';
import { RDSearch } from './rd-search';
import { RDBookKeeping } from './rd-book-keeping';
import { RDCalculator } from './rd-calculator';

const mainService = new MainService("");

export const RecurringDeposit = () => {

    var [currentRDModule, setCurrentRDModule] = React.useState('RDApplication');

    return( 
        <div>
        <ul className="nav nav-tabs" id="myTab" role="tablist">
          <li className="nav-item" role="presentation">
            <button className="nav-link active" 
            id="rdApplication-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdApplication" 
            type="button" role="tab" 
            aria-controls="rdApplication" 
            onClick={()=> setCurrentRDModule('RDApplication')} 
            aria-selected="true">
              RD Application
            </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="rdScheme-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdScheme" 
            type="button" 
            role="tab" 
            aria-controls="rdScheme" 
            onClick={()=> setCurrentRDModule('RDScheme')}
            aria-selected="false">
              RD Scheme
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="rdAssignment-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdAssignment" 
            type="button" 
            role="tab" 
            aria-controls="rdAssignment"
            onClick={()=> setCurrentRDModule('RDAssignment')}
            aria-selected="false">
              RD Assignment
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="rdSearch-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdSearch" 
            type="button" 
            role="tab" 
            aria-controls="rdSearch"
            onClick={()=> setCurrentRDModule('RDSearch')}
            aria-selected="false">
              RD Search
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="rdBookKeeping-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdBookKeeping" 
            type="button" 
            role="tab" 
            aria-controls="rdBookKeeping"
            onClick={()=> setCurrentRDModule('RDBookKeeping')}
            aria-selected="false">
              RD Book Keeping
              </button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" 
            id="rdCalculator-tab" 
            data-bs-toggle="tab" 
            data-bs-target="#rdCalculator" 
            type="button" 
            role="tab" 
            aria-controls="rdCalculator"
            onClick={()=> setCurrentRDModule('RDCalculator')}
            aria-selected="false">
              RD Calculator
              </button>
          </li>
        </ul>
        <div className="tab-content" id="myTabContent">
          <div className='tab-pane fade show active'
            id="rdApplication"
            role="tabpanel"
            aria-labelledby="rdApplication-tab">
            {
              currentRDModule === "RDApplication" ? <RDApplication /> : <></>
            }
          </div>
          <div className="tab-pane fade"
            id="rdScheme"
            role="tabpanel"
            aria-labelledby="rdScheme-tab">
            {
              currentRDModule === "RDScheme" ? <RDScheme /> : <></>
            }
          </div>
          <div className="tab-pane fade"
            id="rdAssignment"
            role="tabpanel"
            aria-labelledby="rdAssignment-tab">
            {
              currentRDModule === "RDAssignment" ? <RDAssignment /> : <></>
            }
          </div>
          <div className="rd-search tab-pane fade"
            id="rdSearch"
            role="tabpanel"
            aria-labelledby="rdSearch-tab">
            {
              currentRDModule === "RDSearch" ? <RDSearch /> : <></>
            }
          </div>
          <div className="rd-bookKeeping tab-pane fade"
            id="rdBookKeeping"
            role="tabpanel"
            aria-labelledby="rdBookKeeping-tab">
            {
              currentRDModule === "RDBookKeeping" ? <RDBookKeeping /> : <></>
            }
          </div>
          <div className="rd-calculator tab-pane fade"
            id="rdCalculator"
            role="tabpanel"
            aria-labelledby="rdCalculator-tab">
            {
              currentRDModule === "RDCalculator" ? <RDCalculator /> : <></>
            }
          </div>
        </div>
      </div>
    )
}