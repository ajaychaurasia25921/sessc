import React,{useState} from 'react'
import './accounts.scss'
import Icon from 'react-icons-kit';
import { plus } from 'react-icons-kit/entypo/plus'
import { arrowLeft } from 'react-icons-kit/fa/arrowLeft'

const Accounts = (props:any) => {
    const [isAddingNewAccount,setIsAddingNewAccount] = useState(false);
  return (
    <div className='accounts'>
        <div className="row heading-section">
                <div className="col-md-6"><h3 className="heading m-0 lh-base"><button className='btn btn-main border-0' onClick={props.todoFunc}><Icon  className='icons' icon={arrowLeft} size="25" /></button>Accounts</h3></div>
                <div className="col-md-6">
                    <div className='d-flex flex-row-reverse'>
                        <button className="btn btn-outline-light  rounded rounded-3 ms-3" onClick={()=>{setIsAddingNewAccount(!isAddingNewAccount)}}>
                            <Icon icon={plus} size="25" />Add New Account
                        </button>
                        <form className="d-flex" key={"account-list-search"}>
                            <input className="form-control me-2  rounded rounded-3 search-input-width" type="search" placeholder="Search" aria-label="Search" />
                            <button className="btn btn-outline-light  rounded rounded-3" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
    </div>
  )
}

export default Accounts