import React from 'react';
import FormView from './form-view';
import TableView from './table-view';


export const Bookkeeping = () => {
  const [formSubmitted, setFormSubmitted] = React.useState(false)
  const [rowData, setRowData] = React.useState();
  return (
    <div className='book-keeping'>
      <div className='row'>
        <div className='bookkeeping-form col-md-3'>
          <FormView setFormSubmitted={setFormSubmitted} rowData={rowData} />   
          </div>
        <div className='bookkeeping-table col-md-9'>
          <TableView formSubmitted={formSubmitted} setRowData={setRowData}/>
        </div>
      </div>
    </div>
  )
}
