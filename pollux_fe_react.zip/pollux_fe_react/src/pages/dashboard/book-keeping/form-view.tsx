import React from 'react'
import { useFormik } from 'formik';
import MainService from '../../../services/main-service';
import { Alert } from 'react-bootstrap';
let isEditing = false
let value:any;
const FormView = (props: any) => {
  const mainService = new MainService("");
  var [reload, setReload] = React.useState(false);
  var [txnId, setTxnId] = React.useState("");
  var [showError,setShowError] = React.useState(false);
  var [errorMsg,setErrorMsg] = React.useState("");
  var [data, setData]= React.useState();
  var [paymentMode, setPaymentMode] = React.useState('');
  const bookkeepingDetails = useFormik({
    initialValues: {
      accountId: "",
      amount: "",
      mode: "",
      indicator: "",
      notes: "",
      fundingAccount: "",
      createOn: ""
    },
    onSubmit: (values: any, { resetForm }) => {
      console.log(values);
      if (isEditing) {
        isEditing = false
        setData(values);
      } else {
        sendDate(values);
      }
      
      
    }
  });
  

  function resetCurrentForm(){
    bookkeepingDetails.values.accountId = "";
      bookkeepingDetails.values.amount = "";
      bookkeepingDetails.values.mode = "";
      bookkeepingDetails.values.indicator = "";
      bookkeepingDetails.values.notes = "";
      bookkeepingDetails.values.fundingAccount = "";
      bookkeepingDetails.values.createdOn = "";
  }

  React.useEffect(()=>{
    deactivateRecord(txnId, data);
    
  },[data])

  

  React.useEffect(() => {
    console.log(props.rowData);
    if (props.rowData != undefined || props.rowData != null) {
      setTxnId(props.rowData.id);
      bookkeepingDetails.values.accountId = props.rowData.accountId;
      bookkeepingDetails.values.amount = props.rowData.amount;
      bookkeepingDetails.values.mode = props.rowData.mode;
      bookkeepingDetails.values.indicator = props.rowData.indicator;
      bookkeepingDetails.values.notes = props.rowData.notes;
      bookkeepingDetails.values.fundingAccount = props.rowData.fundingAccount;
      bookkeepingDetails.values.createdOn = props.rowData.createdOn;
      isEditing = true
    }
    
    setReload(!reload);
  }, [props])

  React.useEffect(()=>{
    isEditing = false
  },[])

  async function sendDate(values: any) {
    console.log(values);
    let url = "transaction";
    let newAcc = (values.accountId+"").toLowerCase();
    let memId = "";
    if((newAcc+"").startsWith('sm') || (newAcc+"").startsWith('tf')) {
      newAcc = newAcc.substring(2);
    } else {

    }
    let data = {
      "accountId": values.accountId,
      "amount": values.amount,
      "indicator": values.indicator,
      "mode": paymentMode,
      "fundingAccount": values.fundingAccount,
      "notes": values.notes,
      "memberId": parseFloat(newAcc),
      "createdOn": values.createdOn
    }
    try {
      let response = await mainService.postRequest(url, data, null);
      console.log(response);
      props.setFormSubmitted(true);
      resetCurrentForm();
    setReload(!reload);
      setTimeout(() => {
        props.setFormSubmitted(false);
      }, 2000)
    }
    catch (e: any) {
      if(e.status === 400){
        setErrorMsg(e.data.msg);
        setShowError(true);
        resetCurrentForm();
    setReload(!reload);
      }
      
    }
  }

  const handlePaymentMode = (e: any) => {
    setPaymentMode(e.target.value);
    bookkeepingDetails.values.mode = e.target.value;
    if(e.target.value == "Cash" || e.target.value == "Cash_Transfer_Account") {
      bookkeepingDetails.values.fundingAccount = "CASH_IN_HAND"
    } else {
      bookkeepingDetails.values.fundingAccount = "SBI"
    }
}

  async function editValueSend1(values: any) {
    console.log(values);
    let url = "transaction";
    let newAcc = (values.accountId+"").toLowerCase();
    let memId = "";
    if((newAcc+"").startsWith('sm') || (newAcc+"").startsWith('tf')) {
      newAcc = newAcc.substring(2);
    } else {

    }
    let data = {
      "accountId": values.accountId,
      "amount": values.amount,
      "indicator": values.indicator,
      "mode": paymentMode,
      "fundingAccount": values.fundingAccount,
      "notes": values.notes,
      "memberId": parseFloat(newAcc),
      "createdOn": values.createdOn
    }
    console.log(data);
    
    try {
      let response = await mainService.postRequest(url, data, null);
      console.log(response);
      props.setFormSubmitted(true);
      resetCurrentForm();
    setReload(!reload);
      setTimeout(() => {
        props.setFormSubmitted(false);
      }, 2000)
    }
    catch (e: any) {
      console.log(e);
      resetCurrentForm();
    setReload(!reload);
    }
  }

  async function deactivateRecord(id: any, values:any) {
    let url = `transaction/deactivate/${id}`;
    try {
      let response = await mainService.patchRequest(url, null, null);
      if(response.status === 200){
        editValueSend1(values);
      }
    }
    catch (e: any) {
      console.log(e);
    }
  }

  

  return (
    <div className="form-body">
      <div className="row">
        <div className="form-holder">
          <div className="form-content">
            <div className="form-items">
              <h3 className='text-white'> Book keeping</h3>
              <form className="requires-validation" onSubmit={bookkeepingDetails.handleSubmit}>
                <div className="col-md-12">
                  <input className="form-control my-1 fs-6"
                    id="accountId"
                    name="accountId"
                    type="text"
                    onChange={bookkeepingDetails.handleChange}
                    value={bookkeepingDetails.values.accountId}
                    placeholder="Account Id"
                    required
                    disabled={isEditing}
                  />
                </div>
                <div className="col-md-12">
                  <input className="form-control my-1 fs-6"
                    id="amount"
                    name="amount"
                    type="text"
                    placeholder="Amount"
                    onChange={bookkeepingDetails.handleChange}
                    value={bookkeepingDetails.values.amount}
                    required
                  />
                </div>

                <div className="col-md-12">
                  <select className="form-select my-1 fs-6" id="indicator"
                    name="indicator" onChange={bookkeepingDetails.handleChange} required value={bookkeepingDetails.values.indicator}>
                    <option disabled value="">--Select Debit / Credit--</option>
                    <option value="Debit">Debit</option>
                    <option value="Credit">Credit</option>
                  </select>
                </div>

                <div className="col-md-12">
                  <select className="form-select my-1 fs-6" id="mode"
                    name="mode" onChange={handlePaymentMode}
                    value={paymentMode} required>
                    <option disabled value="">--Select Mode--</option>
                    {['Cash', 'UPI', 'Bank_Transfer', 'Cheque', 'Cash_Transfer_Account'].map((item, index) => <option key={index} value={item}>{item}</option>)}

                  </select>
                </div>

                <div className="col-md-12">
                  <select className="form-select my-1 fs-6" id="fundingAccount"
                    name="fundingAccount" onChange={bookkeepingDetails.handleChange} required value={bookkeepingDetails.values.fundingAccount}>
                    <option disabled value="">--Select SBI / DCB--</option>
                    <option value="SBI">SBI C/A 10674451044</option>
                    <option value="DCB" disabled={true}>DCB C/A SOC-154</option>
                    <option value="CASH_IN_HAND">Cash In Hand</option>
                  </select>
                </div>

                <div className="col-md-12">
                  <input className="form-control my-1 fs-6"
                    id="createdOn"
                    name="createdOn"
                    type="Date"
                    placeholder="CreatedOn"
                    onChange={bookkeepingDetails.handleChange}
                    value={bookkeepingDetails.values.createdOn}
                  />
                </div>

                <div className="col-md-12">
                  <textarea className="form-control my-1 fs-6" name="notes" rows={4} placeholder="Notes" required onChange={bookkeepingDetails.handleChange} value={bookkeepingDetails.values.notes} />

                </div>

                <div className="form-button mt-3">
                  {<button id="submit" type="submit" className="btn btn-outline-light">{!isEditing ? <span>Add Book Keeping</span>: <span>Edit Book Keeping</span> }</button>
                  }
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      {
        showError && <Alert className='error-alert' variant="danger" onClose={() => setShowError(false)} dismissible>
        <Alert.Heading>Oh snap! Something went wrong!</Alert.Heading>
        <p>
          {errorMsg}
        </p>
      </Alert>
      }
    </div>


  )
}

export default FormView;