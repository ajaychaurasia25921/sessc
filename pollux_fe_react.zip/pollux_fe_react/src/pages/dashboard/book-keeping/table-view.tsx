import * as React from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import './book-keeping.scss';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { ic_mode_edit } from 'react-icons-kit/md/ic_mode_edit';
import Icon from 'react-icons-kit';
import { Button, Modal } from 'react-bootstrap';




type Rows = { id: string, amount: number, balance: number, mode: string, fundingAccount: string, indicator: string, notes: string, createdOn: string, createdBy: string, accountId: string }

const TableView = (props: any) => {
  
  const [rowsData, setRows] = React.useState(Array);
  const mainService = new MainService("");
  const [numberOfRows, setNumberOfRows] = React.useState(10);
  const [pageSize, setPageSize] = React.useState(0);
  var [recordsSize, setRecordsSize] = React.useState(10);
  var [totalElement, setTotalElement] = React.useState(0);
  var [isLoading, setIsLoading] = React.useState(false);
  var [hasNext, setHasNext] = React.useState(false);
  var [hasPrevious, setHasPrevious] = React.useState(false);
  var [txnId, setTxnId] = React.useState("");
  const [deleteModal, setDeleteModal] = React.useState(false);
  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Txn Id', width: 110 },
    { field: 'accountId', headerName: 'Account Id', width: 150 },
    { field: 'amount', headerName: 'Amount', width: 150 },
    { field: 'balance', headerName: 'Balance', width: 150 },
    { field: 'mode', headerName: 'Mode', width: 150 },
    { field: 'indicator', headerName: 'DR | CR.', width: 150 },
    { field: 'fundingAccount', headerName: 'Funding Account', width: 150 },
    { field: 'notes', headerName: 'Notes', width: 150 },
    { field: 'createdOn', headerName: 'Created On', width: 150 },
    { field: 'createdBy', headerName: 'Created By', width: 150 },
    {
      field: 'Actions',
      width: 130,
      sortable: false,

      renderCell: (params) => {
        function deActivateRecord() {
          console.log(params.row.id);
          setTxnId(params.row.id);
          setDeleteModal(!deleteModal);
        };
        function viewRecord() {
          console.log(params.row);
          props.setRowData(params.row);
        }

        return (
          <>
            <button className="btn p-0" onClick={() => viewRecord()} title="Edit"><Icon icon={ic_mode_edit} size="25" /></button>
            <button className="btn p-0" onClick={() => deActivateRecord()} title="Deactivate"><img className="mx-1" src="/assets/remove.svg" alt="" /></button>
          </>
        );
      },
    }
  ];
  React.useEffect(() => {
    getRows(10, 0);
  }, [])

  React.useEffect(() => {
    if (props.formSubmitted) {
      getRows(10, 0);
    }
  }, [props.formSubmitted])

  async function deactivateRecord(id: any) {
    let url = `transaction/deactivate/${id}`;
    try {
      let response = await mainService.patchRequest(url, null, null);
      console.log(response);
    }
    catch (e: any) {
      console.log(e);
    }
  }

  async function getRows(rowSize: number, pageSize: number) {
    console.log(rowSize, pageSize);
    let url = `transaction?size=${rowSize}&page=${pageSize}`;
    let abc: any[] = [];
    try {
      let response = await mainService.getRequest(url, null, null);
      console.log(response);
      setTotalElement(response.data.totalElements);
      setHasNext(response.data.hasNext);
      setHasPrevious(response.data.hasPrevious);
      setNumberOfRows(response.data.size);
      setRows([]);
      response.data.content.forEach((element: any) => {
        let data: Rows = {
          id: element.transactionId,
          amount: element.amount,
          balance: element.balance,
          mode: element.mode,
          indicator: element.indicator,
          notes: element.notes,
          fundingAccount: element.fundingAccount ? element.fundingAccount : "NA",
          createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
          createdBy: element.createdBy,
          accountId: element.accountId
        }
        if (data.accountId.includes("fd") || data.accountId.includes("rd") || data.accountId.includes("la")) {
          console.warn("FD , RD or LA not allowed");
        } else {
          abc.push(data);
        }

      });
      setRows(abc);
    }
    catch (e: any) {
      console.log(e);
    }
  }

  React.useEffect(() => {
    setNumberOfRows(10);
  }, []);


  function txnDataNext() {
    setPageSize(pageSize + 1);
    console.log(pageSize)
    getRows(recordsSize, pageSize + 1);
    setIsLoading(true);
  }

  function txnDataPrevious() {
    setPageSize(pageSize - 1);
    console.log(pageSize)
    getRows(recordsSize, pageSize - 1);
    setIsLoading(true);
  }

  function DeleteModalView(props: any) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header className='d-block text-center'>
          <Modal.Title id="contained-modal-title-vcenter">
            Are you sure want to <strong className='text-danger'>Delete</strong> the Transaction.
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className='d-block text-center'>
          <p>
            You are about to delete transaction <strong>{txnId}</strong>. This process is irrevesable!
          </p>
        </Modal.Body>
        <Modal.Footer className='d-block text-center'>
          <Button variant="outline-secondary" onClick={() => { setDeleteModal(!deleteModal) }}>Cancel</Button>
          <Button variant="danger" onClick={() => {deactivateRecord(txnId); setDeleteModal(!deleteModal); getRows(10, 0);}}>Delete</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  return (


    rowsData ?
      <div>
        <div className='d-flex mb-2 flex-row-reverse'>
          <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
            <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
            <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
            <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
          </div>
          <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
        </div>
        <div className="text-white bg-white table-view" id='tableView'>
          <DataGrid
            className=''
            rows={rowsData as any}
            columns={columns}
            pageSize={numberOfRows}
            getRowId={(row) => row.id}
            hideFooter={true}
          />
        </div>
        {
          deleteModal && <DeleteModalView show={deleteModal} onHide={() => setDeleteModal(false)} />
        }
      </div>
      : <></>

  );
}

export default TableView;