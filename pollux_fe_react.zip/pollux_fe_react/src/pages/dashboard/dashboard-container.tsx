import React, { Suspense } from "react";
import "./dashboard.scss";
import { Icon } from 'react-icons-kit';
import { threeVertical } from 'react-icons-kit/entypo/threeVertical'
import TodoList from "./todo-list/todo-list";
import Members from "./members/members";
import Accounts from "./accounts/accounts";
import ErrorBoundary from "../../shared/error-boundary/error-boundary";
import { Bookkeeping } from "./book-keeping/book-keep";
import { Loan } from "./loan/loan";
import {FixedDeposit} from './FD/fd';
import { RecurringDeposit } from './RD/rd';

const DashboardContainer = (props: any) => {
    const [currentViewType, setCurrentViewType] = React.useState("Members");
    
    React.useEffect(()=>{
        setCurrentViewType(props.currentOption);
        console.log(props.currentOption);
        
    },[props])

    return (
        <main className="dashboard">
            <section className="dynamic-view">
                <Suspense fallback={<div>Loading...</div>}>
                    <div>
                        {
                            currentViewType === "Members" ? <Members /> : <></>
                        }
                        {
                            currentViewType === "Book-keeping" ? <Bookkeeping /> : <></>
                        }
                        {
                            currentViewType === "Loan" ? <Loan /> : <></>
                        }
                        {
                            currentViewType === "FD" ? <FixedDeposit /> : <></>
                        }
                        {
                            currentViewType === "RD" ? <RecurringDeposit /> : <></>
                        }
                    </div>
                </Suspense>
            </section>
        </main>)
}

export default DashboardContainer;