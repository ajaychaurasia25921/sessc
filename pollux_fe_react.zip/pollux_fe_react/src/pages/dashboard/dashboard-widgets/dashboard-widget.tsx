
import React from "react";
import { Button, OverlayTrigger, Tooltip } from "react-bootstrap";
import "./widgets.scss";

const DashboardWidgets = (props: any) => {
    
    function setOption(option:string){
        props.getSelectedSection(option);
    }
    React.useEffect(()=>{
        //setOption("Members");
    },[]);
    return (
        <div>
            <div className="button-with-tooltip">
                
                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Member
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light" onClick={()=>setOption("Members")}>
                        <img className="core-item-img" src="/assets/members.svg" alt="" />
                    </Button>
                </OverlayTrigger>
                
                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Book Keeping
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light" onClick={()=>setOption("Book-keeping")}>
                        <img className="core-item-img" src="/assets/manual.svg" alt="" />
                    </Button>
                </OverlayTrigger>

                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Loan
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light" onClick={()=>setOption("Loan")}>
                        <img className="core-item-img" src="/assets/loan.svg" alt="" />
                    </Button>
                </OverlayTrigger>

                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            FD
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light" onClick={()=>setOption("FD")}>
                        <img className="core-item-img" src="/assets/fdrd.svg" alt="" />
                    </Button>
                </OverlayTrigger>
				<OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Recurring Deposit
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light" onClick={()=>setOption("RD")}>
                        <img className="core-item-img" src="/assets/rd.svg" alt="" />
                    </Button>
                </OverlayTrigger>
                <div className="dev-details">
                    <hr />
                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Infromation
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light">
                        <img className="core-item-img" src="/assets/info.svg" alt="" />
                    </Button>
                </OverlayTrigger>
                <OverlayTrigger
                    placement="right"
                    overlay={
                        <Tooltip id="tooltip-right">
                            Contact
                        </Tooltip>
                    }
                >
                    <Button className="btn btn-light">
                        <img className="core-item-img" src="/assets/message.svg" alt="" />
                    </Button>
                </OverlayTrigger>
                </div>
            </div>
        </div>
    )
}
export default DashboardWidgets;