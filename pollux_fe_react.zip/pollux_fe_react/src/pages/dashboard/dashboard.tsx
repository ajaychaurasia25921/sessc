import React from 'react';
import DashboardContainer from './dashboard-container';
import Widgets from './dashboard-widgets/dashboard-widget';

const Dashboard = (props:any) => {
  const [isToggle, setIsToggle] = React.useState(false)
  const [currentOption, setCurrentOption] = React.useState("Members");

  const toggleCalender = () => {
    setIsToggle(!isToggle)
  }

  React.useEffect(() => {
    props.headerFunc(true);
    props.footerFunc(true);
}, []);

  const getSelectedSection=(option:string)=>{
    setSelectedSection(option);
  }
function setSelectedSection(option:string){
  if(option){
     setCurrentOption(option)
  }else{
    setCurrentOption("Members");
  }
  
}
  return (
    <>
      <div className='outlet-view'>
        <div className="widget-view row g-0">
          <div className={"widgets-slim col"}>
            <Widgets getSelectedSection={getSelectedSection} />
          </div>
          <div className='main-view ps-2 col-auto'>
              <DashboardContainer currentOption={currentOption} />
          </div>
        </div>
      </div>
    </>
  );
}

export default Dashboard;
