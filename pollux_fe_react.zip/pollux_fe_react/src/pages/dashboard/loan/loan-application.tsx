import React, { useState } from 'react';
import './loan.scss';
import optionsCredit from "../../../data/loanCreditOptions.json";
import stateArr from '../../../data/state.json';
import MainService from '../../../services/main-service';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used
import { LoanCreation } from './loan-creation';
import dateFormat from "dateformat";
import { propTypes } from 'react-bootstrap/esm/Image';

const mainService = new MainService("");


type Guarantor = {
    introducerId: number,
    name: string,
    personalNumber: string,
    ticketNumber: string,
    section: string,
    post: string
}
export const LoanApplication = (props: any) => {
    var [memberName, setMemberName] = React.useState('');
    var [ticketNumber, setTicketNumber] = React.useState('');
    var [section, setSection] = React.useState('');
    var [post, setPost] = React.useState('');
    var [personalNumber, setPersonalNumber] = React.useState('');
    var [contactNumber, setContactNumber] = React.useState('');
    var [dob, setDOB] = React.useState('');
    var [creditValid, setCreditValid] = React.useState('Share Money');
    var [commonMemberId, setCommonMemberId] = React.useState('');
    var [mailingAddressLine1, setMailingAddressLine1] = React.useState('');
    var [mailingCity, setMailingCity] = React.useState('');
    var [mailingState, setMailingState] = React.useState('');
    var [mailingDistrict, setMailingDistrict] = React.useState('');
    var [mailingPinCode, setMailingPinCode] = React.useState('');
    var [mailingContact, setMailingContact] = React.useState('');
    var [permanentAddressLine1, setPermanentAddressLine1] = React.useState('');
    var [permanentCity, setPermanentCity] = React.useState('');
    var [permanentState, setPermanentState] = React.useState('');
    var [permanentDistrict, setPermanentDistrict] = React.useState('');
    var [permanentPinCode, setPermanentPinCode] = React.useState('');
    var [permanentContact, setPermanentContact] = React.useState('');
    var [grossSalary, setGrossSalary] = React.useState('');
    var [shareMoney, setShareMoney] = React.useState('');
    var [fixedDeposit, setFD] = React.useState('');
    var [creditLimit, setCreditLimit] = React.useState('');
    var [remainingLoan, setRemainingLoan] = React.useState('');
    var [tenure, setTenure] = React.useState('');
    var [dateOfAppointment, setDateOfAppointment] = React.useState('');
    var [dateOfRetirement, setDateOfRetirement] = React.useState('');
    var [requiredLoanAmount, setRequiredLoanAmount] = React.useState('');
    var [reasonForLoan, setReasonForLoan] = React.useState('');
    var [monthlyDeduction, setMonthlyDeduction] = React.useState('');
    var [createdOnDate, setCreatedOn] = React.useState('');
    var [existingGuaranterArr, setExistingGuaranterArr] = React.useState(Array<any>());
    var [memberIdSearch, setMemberIdSearch] = React.useState('');
    var [memberSearchArr, setSearchMemberArr] = React.useState(Array<any>());
    var [memberPhoto, setMemberPhoto] = React.useState('');
    var [memberSignature, setMemberSignature] = React.useState('');
    var [memberData, setMemberData] = React.useState();
    var [disableSaveButton, setDisableSaveButton] = React.useState(true);
    var [showAlert, setShowAlert] = React.useState(false);
    var [alertMessage, setAlertMessage] = React.useState('');
    var [creditValidValue, setCreditValidValue] = React.useState('');
    var [showSuccessDialog, setShowSuccessDialog] = React.useState(false);
    var [loanApplicationResponse, setLoanApplicationResponse] = React.useState();
    var [loanAccountBalance, setLoanAccountBalance] = React.useState("");
    var [tempvar, setTempVar] = React.useState("");
    var [shareMoneyOnLoad, setShareMoneyOnLoad] = React.useState('');
    

    React.useEffect(() => {
        calculateRemainingLoan();
        // setShowSuccessDialog(true);

    }, [requiredLoanAmount, creditLimit]);

    React.useEffect(() => {
        handleCreditValidLoad();

    }, [shareMoneyOnLoad]);

    React.useEffect(() => {
        console.log(requiredLoanAmount)
        console.log(monthlyDeduction)
        if(requiredLoanAmount && monthlyDeduction) {
            setTenure(Math.ceil((parseFloat(requiredLoanAmount)/parseFloat(monthlyDeduction)))+"")
        } else {
            setTenure('')
        }

    }, [monthlyDeduction]);

    //Handlers
    const handleCommonMemberId = (e: any) => {
        setCommonMemberId(e.target.value);
    }
    const handleMemberName = (e: any) => {
        setMemberName(e.target.value)
    }
    const handleTicketnumber = (e: any) => {
        setTicketNumber(e.target.value)
    }
    const handleSection = (e: any) => {
        setSection(e.target.value)
    }
    const handlePost = (e: any) => {
        setPost(e.target.value)
    }
    const handlePersonalNumber = (e: any) => {
        setPersonalNumber(e.target.value)
    }
    const handleContactNumber = (e: any) => {
        setContactNumber(e.target.value)
    }
    const handleDOB = (e: any) => {
        setDOB(e.target.value);
    }
    const handleCreditValid = (e: any) => {
        setCreditValid(e.target.value)
        if (e.target.value == "Share Money") {
            setCreditValidValue("Share_Money");
            let balance = parseInt(shareMoney);
            let multiplier = 0;
            if (balance > 0) {
                for (let el of optionsCredit) {
                    if (el.name == e.target.value) {
                        multiplier = el.param;
                    }
                }
                setCreditLimit((Math.round(balance * multiplier) - Math.round(parseFloat(loanAccountBalance ? loanAccountBalance : "0"))) + "");
                if ((balance * multiplier) >= parseInt(requiredLoanAmount)) {
                    setRemainingLoan(((balance * multiplier) - parseInt(requiredLoanAmount)) + "")
                }
            } else {
                setCreditLimit("0");
                setRemainingLoan('0');
                displayAlert("User must have Share Money Balance or must Open FD.");
            }
        }
        if (e.target.value == "Fixed Deposit") {
            setCreditValidValue("Fixed_Deposit");

            let balance = parseInt(fixedDeposit);
            let multiplier = 0;
            if (balance > 0) {
                for (let el of optionsCredit) {
                    if (el.name == e.target.value) {
                        multiplier = el.param;
                    }
                }
                setCreditLimit(((balance * multiplier) - parseFloat(loanAccountBalance? loanAccountBalance:"0")) + "");
                if ((balance * multiplier) >= parseInt(requiredLoanAmount)) {
                    setRemainingLoan(((balance * multiplier) - parseInt(requiredLoanAmount)) + "")
                }
            } else {
                setCreditLimit("0");
                setRemainingLoan('0');
                displayAlert("User must have Share Money Balance or must Open FD.");
            }
        }
        checkDisabilityOfSaveBtn();
    }

    const handleMailingAddressLine1 = (e: any) => {
        setMailingAddressLine1(e.target.value);
    }
    const handleMailingCity = (e: any) => {
        setMailingCity(e.target.value);
    }
    const handleMailingDistrict = (e: any) => {
        setMailingDistrict(e.target.value);
    }
    const handleMailingState = (e: any) => {
        setMailingState(e.target.value);
    }
    const handleMailingPinCode = (e: any) => {
        setMailingPinCode(e.target.value);
    }
    const handleMailingContact = (e: any) => {
        setMailingContact(e.target.value);
    }
    const handlePermanentAddressLine1 = (e: any) => {
        setPermanentAddressLine1(e.target.value);
    }
    const handlePermanentCity = (e: any) => {
        setPermanentCity(e.target.value);
    }
    const handlePermanentDistrict = (e: any) => {
        setPermanentDistrict(e.target.value);
    }
    const handlePermanentState = (e: any) => {
        setPermanentState(e.target.value);
    }
    const handlePermanentPinCode = (e: any) => {
        setPermanentPinCode(e.target.value);
    }
    const handlePermanentContact = (e: any) => {
        setPermanentContact(e.target.value);
    }
    const handleGrossSalary = (e: any) => {
        setGrossSalary(e.target.value);
    }
    const handleShareMoney = (e: any) => {
        setShareMoney(e.target.value);
    }
    const handleFD = (e: any) => {
        setFD(e.target.value);
    }
    const handleCreditLimit = (e: any) => {
        setCreditLimit(e.target.value);
    }
    const handleRemainingLoan = (e: any) => {
        setRemainingLoan(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleTenure = (e: any) => {
        setTenure(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleDateOfAppointment = (e: any) => {
        setDateOfAppointment(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleDateOfRetirement = (e: any) => {
        setDateOfRetirement(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleRequiredLoanAmount = (e: any) => {
        setRequiredLoanAmount(e.target.value);
        calculateRemainingLoan();
        checkDisabilityOfSaveBtn();
    }
    const handleReasonForLoan = (e: any) => {
        setReasonForLoan(e.target.value);
        checkDisabilityOfSaveBtn();
    }

    const handleCreatedOnDate = (e: any) => {
        setCreatedOn(e.target.value);
        checkDisabilityOfSaveBtn();
    }

    const handleMonthlyDeduction = (e: any) => {
        setMonthlyDeduction(e.target.value);
        checkDisabilityOfSaveBtn();
    }
    const handleMemberIdSearch = (e: any) => {
        setMemberIdSearch(e.target.value);
    }

    function displayAlert(message: string) {
        setAlertMessage(message)
        setShowAlert(true);
        setTimeout(() => {
            setShowAlert(false);
        }, 5000);
    }

    function handleCreditValidLoad() {
        console.log("credit valid value",creditValid)
        console.log("share money amount in load",shareMoney)

        if (creditValid == "Share Money") {
            setCreditValidValue("Share_Money");
            let balance = parseInt(shareMoney);
            let multiplier = 0;
            if (balance > 0) {
                for (let el of optionsCredit) {
                    if (el.name == creditValid) {
                        multiplier = el.param;
                    }
                }
                setCreditLimit((Math.round(balance * multiplier) - Math.round(parseFloat(loanAccountBalance ? loanAccountBalance : "0"))) + "");
                if ((balance * multiplier) >= parseInt(requiredLoanAmount)) {
                    setRemainingLoan(((balance * multiplier) - parseInt(requiredLoanAmount)) + "")
                }
            } else {
                setCreditLimit("0");
                setRemainingLoan('0');
                // displayAlert("User must have Share Money Balance or must Open FD.");
            }
        }
        // if (creditValid == "Fixed Deposit") {
        //     setCreditValidValue("Fixed_Deposit");

        //     let balance = parseInt(fixedDeposit);
        //     let multiplier = 0;
        //     if (balance > 0) {
        //         for (let el of optionsCredit) {
        //             if (el.name == creditValid) {
        //                 multiplier = el.param;
        //             }
        //         }
        //         setCreditLimit(((balance * multiplier) - parseFloat(loanAccountBalance? loanAccountBalance:"0")) + "");
        //         if ((balance * multiplier) >= parseInt(requiredLoanAmount)) {
        //             setRemainingLoan(((balance * multiplier) - parseInt(requiredLoanAmount)) + "")
        //         }
        //     } else {
        //         setCreditLimit("0");
        //         setRemainingLoan('0');
        //         displayAlert("User must have Share Money Balance or must Open FD.");
        //     }
        // }
        checkDisabilityOfSaveBtn();
    }

    function calculateRemainingLoan() {
        if ((parseInt(creditLimit) - parseInt(requiredLoanAmount)) >= 0) {
            setRemainingLoan((parseInt(creditLimit) - parseInt(requiredLoanAmount)) + "")
        }
        if (parseInt(requiredLoanAmount) > parseInt(creditLimit)) {
            displayAlert("Required loan amount must be less than your credit limit.")
        }
    }

    async function checkFormSubmition() {
        let newGuarantorArr = [];
        for (let s of existingGuaranterArr) {
            newGuarantorArr.push(s.memberId +" "+s.personalDetail.firstName+" "+s.personalDetail.lastName);
        }

        let userInput = {
            "creditValidFrom": creditValidValue,
            "smAmount": parseFloat(shareMoney),
            "fdAmount": parseFloat(fixedDeposit),
            "creditLimit": parseFloat(creditLimit),
            "remainingLoan": parseFloat(remainingLoan),
            "tenure": tenure,
            "dateOfAppointment": dateOfAppointment,
            "dateOfRetirement": dateOfRetirement,
            "requiredLoanAmount": parseFloat(requiredLoanAmount),
            "reasonForLoan": reasonForLoan,
            "memberId": memberData ? memberData['memberId'] + "" : "",
            "guarantor": newGuarantorArr,
            "monthlyDeduction": monthlyDeduction,
            "createdOn" : createdOnDate
        }
        let url = "loan/application";
        let response = await mainService.postRequest(url, userInput, null);
        console.log(response);
        setLoanApplicationResponse(response.data);
        if (response.status == 200) {
            setShowSuccessDialog(true);
            let anyObj: any = ""
            setMemberData(anyObj);
        }
        resetFormSubmition();
    }

    const resetFormSubmition = () => {
        setCommonMemberId("");
        setMemberName(''); setTicketNumber(''); setSection(''); setPost(''); setPersonalNumber(''); setContactNumber('');
        setDOB(''); setCreditValid(''); setMailingAddressLine1(''); setMailingCity(''); setMailingState('');
        setMailingDistrict(''); setMailingPinCode(''); setMailingContact(''); setPermanentAddressLine1('');
        setPermanentCity(''); setPermanentState(''); setPermanentDistrict(''); setPermanentPinCode('');
        setPermanentContact(''); setGrossSalary(''); setShareMoney(''); setFD(''); setCreditLimit('');
        setRemainingLoan(''); setTenure(''); setDateOfAppointment(''); setDateOfRetirement('');
        setRequiredLoanAmount(''); setReasonForLoan(''); setExistingGuaranterArr([]); setMemberIdSearch('');
        setMemberPhoto(''); setMemberSignature(''); setCreatedOn('');
    }

    function checkDisabilityOfSaveBtn() {
        if ((creditValid && creditValid != '')
            && (shareMoney && shareMoney != '')
            && (fixedDeposit && fixedDeposit != '')
            && (creditLimit && creditLimit != '')
            && (remainingLoan && remainingLoan != '')
            && (tenure && tenure != '')
            && (dateOfAppointment && dateOfAppointment != '')
            && (requiredLoanAmount && requiredLoanAmount != '')
            && (monthlyDeduction && monthlyDeduction != '')
            && (reasonForLoan && reasonForLoan != '') && 
            (parseFloat(creditLimit) >= parseFloat(requiredLoanAmount)) && parseFloat(creditLimit) >= 0) {
            setDisableSaveButton(false);
        } else {
            setDisableSaveButton(true);
        }
    }

    async function getDetailsFromMemeberID() {
        try {
            let url = `member/${commonMemberId}`;
            let data = await mainService.getRequest(url, null, null);
            assignFormValues(data);
        } catch (e: any) {
            console.log(e)
        }
    }
    const assignFormValues = (data: any) => {
        data = data.data;
        setMemberData(data);
        setMemberName(data.personalDetail.firstName + " " + data.personalDetail.lastName);
        setTicketNumber(data.officialDetail.ticketNumber);
        setPost(data.officialDetail.post);
        setSection(data.officialDetail.section);
        let newD = dateFormat(data.personalDetail.dateOfBirth, "yyyy-mm-dd");
        setDOB(newD);
        const dateOfRe = new Date(data.personalDetail.dateOfBirth);
        dateOfRe.setFullYear(dateOfRe.getFullYear() + 60);
        let newDOR = dateFormat(dateOfRe, "yyyy-mm-dd");
        setDateOfRetirement(newDOR);
        setPersonalNumber(data.personalDetail.personalDetailId + "");
        setContactNumber(data.personalDetail.contactNumber);
        setCreditValid(creditValid);
        setMemberPhoto(data.memberPhoto);
        setMemberSignature(data.memberSignature);

        //address
        setMailingAddressLine1(data.memberAddress.mailing.addressLine1);
        setMailingCity(data.memberAddress.mailing.postOrCity);
        setMailingState(data.memberAddress.mailing.state);
        setMailingDistrict(data.memberAddress.mailing.district);
        setMailingPinCode(data.memberAddress.mailing.pinCode);
        setMailingContact(data.memberAddress.mailing.contact);
        setPermanentAddressLine1(data.memberAddress.permanent.addressLine1);
        setPermanentCity(data.memberAddress.permanent.postOrCity);
        setPermanentState(data.memberAddress.permanent.state);
        setPermanentDistrict(data.memberAddress.permanent.district);
        setPermanentPinCode(data.memberAddress.permanent.pinCode);
        setPermanentContact(data.memberAddress.permanent.contact);
        //SM
        let balanceSM = 0;
        for (let s of data.account) {
            if (s.type == "Share_Money") {
                balanceSM = balanceSM + s.accountBalance;
            }
            if (s.type == "Loan") {
                setLoanAccountBalance(s.accountBalance);
            }
        }
        if (balanceSM > 0) {
            console.log("ShareMoney non zero",balanceSM)
            setShareMoney(balanceSM + "");
            setShareMoneyOnLoad(balanceSM + "");
        } else {
            console.log("ShareMoney zero",balanceSM)
            setShareMoney("0");
            setShareMoneyOnLoad("0");
        }
        //FD
        let balanceFD = 0;
        for (let s of data.account) {
            if (s.type == "Fixed_Deposit") {
                balanceFD = balanceFD + s.accountBalance;
            }
            if (s.type == "Loan") {
                setLoanAccountBalance(s.accountBalance);
            }
        }
        if (balanceFD > 0) {
            setFD(balanceFD + "");
        } else {
            setFD("0");
        }
        // setFD("0");
        setGrossSalary((data.officialDetail.grossSalary * 12) + "");
        setDateOfAppointment(dateFormat(data.officialDetail.appointmentDate, "yyyy-mm-dd"));

        setTimeout(()=> {
        setTempVar("empty")
        }, 2000);

        checkDisabilityOfSaveBtn();


    }

    function closeAlert() {
        setShowAlert(false);
    }

    async function getSearchedMemeberIdDetails() {
        if (memberIdSearch == commonMemberId) {
            displayAlert("Self can't be added as a guarantor.")
        } else {
            let url = `member/${memberIdSearch}`;
            let data = await mainService.getRequest(url, null, null);
            let memberArr = [];
            memberArr.push(data.data);
            setSearchMemberArr(memberArr);
        }
    }

    const addGuarantor = (obj: any) => {
        console.log(obj)
        for (let s of existingGuaranterArr) {
            if (s.memberId == obj.memberId) {
                let emptyarr: never[] = [];
                setSearchMemberArr([...emptyarr]);
                setMemberIdSearch('');
                displayAlert("Duplicate Guarantors can't be added.");
                return;
            }
        }
        if (existingGuaranterArr.length == 10) {
            let emptyarr: never[] = [];
            setSearchMemberArr([...emptyarr]);
            setMemberIdSearch('');
            displayAlert("Cannot add more than 10 Guarantors.");
            return;
        }
        existingGuaranterArr.push(obj);
        setExistingGuaranterArr([...existingGuaranterArr]);
        let emptyarr: never[] = [];
        setSearchMemberArr([...emptyarr]);
        setMemberIdSearch('');
    }

    const deleteGuarantor = (el: any) => {
        let index = 0;
        for (let s of existingGuaranterArr) {
            if (s.name == el.name && s.personalNumber == el.personalNumber) {
                break;
            }
            index++;
        }
        existingGuaranterArr.splice(index, 1);
        console.log(existingGuaranterArr);
        setExistingGuaranterArr([...existingGuaranterArr]);
    }

    const closeLoanApplicationModal = () => {
        setShowSuccessDialog(false);
    }


    return (
        <div>
            {
                showAlert ?
                    <div className="d-flex justify-content-end my-4 phx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessage}</span>
                                <button aria-label="Close" className='close close-position' type='button' data-dismiss="alert" onClick={() => closeAlert()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
            {
                showSuccessDialog ?
                    <div className="modal fade show" data-bs-backdrop="static" data-bs-keyboard="false" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Loan Application Saved</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeLoanApplicationModal()}></button>
                                </div>
                                <div className="modal-body">
                                    {
                                        loanApplicationResponse ?
                                        <div>
                                            <div>
                                                <span><strong>Loan Application ID: </strong></span>
                                                <span>{loanApplicationResponse['applicationId']}</span>
                                            </div>
                                            <div>
                                            <span><strong>Application Date: </strong></span>
                                                <span>{dateFormat(loanApplicationResponse['createdOn'], "mmmm dS, yyyy, h:MM:ss TT")}</span>
                                                </div>
                                            </div> : <></>
          }
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className="loan-application-content mt-3">
            <div className='container-fluid'>
                <div className="row">
                    <div className="col-lg-3"></div>
                    <div className="col-lg-6">
                        <div className="common-member-box">
                            <div className="input-group mx-5">
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="commonMemberID"
                                    name="commonMemberID"
                                    placeholder="Member ID"
                                    onChange={handleCommonMemberId}
                                    value={commonMemberId}
                                    aria-label="Member ID"
                                    aria-describedby="button-addon2" />
                                <button
                                    className="btn btn-outline-light"
                                    type="button"
                                    onClick={() => getDetailsFromMemeberID()}>Get Details</button>
                            </div>
                            <button type="button" id="saveApplication"
                                className="btn btn-outline-light"
                                disabled={disableSaveButton}
                                onClick={() => checkFormSubmition()}>
                                Save
                            </button>
                            <button type="button" id="resetApplication"
                                className="btn btn-outline-light mx-3"
                                // disabled={disableSaveButton}
                                onClick={() => resetFormSubmition()}>
                                Reset
                            </button>
                        </div>

                    </div>
                </div>
            </div>
            <br />
            {
                memberData ? <div>
                <div className="accordion" id="accordionPersonalDetails">
                <div className="accordion-item">
                    <h2 className="accordion-header" id="personalDetails">
                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePersonalDetails" aria-expanded="true" aria-controls="collapsePersonalDetails">
                            Personal Details
                        </button>
                    </h2>
                    <div id="collapsePersonalDetails" className="accordion-collapse collapse show" aria-labelledby="personalDetails" data-bs-parent="#accordionPersonalDetails">
                        <div className="accordion-body">
                            <table className='table'>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div className="container-fluid">
                                                <div className="row">
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Member Name</label>
                                                            <input type="text" autoComplete='off'
                                                                className="form-control"
                                                                id="memberName"
                                                                name="memberName"
                                                                placeholder="Member Name"
                                                                onChange={handleMemberName}
                                                                value={memberName} disabled readOnly />
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Ticket Number</label>
                                                            <input type="text" autoComplete='off'
                                                            className="form-control"
                                                                id="ticketNumber"
                                                                name="ticketNumber"
                                                                placeholder="Ticket Number"
                                                                onChange={handleTicketnumber}
                                                                value={ticketNumber} disabled readOnly />
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Section</label>
                                                            <input type="text" autoComplete='off'
                                                                className="form-control"
                                                                id="section"
                                                                name="section"
                                                                placeholder="Section"
                                                                onChange={handleSection}
                                                                value={section} disabled readOnly />
                                                        </div>
                                                    </div>

                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Post</label>
                                                            <input type="text"autoComplete='off'
                                                                className="form-control"
                                                                id="post" name="post"
                                                                placeholder="Post"
                                                                onChange={handlePost}
                                                                value={post} disabled readOnly />
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Personal Number</label>
                                                            <input type="text" autoComplete='off'
                                                                className="form-control"
                                                                id="personalNumber" name="personalNumber"
                                                                placeholder="Personal Number"
                                                                onChange={handlePersonalNumber}
                                                                value={personalNumber} disabled readOnly />
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Contact Number</label>
                                                            <input type="text" autoComplete='off'
                                                                className="form-control"
                                                                id="contactNumber" name="contactNumber"
                                                                placeholder="Phone No."
                                                                onChange={handleContactNumber}
                                                                value={contactNumber} disabled readOnly />
                                                        </div>
                                                    </div>

                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Date Of Birth</label>
                                                            <input className="form-control" autoComplete='off'
                                                                id="dateOfBirth"
                                                                name="dateOfBirth"
                                                                type="Date"
                                                                onChange={handleDOB}
                                                                value={dob}
                                                                placeholder="Date of Birth"
                                                                disabled readOnly
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-3">
                                                        <div className='pd-b-10 pd-r-5'>
                                                            <label className="form-label">Credit Valid From</label>
                                                            <select className="form-select"
                                                                aria-label="Default select example"
                                                                id="creditValid" name="creditValid"
                                                                onChange={handleCreditValid}
                                                                value={creditValid}>
                                                                {
                                                                    optionsCredit.map(el => <option value={el.name} key={(el.name).toString()} > {el.name} </option>)}
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <img className='uploaded-images' src={`data:image/png;image/jpg;image/jpeg;base64,${memberPhoto}`} alt="" srcSet="" />
                                            <br />
                                            <img className='uploaded-images' src={`data:image/png;image/jpg;image/jpeg;base64,${memberSignature}`} alt="" srcSet="" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div className="accordion" id="accordionAddressDetails">
                                <div className="accordion-item">
                                    <h2 className="accordion-header" id="LoanAddress">
                                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwow" aria-expanded="true" aria-controls="collapseTwow">
                                            Address
                                        </button>
                                    </h2>
                                    <div id="collapseTwow" className="accordion-collapse collapse show" aria-labelledby="LoanAddress" data-bs-parent="#accordionAddressDetails">
                                        <div className="accordion-body">
                                            <div className="container-fluid">
                                                <div className="row">
                                                    <div className="col-lg-12">
                                                        <form>

                                                            <div className='row g-3'>
                                                                <div className="col-md-6">
                                                                    <div className="row">
                                                                        <div className="col-12">
                                                                            <label htmlFor="title">Mailing Address</label>
                                                                            <input className="form-control my-1"
                                                                                autoComplete='off'
                                                                                id="mailingAddressLine1"
                                                                                name="mailingAddressLine1"
                                                                                type="text"
                                                                                onChange={handleMailingAddressLine1}
                                                                                value={mailingAddressLine1}
                                                                                 disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">City</label>
                                                                            <input className="form-control my-1"
                                                                                autoComplete='off'
                                                                                id="mailingCity"
                                                                                name="mailingCity"
                                                                                type="text"
                                                                                onChange={handleMailingCity}
                                                                                value={mailingCity}
                                                                                 disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">District</label>
                                                                            <input className="form-control my-1"
                                                                                id="mailingDistrict"
                                                                                autoComplete='off'
                                                                                name="mailingDistrict"
                                                                                type="text"
                                                                                onChange={handleMailingDistrict}
                                                                                value={mailingDistrict}
                                                                                 disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">State</label>
                                                                            <select className="form-select" id="mailingState"
                                                                                name="mailing.state" onChange={handleMailingState} value={mailingState} disabled>
                                                                                <option value="">--Select--</option>
                                                                                {
                                                                                    stateArr.map((element) => {
                                                                                        return <option value={element.state}>{element.state}</option>
                                                                                    })
                                                                                }
                                                                            </select>
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Country</label>
                                                                            <input className="form-control my-1"
                                                                                id="mailing.country"
                                                                                autoComplete='off'
                                                                                name="mailing.country"
                                                                                type="text"
                                                                                value="India"
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Pincode</label>
                                                                            <input className="form-control my-1"
                                                                                id="mailing.pinCode"
                                                                                autoComplete='off'
                                                                                name="mailing.pinCode"
                                                                                type="text"
                                                                                onChange={handleMailingPinCode}
                                                                                value={mailingPinCode}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Contact No.</label>
                                                                            <input className="form-control my-1"
                                                                                id="mailing.contact"
                                                                                autoComplete='off'
                                                                                name="mailing.contact"
                                                                                type="text"
                                                                                onChange={handleMailingContact}
                                                                                value={mailingContact}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        {/* <div className="col-12">
                                        <input type="checkbox" name="sameAddress" onChange={() => setSameAddressValue()} />
                                        <label className="form-check-label ps-2" htmlFor="inlineRadio1">Keep Mailing Address as Permanent Address</label>
                                      </div> */}
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="row">
                                                                        <div className="col-12">
                                                                            <label htmlFor="title">Permanent Address</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.addressLine1"
                                                                                autoComplete='off'
                                                                                name="permanent.addressLine1"
                                                                                type="text"
                                                                                onChange={handlePermanentAddressLine1}
                                                                                value={permanentAddressLine1}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">City</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.postOrCity"
                                                                                autoComplete='off'
                                                                                name="permanent.postOrCity"
                                                                                type="text"
                                                                                onChange={handlePermanentCity}
                                                                                value={permanentCity}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">District</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.district"
                                                                                autoComplete='off'
                                                                                name="permanent.district"
                                                                                type="text"
                                                                                onChange={handlePermanentDistrict}
                                                                                value={permanentDistrict}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">State</label>
                                                                            <select className="form-select" id="mailing.state"
                                                                                name="mailing.state" onChange={handlePermanentState} value={permanentState} disabled>
                                                                                <option value="">--Select--</option>
                                                                                {
                                                                                    stateArr.map((element) => {
                                                                                        return <option value={element.state}>{element.state}</option>
                                                                                    })
                                                                                }
                                                                            </select>
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Country</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.country"
                                                                                autoComplete='off'
                                                                                name="permanent.country"
                                                                                type="text"
                                                                                value="India"
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Pincode</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.pinCode"
                                                                                name="permanent.pinCode"
                                                                                autoComplete='off'
                                                                                type="text"
                                                                                onChange={handlePermanentPinCode}
                                                                                value={permanentPinCode}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>
                                                                        <div className="col-6">
                                                                            <label htmlFor="title">Contact No.</label>
                                                                            <input className="form-control my-1"
                                                                                id="permanent.contact"
                                                                                name="permanent.contact"
                                                                                autoComplete='off'
                                                                                type="text"
                                                                                onChange={handlePermanentContact}
                                                                                value={permanentContact}
                                                                                disabled readOnly
                                                                            />
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div></div>

                        </div>
                    </div>
                </div>
            </div>
            <br></br>
            <div className="accordion" id="accordionAccountDetails">
                <div className="accordion-item">
                    <h2 className="accordion-header" id="accountDetails">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAccountDetails" aria-expanded="false" aria-controls="collapseAccountDetails">
                            Account Details
                        </button>
                    </h2>
                    <div id="collapseAccountDetails" className="accordion-collapse collapse" aria-labelledby="accountDetails" data-bs-parent="#accordionAccountDetails">
                        <div className="accordion-body">
                            <div className='container-fluid'>
                                <div className='row'>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Gross Salary(Yearly)</label>
                                            <input type="text"
                                                className="form-control"
                                                id="grossSalary"
                                                name="grossSalary"
                                                autoComplete='off'
                                                placeholder="Gross Salary"
                                                onChange={handleGrossSalary}
                                                value={grossSalary} disabled readOnly />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Share Money</label>
                                            <input type="text"
                                                className="form-control"
                                                id="shareMoney"
                                                name="shareMoney"
                                                autoComplete='off'
                                                placeholder=""
                                                onChange={handleShareMoney}
                                                value={shareMoney} disabled readOnly />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Fixed Deposit(FD)</label>
                                            <input type="text"
                                                className="form-control"
                                                id="fixedDeposit"
                                                name="fixedDeposit"
                                                autoComplete='off'
                                                placeholder=""
                                                onChange={handleFD}
                                                value={fixedDeposit} disabled readOnly />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Credit Limit</label>
                                            <input type="text"
                                                className="form-control"
                                                id="creditLimit"
                                                name="creditLimit"
                                                autoComplete='off'
                                                placeholder=""
                                                onChange={handleCreditLimit}
                                                value={creditLimit} disabled readOnly />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Remaining Loan</label>
                                            <input type="text"
                                                className="form-control"
                                                id="remainingLoan"
                                                name="remainingLoan"
                                                autoComplete='off'
                                                placeholder=""
                                                onChange={handleRemainingLoan}
                                                value={remainingLoan} disabled readOnly />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Tenure(in months)</label>
                                            <input className="form-control"
                                                id="closingDate"
                                                name="closingDate"
                                                autoComplete='off'
                                                type="text"
                                                onChange={handleTenure}
                                                value={tenure}
                                                placeholder="Tenure"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Date Of Appointment</label>
                                            <input className="form-control my-1"
                                                id="appointmentDate"
                                                name="appointmentDate"
                                                type="Date"
                                                autoComplete='off'
                                                onChange={handleDateOfAppointment}
                                                value={dateOfAppointment}
                                                placeholder="Date of Appointment"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Date Of Retirement</label>
                                            <input className="form-control my-1"
                                                id="retirementDate"
                                                autoComplete='off'
                                                name="retirementDate"
                                                type="Date"
                                                onChange={handleDateOfRetirement}
                                                value={dateOfRetirement}
                                                placeholder="Date of Retirement"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Required Loan Amount</label>
                                            <input type="text"
                                                className="form-control"
                                                autoComplete='off'
                                                id="requiredLoanAmount"
                                                name="requiredLoanAmount"
                                                placeholder="Loan Amount Required"
                                                onChange={handleRequiredLoanAmount}
                                                value={requiredLoanAmount} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Reason for Loan</label>
                                            <input type="text"
                                                className="form-control"
                                                autoComplete='off'
                                                id="loanreason"
                                                name="loanreason"
                                                placeholder="Reason"
                                                onChange={handleReasonForLoan}
                                                value={reasonForLoan} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Monthly Deduction</label>
                                            <input type="text"
                                                className="form-control"
                                                id="monthlyDeduction"
                                                autoComplete='off'
                                                name="monthlyDeduction"
                                                placeholder="Monthly Deduction"
                                                onChange={handleMonthlyDeduction}
                                                value={monthlyDeduction} />
                                        </div>
                                    </div>
                                    <div className="col-lg-3">
                                        <div className='pd-b-10'>
                                            <label className="form-label">Created On</label>
                                            <input className="form-control my-1"
                                                id="createdOnDate"
                                                autoComplete='off'
                                                name="createdOnDate"
                                                type="Date"
                                                onChange={handleCreatedOnDate}
                                                value={createdOnDate}
                                                placeholder="Created On"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <br />
            <div className="accordion" id="accordionGuarantor">
                <div className="accordion-item">
                    <h2 className="accordion-header" id="Guarantor">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseGuarantor" aria-expanded="false" aria-controls="collapseGuarantor">
                            Guaranters
                        </button>
                    </h2>
                    <div id="collapseGuarantor" className="accordion-collapse collapse" aria-labelledby="Guarantor" data-bs-parent="#accordionGuarantor">
                        <div className="accordion-body">
                            <div className='container-fluid'>
                                <div className='row'>
                                    <div className='col-lg-1'></div>
                                    <div className='col-lg-4'>
                                        <div className='existingGBox'>
                                            <h5>Existing Guaranters ({existingGuaranterArr.length}/10)</h5>
                                            <br />
                                            <div className='existing-guarantor-subBox'>
                                                <div className='container-fluid'>
                                                    <div className='row'>
                                                        {
                                                            existingGuaranterArr.map((el, index) => {
                                                                return <div className="col-lg-12">
                                                                    <div className="guaranter-box">
                                                                        <div className='text-boxGuarantor'>
                                                                            <span>{el.personalDetail.firstName + " " + el.personalDetail.lastName}</span>
                                                                            (<span>{el.memberId}</span>)
                                                                        </div>
                                                                        <div className='inline-block'>
                                                                            <FontAwesomeIcon className='fa-icon' icon={solid('trash-can')}
                                                                                onClick={() => deleteGuarantor(el)} />
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-lg-1'></div>
                                    <div className='col-lg-4'>
                                        <div className='existingGBox'>
                                            <h5>Add Guaranters</h5>
                                            <div className="input-group mb-3">
                                                <input type="text"
                                                    className="form-control"
                                                    autoComplete='off'
                                                    id="memberIDSearch"
                                                    name="memberIDSearch"
                                                    placeholder="Member ID"
                                                    onChange={handleMemberIdSearch}
                                                    value={memberIdSearch}
                                                    aria-label="Member ID"
                                                    aria-describedby="button-addon3" />
                                                <button
                                                    className="btn btn-outline-secondary"
                                                    type="button"
                                                    onClick={() => getSearchedMemeberIdDetails()}
                                                    id="button-addon3">Search</button></div><br />
                                            {
                                                memberSearchArr.map((el, index) => {
                                                    return <div className="guaranter-box">
                                                        <div>
                                                            <span>{el.personalDetail.firstName + " " + el.personalDetail.lastName}</span>(<span>{el.memberId}</span>)<br />

                                                        </div>
                                                        <button onClick={() => addGuarantor(el)}>Add</button>
                                                    </div>

                                                })
                                            }

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div></div> : <></>
            }
            </div>
        </div>
    );
}