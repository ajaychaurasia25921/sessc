import React, { useState } from 'react';
import './loan.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";

const mainService = new MainService("");

export const LoanAssignment = () => {
    var [loanApplicationId, setLoanApplicationId] = React.useState('');
    var [loanSchemeId, setLoanSchemeId] = React.useState('');
    var [responseLoanScheme, setResponseLoanScheme] = React.useState();
    var [responseLoanApplication, setResponseLoanApplication] = React.useState();
    var [loanAmount, setLoanAmount] = React.useState('');
    var [tenure, setTenure] = React.useState('');
    var [interestRate, setInterestRate] = React.useState('');
    var [reason, setReason] = React.useState('');
    var [totalAmount, setTotalAmount] = React.useState('');
    var [interestAmount, setInterestAmount] = React.useState('');
    var [paymentMode, setPaymentMode] = React.useState('');
    var [loanSchemeName, setLoanSchemeName] = React.useState('');
    var [alertMessageAssignmentTab, setAlertMessageAssignmentTab] = React.useState('');
    var [showAlertAssignmentTab, setShowAlertAssignmentTab] = React.useState(false);
    var [allSchemes, setAllSchemes] = React.useState(Array<any>());
    var [loanAssignmentResponse, setLoanAssignmentResponse] = React.useState();
    var [showSuccessDialog, setShowSuccessDialog] = React.useState(false);
    var [showAssignBtn, setShowAssignBtn] = React.useState(false);
    var [disableAssignButtonLoan, setDisableAssignButtonLoan] = React.useState(true);
    var [monthlyEmi, setMonthlyEmi] = React.useState('');


    React.useEffect(() => {
        getAllSchemes();
    }, []);

    React.useEffect(() => {
        checkDisabilityAssignBtn();
    }, [paymentMode]);

    React.useEffect(() => {
        checkDisabilityAssignBtn();
        if (loanAmount && tenure && interestRate) {
            let newLoanAmount = parseInt(loanAmount);
            let newTenure = parseFloat(tenure);
            let newRate = parseFloat(interestRate);

            newTenure = newTenure / 12;
            let interestOnLoan = (newLoanAmount * newTenure * newRate) / 100;
            setInterestAmount(Math.round(interestOnLoan) + "");
            setTotalAmount(Math.round(newLoanAmount + interestOnLoan) + "");
        }
    }, [loanAmount, tenure, interestRate]);

    async function getAllSchemes() {
        let url = `loan/scheme`;
        try {
            let response = await mainService.getRequest(url, null, null);
            setAllSchemes(response.data.content);
        } catch (e: any) {
            console.log(e)
        }
    }

    const handleLoanApplicationId = (e: any) => {
        setLoanApplicationId(e.target.value);
    }

    const handleLoanSchemeId = (e: any) => {
        setLoanSchemeId(e.target.value);
    }

    async function getLoanAssignmentDetails() {
        let url = `loan/application/${loanApplicationId}`;
        let response1 = await mainService.getRequest(url, null, null);
        console.log(response1.data)
        if(response1.data['status'] && response1.data['status'] == "Approved") {
            setShowAssignBtn(true);
            setAlertMessageAssignmentTab("Entered Loan Application already assigned.");
            setShowAlertAssignmentTab(true);
            setTimeout(() => {
                setShowAlertAssignmentTab(false);
            }, 5000);
        } else {
            setShowAssignBtn(true);
            setResponseLoanApplication(response1.data);
        }
        
        let url1: string = "";
        if (loanSchemeId) {
            url1 = `loan/scheme/${loanSchemeId}`;
        }
        if (loanSchemeName) {
            url1 = `loan/scheme/${loanSchemeName}`;
        }
        if (loanSchemeId == "" && loanSchemeName == "") {
            setAlertMessageAssignmentTab("Provide Scheme ID or Scheme Name.");
            setShowAlertAssignmentTab(true);
            setTimeout(() => {
                setShowAlertAssignmentTab(false);
            }, 5000);
        }
        let response2 = await mainService.getRequest(url1, null, null);
        setResponseLoanScheme(response2.data);
        setReason('');
        setLoanAmount(response1.data['requiredLoanAmount']);
        setTenure(response1.data['tenure']);
        setReason(response1.data['reasonForLoan']);
        setInterestRate(response2.data['maxInterestRate']);
        setMonthlyEmi(response1.data['monthlyDeduction']);
        
    }

    const checkDisabilityAssignBtn = () => {
        if (responseLoanScheme &&
            (parseFloat(loanAmount) <= parseFloat(responseLoanScheme['approvedAmount'])) &&
            (parseInt(tenure) <= parseInt(responseLoanScheme['maxTenure'])) &&
            (parseFloat(interestRate) >= parseFloat(responseLoanScheme['maxInterestRate'])) &&
            (paymentMode && paymentMode != '')) {
            setDisableAssignButtonLoan(false);
        } else {
            setDisableAssignButtonLoan(true);
        }
    }

    const closeAlertAssignTab = () => {
        setShowAlertAssignmentTab(false);
    }

    // function checkDisabilityOfAssignBtn() {

    // }

    async function assignLoanDetils() {
        let payload = {
            "loanApplication": responseLoanApplication,
            "schemeId": responseLoanScheme,
            "assignedAmount": loanAmount,
            "assignedTenure": tenure,
            "interestAmount": interestAmount,
            "interestRate": interestRate,
            "paymentMode": paymentMode
        }
        let url = `loan/assignment`
        let response = await mainService.postRequest(url, payload, null);
        console.log(response);
        if (response.status == 200) {
            setLoanAssignmentResponse(response.data);
            setShowSuccessDialog(true);
            setPaymentMode("");
            setLoanApplicationId("");
            setLoanSchemeId("");
            setLoanSchemeName("");
            setLoanAmount("");
            setTenure("");
            setInterestRate("");
            setReason("");
            setTotalAmount("");
            setInterestAmount("");
            let anyObj: any = ""
            setResponseLoanApplication(anyObj);
            setResponseLoanScheme(anyObj);
            setShowAssignBtn(false);
        } else {

        }
    }

    const closeLoanAssignmentModal = () => {
        setShowSuccessDialog(false);
    }

    const handleLoanAmount = (e: any) => {
        setLoanAmount(e.target.value);
    }
    const handleTenure = (e: any) => {
        setTenure(e.target.value);
    }
    const handleInterestRate = (e: any) => {
        setInterestRate(e.target.value);
    }
    const handleReason = (e: any) => {
        setReason(e.target.value);
    }
    const handleTotalAmount = (e: any) => {
        setTotalAmount(e.target.value);
    }
    const handleInterestAmount = (e: any) => {
        setInterestAmount(e.target.value);
    }
    const handleMonthlyDeduction = (e: any) => {
        setMonthlyEmi(e.target.value);
    }
    const handlePaymentMode = (e: any) => {
        setPaymentMode(e.target.value);
        // checkDisabilityAssignBtn();
    }
    const handleLoanSchemeName = (e: any) => {
        setLoanSchemeName(e.target.value);
    }
    return (
        <div className='loan-assignment my-3'>
            {
                showAlertAssignmentTab ?
                    <div className="d-flex justify-content-end my-4cphx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessageAssignmentTab}</span>
                                <button aria-label="Close"
                                    className='close close-position'
                                    type='button' data-dismiss="alert"
                                    onClick={() => closeAlertAssignTab()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
            {
                showSuccessDialog ?
                    <div className="modal" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Loan Application Saved</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeLoanAssignmentModal()}></button>
                                </div>
                                <div className="modal-body">
                                    {
                                        loanAssignmentResponse ?
                                            <div>
                                                <div>
                                                    <span><strong>Loan ID: </strong></span>
                                                    <span>{loanAssignmentResponse['loanId']}</span>
                                                </div>
                                                <div>
                                                    <span><strong>Loan Account Number: </strong></span>
                                                    <span>{loanAssignmentResponse['loanAccountNumber']}</span>
                                                </div>
                                                <div>
                                                    <span><strong>Loan Assignment Creation Date: </strong></span>
                                                    <span>{dateFormat(loanAssignmentResponse['createdOn'], "mmmm dS, yyyy, h:MM:ss TT")}</span>
                                                </div>
                                                <div>
                                                    <span><strong>Loan Assignment Created By: </strong></span>
                                                    <span>{loanAssignmentResponse['createdBy']}</span>
                                                </div>
                                            </div> : <></>
                                    }
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className='container-fluid'>
                <div className='row my-2'>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">Loan Application ID</label>
                        <input type="text" autoComplete='off'
                            className="form-control"
                            id="loanApplicationId"
                            name="loanApplictionId"
                            placeholder="Loan Application Id"
                            onChange={handleLoanApplicationId}
                            value={loanApplicationId}
                            aria-label="Loan id"
                            aria-describedby="button-addon2" />
                    </div>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">Loan Scheme ID</label>
                        <input type="text" autoComplete='off'
                            className="form-control"
                            id="loanSchemeId"
                            name="loanSchemeId"
                            placeholder="Loan Scheme Id"
                            onChange={handleLoanSchemeId}
                            value={loanSchemeId}
                            aria-label="Loan id"
                            aria-describedby="button-addon2" />
                    </div>
                    <div className='col-lg-3'>
                        <label className="form-label color-white">Loan Scheme Name</label>
                        <select className="form-select mb-3"
                            aria-label="Default select example"
                            id="loanSchemeName"
                            name="loanSchemeName"
                            onChange={handleLoanSchemeName}
                            value={loanSchemeName}>
                            <option value="" key="" >Select</option>
                            {
                                allSchemes.map(e => <option
                                    value={e.schemeId} key={e.loanName}>{e.loanName}</option>)
                            }
                        </select>
                    </div>
                    <div className='col-lg-3'>
                        <button
                            className="btn btn-outline-light mt-4"
                            type="button"
                            onClick={() => getLoanAssignmentDetails()}>Go</button>
                    </div>
                </div>
                <div className='row my-2'>
                    <div className='col-lg-6'>
                        {responseLoanApplication && responseLoanScheme ?
                            <div className="assignment-application-box my-3 p-3">
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>Required Loan Amount: </strong>{responseLoanApplication ? responseLoanApplication['requiredLoanAmount'] : ''}</span>
                                    </div>
                                    <div className='col-lg-6'>
                                        <span><strong>
                                            Reason For Loan: </strong>
                                            {responseLoanApplication ?
                                                responseLoanApplication['reasonForLoan'] : ''}</span>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>Tenure: </strong>
                                            {responseLoanApplication ?
                                                responseLoanApplication['tenure'] : ''}
                                        </span> months
                                    </div>
                                </div>
                            </div> : <></>
                        }
                    </div>
                    <div className='col-lg-6'>
                        {responseLoanScheme && responseLoanApplication ?
                            <div className="assignment-schema-box my-3 p-3">
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>Loan Scheme: </strong>{responseLoanScheme ? responseLoanScheme['loanName'] : ''}</span>
                                    </div>
                                    <div className='col-lg-6'>
                                        <span className='ml-6'><strong>Max Amount: </strong>{responseLoanScheme ? responseLoanScheme['approvedAmount'] : ''}</span>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-lg-6'>
                                        <span><strong>Max Tenure: </strong>{responseLoanScheme ? responseLoanScheme['maxTenure'] : ''} months</span>
                                    </div>
                                    <div className='col-lg-6'>
                                        <span className='ml-6'><strong>Interest Rate: </strong>{responseLoanScheme ? responseLoanScheme['maxInterestRate'] : ''}%</span>
                                    </div>
                                </div>
                            </div> : <></>
                        }
                    </div>

                </div>
                {responseLoanScheme && responseLoanApplication ?
                    <div className='row my-2'>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Loan Amount</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="loanAmount"
                                name="loanAmount"
                                placeholder="Loan Amount"
                                onChange={handleLoanAmount}
                                value={loanAmount}
                                aria-label="Loan Amount"
                                aria-describedby="button-addon2" />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">
                                Tenure (in months)</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="tenure"
                                name="tenure"
                                placeholder="Tenure"
                                onChange={handleTenure}
                                value={tenure}
                                aria-label="Tenure"
                                aria-describedby="button-addon2" />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Interest Rate</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="interestRate"
                                name="interestRate"
                                placeholder="Interest Rate"
                                onChange={handleInterestRate}
                                value={interestRate}
                                aria-label="Interest Rate"
                                aria-describedby="button-addon2" />
                            {/* <span className='color-white'>%</span> */}
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Reason</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="reason"
                                name="reason"
                                placeholder="Reason"
                                onChange={handleReason}
                                value={reason}
                                aria-label="Reason"
                                aria-describedby="button-addon2" />
                        </div>

                        <div className='col-lg-3'>
                            <label className="form-label color-white">
                                Total Amount (including interest)</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="totalAmount"
                                name="totalAmount"
                                placeholder="Total Amount"
                                onChange={handleTotalAmount}
                                value={totalAmount}
                                aria-label="Total Amount"
                                aria-describedby="button-addon2" disabled readOnly />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Interest Amount</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="interestAmount"
                                name="interestAmount"
                                placeholder="Interest Amount"
                                onChange={handleInterestAmount}
                                value={interestAmount}
                                aria-label="Interest Amount"
                                aria-describedby="button-addon2" disabled readOnly />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Monthly Deduction</label>
                            <input type="text" autoComplete='off'
                                className="form-control mb-3"
                                id="monthlyemi"
                                name="monthlyemi"
                                placeholder="Monthly Deduction"
                                onChange={handleMonthlyDeduction}
                                value={monthlyEmi} />
                        </div>
                        <div className='col-lg-3'>
                            <label className="form-label color-white">Payment Mode</label>
                            <select className="form-select mb-3"
                                aria-label="Default select example"
                                id="paymentMode" name="paymentMode"
                                onChange={handlePaymentMode}
                                value={paymentMode}>
                                <option value="" key="" >Select</option>
                                <option value="Salary" key="Salary" >Salary</option>
                                <option value="Self" key="Self" >Self</option>
                            </select>
                        </div>
                    </div>
                    : <></>
                }
                {
                    showAssignBtn ? <div className='row my-2'>
                        <div className='col-lg-5'></div>
                        <div className='col-lg-1'>
                            <button id="assignApplication"
                                className="btn btn-outline-light"
                                type="button" disabled={disableAssignButtonLoan}
                                onClick={() => assignLoanDetils()}>Assign</button>
                        </div>
                    </div> : <></>
                }


            </div>
        </div>
    )
}