import React, { useState } from 'react';
import './loan.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");


export const LoanCalculator = (props: any) => {

    var [loanAmount, setLoanAmount] = React.useState('5000');
    var [loanRange, setLoanRange] = React.useState('5000');
    var [estReturns, setEstReturns] = React.useState('');
    var [loanSchemeName, setLoanSchemeName] = React.useState('');
    var [interestStartRange, setInterestStartRange] = React.useState('');
    var [loanTenureType, setLoanTenureType] = React.useState('');
    var [loanMonths, setLoanMonths] = React.useState('');
    var [maturedAmount, setMaturedAmount] = React.useState('');
    var [allLoanSchemes, setAllLoanSchemes] = React.useState(Array<any>());
    var [maturityDate, setMaturityDate] = React.useState('');

    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    React.useEffect(() => {
        getAllLoanSchemes();
    }, []);
    React.useEffect(() => {
        for (let s of allLoanSchemes) {
            if (s.schemeId == loanSchemeName) {
                setInterestStartRange(s.maxInterestRate);
                break;
            }
        }
    }, [loanSchemeName]);

    async function getAllLoanSchemes() {
        let url = `loan/scheme`;
        try {
            let response = await mainService.getRequest(url, null, null);
            setAllLoanSchemes(response.data.content);
        } catch (e: any) {
            console.log(e)
        }
    }

    const handleLoanAmount = (e: any) => {
        setLoanAmount(e.target.value);
        setLoanRange(e.target.value);
    }
    const handleLoanSchemeName = (e: any) => {
        setLoanSchemeName(e.target.value);
    }
    const handleLoanRange = (e: any) => {
        setLoanRange(e.target.value);
        setLoanAmount(e.target.value);
    }
    const handleLoanMonths = (e: any) => {
        setLoanMonths(e.target.value);
    }
    const handleInterestStartRange = (e: any) => {
        setInterestStartRange(e.target.value);
    }
    const handleTenureType = (e: any) => {
        setLoanTenureType(e.target.value);
    }
    async function calculateInputs() {
        let tenure: any = "";
        var d = new Date();
        if (loanTenureType == "Years") {
            tenure = loanMonths;
            d.setFullYear(d.getFullYear() + parseInt(loanMonths));
        }
        if (loanTenureType == "Months") {
            tenure = parseFloat(loanMonths) / 12;
            d.setMonth(d.getMonth() + parseInt(loanMonths));
        }
        if (loanTenureType == "Days") {
            if(parseInt(loanMonths) < 46) {
                setEstReturns("0");
                setMaturedAmount(parseFloat(loanMonths) + "");
                d.setDate(d.getDate() + parseInt(loanMonths));
                setMaturityDate(d.getDate()+" "+ monthNames[d.getMonth()]+" "+d.getFullYear());
                return;
            } else {
                tenure = parseFloat(loanMonths) / (365);
                // d.setMonth(d.getMonth() + parseInt(FDMonths));
            }
            d.setDate(d.getDate() + parseInt(loanMonths));
            console.log(d)
    // return date;
        }
        setMaturityDate(d.getDate() + " " + monthNames[d.getMonth()] + " " + d.getFullYear());

        let interest = (parseFloat(loanAmount) * parseFloat(interestStartRange) * parseFloat(tenure)) / 100;
        setEstReturns(Math.round(interest) + "");
        let OnMaturityAmount = parseFloat(loanAmount) + interest;
        setMaturedAmount(Math.round(OnMaturityAmount) + "");
    }

    function resetInputs() {
        setLoanAmount('');
        setLoanRange('');
        setLoanSchemeName('');
        setInterestStartRange('');
        setLoanTenureType('');
        setLoanMonths('');
        setMaturedAmount('');
        setEstReturns('');
        setMaturityDate('');
    }

    function investNow() {

        // let tab = document.getElementById("FDBtn");
        // if(tab) {
        //     tab.dispatchEvent(new Event("click"));
        // }
        
        // document.getElementById("fdApplication-tab")?.classList.add("active");
        // document.getElementById("fdCalculator-tab")?.classList.remove("active");
        // document.getElementById("fdApplication")?.classList.add("show");
        // document.getElementById("fdCalculator")?.classList.remove("show");
        // document.getElementById("fdApplication")?.classList.add("active");
        // document.getElementById("fdCalculator")?.classList.remove("active");

    }

    return (
        <div>
            <div className="container-fluid">
                <div className='row'>
                    {/* <div className='col-md-1'></div> */}
                    <div className='col-md-3'>
                        <div className="form-body">
                            <div className="row">
                                <div className="form-holder loan-scheme-form">
                                    <div className="form-content">
                                        <div className="form-items color-white">
                                            <form className="mt-1">
                                                <div className="col-md-12">
                                                    <label className='form-label'>Loan Amount</label>
                                                    <input className="form-control my-1 fs-6"
                                                        id="loanAmount"
                                                        autoComplete='off'
                                                        name="loanAmount"
                                                        type="text"
                                                        onChange={handleLoanAmount}
                                                        value={loanAmount}
                                                        placeholder="Loan Amount" />
                                                </div>

                                                <label className="form-label">Example range</label>
                                                <input type="range"
                                                    onChange={handleLoanRange}
                                                    value={loanRange}
                                                    className="form-range"
                                                    min="0"
                                                    max="10000000"
                                                    step="1000"
                                                    id="customRange3"></input>

                                                <div className='col-md-12'>
                                                    <label className="form-label color-white">Loan Scheme Name</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="loanSchemeName"
                                                        name="loanSchemeName"
                                                        onChange={handleLoanSchemeName}
                                                        value={loanSchemeName}>
                                                        <option value="" key="" >Select</option>
                                                        {
                                                            allLoanSchemes.map(e => <option
                                                                value={e.schemeId} key={e.loanName}>{e.loanName}</option>)
                                                        }
                                                    </select>
                                                </div>

                                                <div className="col-md-12">
                                                    <label className='form-label'>Interest Rate</label>
                                                    <div>
                                                        <input type="text"
                                                            className="form-control"
                                                            id="interestStartRange"
                                                            autoComplete='off'
                                                            name="interestStartRange"
                                                            placeholder="Interest Rate"
                                                            onChange={handleInterestStartRange}
                                                            value={interestStartRange} disabled readOnly />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <label className='form-label'>Tenure (in months)</label>
                                                    <div>
                                                        <div className='inline-prop'>
                                                            <input type="text"
                                                                className="form-control"
                                                                id="loanMonths"
                                                                name="loanMonths"
                                                                autoComplete='off'
                                                                onChange={handleLoanMonths}
                                                                value={loanMonths} />
                                                        </div>
                                                        <div className='inline-prop'>
                                                            <select className="form-select"
                                                                aria-label="Default select example"
                                                                id="loanFilterType" name="loanFilterType"
                                                                onChange={handleTenureType}
                                                                value={loanTenureType}>
                                                                <option value="Select" key="Select">Select</option>
                                                                <option value="Years" key="Years">Year</option>
                                                                <option value="Months" key="Months">Month</option>
                                                                <option value="Days" key="Days">Days</option>
                                                            </select>
                                                        </div>
                                                        {/* <div className='col-md-1'></div> */}

                                                    </div>
                                                </div>

                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => calculateInputs()}>Calculate</button>
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => resetInputs()}>Reset</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-7'>
                        <div className="output-card">
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                        <strong>
                                            <div>
                                                <span className='smallfont'>INTEREST AMOUNT</span>
                                            </div>
                                            Rs. <span className='xxlargefont'>{estReturns}</span>
                                        </strong>
                                    </div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='inline-start'>
                                        <strong>
                                            <div>
                                                <span className='smallfont'>TOTAL AMOUNT</span>
                                            </div>
                                            Rs. <span className='xxlargefont'>{maturedAmount}</span>
                                        </strong>
                                    </div>
                                </div>
                                <br /><br />
                                <div className='interest-div'>
                                    <span><strong>Interest @ {interestStartRange} p.a.</strong></span>
                                </div>
                            </div>
                            <hr />
                            <div className='row'>
                                <div className='col-md-12'>
                                    <div className='interest-div'>
                                        <span><strong>To Be Paid Upto : {maturityDate}</strong></span>
                                    </div>
                                </div>
                                {/* <div className="form-button mt-3 interest-div">
                                    <button type="button" className="btn"
                                        onClick={() => investNow()}>Invest Now</button>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}
