import React, { useState } from 'react';
import './loan.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used

const mainService = new MainService("");

type RowsObj = {
    id: string,
    loanName: string,
    approvedAmount: number,
    maxInterestRate: number,
    maxTenure: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string,
    preclosure: string
};

export const LoanCreation = (props: any) => {

    var [loanName, setLoanName] = React.useState('');
    var [editedSchemeName, setEditedSchemeName] = React.useState('');
    var [maxAmount, setMaxAmount] = React.useState('');
    var [editedMaxAmount, setEditedMaxAmount] = React.useState('');
    var [intrestRate, setInterestRate] = React.useState('');
    var [editedIntrestRate, setEditedInterestRate] = React.useState('');
    var [tenure, setTenure] = React.useState('');
    var [editedTenure, setEditedTenure] = React.useState('');
    var [preClosure, setPreClosure] = React.useState('');
    var [editedPreClosure, setEditedPreClosure] = React.useState('');
    const [rowsData, setRows] = React.useState(Array);
    var [reload, setReload] = React.useState(false);
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [hasPrevious, setHasPrevious] = React.useState(false);
    var [showEditLoanSchemeDialog, setShowEditLoanSchemeDialog] = React.useState(false);
    var [recordOpened, setRecordOpened] = React.useState();

    React.useEffect(() => {
        getRows(10, 0);
    }, []);

    const handleLoanName = (e: any) => {
        setLoanName(e.target.value);
    }
    const handleMaxAmount = (e: any) => {
        setMaxAmount(e.target.value);
    }
    const handleIntrestRate = (e: any) => {
        setInterestRate(e.target.value);
    }
    const handleTenure = (e: any) => {
        setTenure(e.target.value);
    }
    const handlePreClosure = (e: any) => {
        setPreClosure(e.target.value);
    }
    const handleEditedSchemeName = (e: any) => {
        setEditedSchemeName(e.target.value);
    }
    const handlEeditedIntrestRate = (e: any) => {
        setEditedInterestRate(e.target.value);
    }
    const handleEditedMaxAmount = (e: any) => {
        setEditedMaxAmount(e.target.value);
    }
    const handleEditedTenure = (e: any) => {
        setEditedTenure(e.target.value);
    }
    const handleEditedPreClosure = (e: any) => {
        setEditedPreClosure(e.target.value);
    }
    

    const columnsList: GridColDef[] = [
        { field: 'id', headerName: 'Scheme ID', width: 150 },
        { field: 'loanName', headerName: 'Loan Name', width: 150 },
        { field: 'approvedAmount', headerName: 'Approved Amount', width: 150 },
        { field: 'maxInterestRate', headerName: 'Interest Rate', width: 150 },
        { field: 'maxTenure', headerName: 'Tenure', width: 150 },
        { field: 'preclosure', headerName: 'Pre-Closure(%)', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'modifiedOn', headerName: 'Modified On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        { field: 'modifiedBy', headerName: 'Modified By', width: 150 },
        {
            field: 'action',
            width: 130,
            sortable: false,
    
            renderCell: (params) => {
                function onClickEdit() {
                    console.log(params.row)
                    setShowEditLoanSchemeDialog(true);
                    setRecordOpened(params.row);
                    setEditedSchemeName(params.row.loanName)
                    setEditedMaxAmount(params.row.approvedAmount);
                    setEditedInterestRate(params.row.maxInterestRate);
                    setEditedTenure(params.row.maxTenure);
                    setEditedPreClosure(params.row.preclosure);
                }
    
                return (
                    <>
                        <FontAwesomeIcon className='fa-icon-table' icon={solid('pencil')} onClick={() => onClickEdit()} />
                    </>
                );
            },
        }
    ];
    async function saveLoanPlan() {
        let reqPayload = {
            "loanName": loanName,
            "approvedAmount": parseInt(maxAmount),
            "maxInterestRate": parseFloat(intrestRate),
            "maxTenure": tenure,
            "preClosureCharges": parseFloat(preClosure)
        }
        try {
        let tempurl = 'loan/scheme';
        let response = await mainService.postRequest(tempurl, reqPayload, null);
        setLoanName('');
        setMaxAmount('');
        setInterestRate('');
        setTenure('');

        getRows(10,0);
    }
    catch(e:any){
      console.log(e);
    }
    }

    async function getRows(rowSize: number, pageSize: number) {
        console.log(rowSize, pageSize);
        let url = `loan/scheme?size=${rowSize}&page=${pageSize}`;
        let abc: any[] = [];
        try {
            let response = await mainService.getRequest(url, null, null);
            console.log(response);
            setTotalElement(response.data.totalElements);
            setHasNext(response.data.hasNext);
            setHasPrevious(response.data.hasPrevious);
            setNumberOfRows(response.data.size);
            setRows([]);
            response.data.content.forEach((element: any) => {
                let data: RowsObj = {
                    id: element.schemeId,
                    loanName: element.loanName,
                    approvedAmount: element.approvedAmount,
                    maxInterestRate: element.maxInterestRate,
                    maxTenure: element.maxTenure,
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    modifiedOn: dateFormat(element.modifiedOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    modifiedBy: element.createdBy,
                    preclosure: element.preClosureCharges+""
                }
                abc.push(data);
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    async function saveEditedRecord() {
        let url = `loan/scheme`;
        let data = {
            "schemeId": recordOpened?recordOpened['id']:'',
            "loanName": editedSchemeName,
            "approvedAmount": parseInt(editedMaxAmount),
            "maxInterestRate": parseFloat(editedIntrestRate),
            "maxTenure": editedTenure,
            "preClosureCharges": parseFloat(editedPreClosure)
        }
        let response = await mainService.postRequest(url, data, null);
        if (response.status == 200) {
            setEditedInterestRate('');
            setEditedMaxAmount('');
            setEditedPreClosure('');
            setEditedSchemeName('');
            setEditedTenure('');
            setShowEditLoanSchemeDialog(false);
        }
        getRows(recordsSize, pageSize);
    }

    function closeEditDialog() {
        setShowEditLoanSchemeDialog(false);
    }

    function txnDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    return (
        <div>
            {
                showEditLoanSchemeDialog ?
                    <div className="modal fade show" data-bs-backdrop="static" data-bs-keyboard="false" id="response-modal" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Edit Loan Scheme Record</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeEditDialog()}></button>
                                </div>
                                <div className="modal-body">
                                    <div className='row'>

                                            <div className="col-md-6">
                                            <label className='form-label'>Scheme Name</label>
                                            <input className="form-control my-1 fs-6"
                                                id="loanName" autoComplete='off'
                                                name="schemeName"
                                                type="text"
                                                onChange={handleEditedSchemeName}
                                                value={editedSchemeName}
                                                placeholder="Scheme Name"
                                            />
                                            </div>

                                            <div className="col-md-6">
                                        <label className='form-label'>Maximum Amount</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxAmount" autoComplete='off'
                                                name="maxAmount"
                                                type="text"
                                                placeholder="Max Amount"
                                                onChange={handleEditedMaxAmount}
                                                value={editedMaxAmount}
                                            />
                                        </div>
                                        <div className="col-md-6">
                                        <label className='form-label'>Interest Rate</label>
                                            <input className="form-control my-1 fs-6"
                                                id="intrestRate" autoComplete='off'
                                                name="intrestRate"
                                                type="text"
                                                placeholder="Interest Rate"
                                                onChange={handlEeditedIntrestRate}
                                                value={editedIntrestRate}
                                            />
                                        </div>
                                        <div className="col-md-6">
                                        <label className='form-label'>Tenure</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxTenure"
                                                name="maxTenure"
                                                type="text"
                                                autoComplete='off'
                                                placeholder="Tenure(in months)"
                                                onChange={handleEditedTenure}
                                                value={editedTenure}
                                            />
                                        </div>
                                        <div className="col-md-6">
                                        <label className='form-label'>Pre-Closure(%)</label>
                                            <input className="form-control my-1 fs-6"
                                                id="preClosure"
                                                name="preClosure"
                                                autoComplete='off'
                                                type="text"
                                                placeholder="PreClosure Percentage"
                                                onChange={handleEditedPreClosure}
                                                value={editedPreClosure}
                                            />
                                        </div>
                                            <button type="button" className="btn"
                            onClick={() => saveEditedRecord()}>Save</button>
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div> : <></>
            }
            <div className="container-fluid">
        <div className='row'>
            <div className='col-md-3'>
                <div className="form-body">
                    <div className="row">
                        <div className="form-holder">
                            <div className="form-content">
                                <div className="form-items">
                                    <form className="requires-validation">
                                        <div className="col-md-12">
                                            <label className='form-label color-white'>Scheme Name</label>
                                            <input className="form-control my-1 fs-6"
                                                id="loanName" autoComplete='off'
                                                name="loanName"
                                                type="text"
                                                onChange={handleLoanName}
                                                value={loanName}
                                                placeholder="Loan Name"
                                            />
                                        </div>
                                        <div className="col-md-12">
                                        <label className='form-label color-white'>Maximum Amount</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxAmount" autoComplete='off'
                                                name="maxAmount"
                                                type="text"
                                                placeholder="Max Amount"
                                                onChange={handleMaxAmount}
                                                value={maxAmount}
                                            />
                                        </div>
                                        <div className="col-md-12">
                                        <label className='form-label color-white'>Interest Rate</label>
                                            <input className="form-control my-1 fs-6"
                                                id="intrestRate" autoComplete='off'
                                                name="intrestRate"
                                                type="text"
                                                placeholder="Interest Rate"
                                                onChange={handleIntrestRate}
                                                value={intrestRate}
                                            />
                                        </div>
                                        <div className="col-md-12">
                                        <label className='form-label color-white'>Tenure</label>
                                            <input className="form-control my-1 fs-6"
                                                id="maxTenure"
                                                name="maxTenure"
                                                type="text"
                                                autoComplete='off'
                                                placeholder="Tenure(in months)"
                                                onChange={handleTenure}
                                                value={tenure}
                                            />
                                        </div>
                                        <div className="col-md-12">
                                        <label className='form-label color-white'>Pre-Closure(%)</label>
                                            <input className="form-control my-1 fs-6"
                                                id="preClosure"
                                                name="preClosure"
                                                autoComplete='off'
                                                type="text"
                                                placeholder="PreClosure Percentage"
                                                onChange={handlePreClosure}
                                                value={preClosure}
                                            />
                                        </div>


                                        <div className="form-button mt-3">
                                            <button type="button" className="btn btn-outline-light" 
                                            onClick={() => saveLoanPlan()}>Save Loan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='col-md-9 border-left'>
                <br/>
            <div className='d-flex mb-2 flex-row-reverse'>
          <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
            <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
            <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
            <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
          </div>
          <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
        </div>
            {
                rowsData ?
                <div className="text-white bg-white grid-view" id='gridView'>
                    <DataGrid
                        className=''
                        rows={rowsData as any}
                        columns={columnsList}
                        pageSize={numberOfRows}
                        getRowId={(row) => row.id}
                        hideFooter={true}
                    />
                </div> : <></>
            }
            </div>
        </div></div>
        </div>
    );
}
