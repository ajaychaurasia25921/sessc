import React, { useState } from 'react';
import './loan.scss';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import MainService from '../../../services/main-service';
import dateFormat from "dateformat";
import { IconButton } from '@mui/material';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Button, Modal } from 'react-bootstrap';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used
import { AnyCnameRecord } from 'dns';


const mainService = new MainService("");

type RowsObj = {
    id: string,
    memberId: string,
    reasonForLoan: number,
    requiredLoanAmount: number,
    tenure: string,
    creditValidFrom: string,
    creditLimit: number,
    smAmount: number,
    remainingLoan: number,
    fdAmount: number,
    dateOfAppointment: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string,
    status: string,
    guarantor: any
};

export const LoanSearch = (props: any) => {

    var [loanFilterType, setLoanFilterType] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [loanId, setLoanId] = React.useState('');
    const [rowsData, setRows] = React.useState(Array<any>());
    const [numberOfRows, setNumberOfRows] = React.useState(10);
    const [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [hasPrevious, setHasPrevious] = React.useState(false);
    var [deleteModal, setDeleteModal] = React.useState(false);
    var [loanDeactivateRecordId, setLoanDeactivateRecordId] = React.useState("");
    var [assignmentViewModal, setAssignmentViewModal] = React.useState(false);
    var [loanViewRecord, setLoanViewRecord] = React.useState();
    var [applicationAssigned, setApplicationAssigned] = React.useState(true);
    var [showAlert, setShowAlert] = React.useState(false);
    var [alertMessage, setAlertMessage] = React.useState('');
    var [guarantorExist, setGuarantorExist] = React.useState(false);
    var [guarantorList, setGuarantorList] = React.useState([]);

    React.useEffect(() => {
        getRows(10, 0);
    }, []);
    React.useEffect(() => {
        console.log(loanViewRecord)
    }, [loanViewRecord]);

    const columnsList: GridColDef[] = [
        { field: 'id', headerName: 'Loan Application ID', width: 150 },
        { field: 'memberId', headerName: 'Member ID', width: 150 },
        { field: 'reasonForLoan', headerName: 'Reason For Loan', width: 150 },
        { field: 'requiredLoanAmount', headerName: 'Required Loan Amount', width: 150 },
        { field: 'tenure', headerName: 'Tenure', width: 150 },
        { field: 'creditValidFrom', headerName: 'Credit Valid From', width: 150 },
        { field: 'creditLimit', headerName: 'Credit Limit', width: 150 },
        { field: 'smAmount', headerName: 'Share Money Amount', width: 150 },
        { field: 'fdAmount', headerName: 'FD Amount', width: 150 },
        { field: 'remainingLoan', headerName: 'Remaining Loan', width: 150 },
        { field: 'dateOfAppointment', headerName: 'Appointment Date', width: 150 },
        { field: 'createdOn', headerName: 'Created On', width: 150 },
        { field: 'modifiedOn', headerName: 'Modified On', width: 150 },
        { field: 'createdBy', headerName: 'Created By', width: 150 },
        { field: 'modifiedBy', headerName: 'Modified By', width: 150 },
        { field: 'status', headerName: 'Status', width: 150 },
        {
            field: 'Actions',
            width: 130,
            sortable: false,

            renderCell: (params) => {
                async function deActivateRecord() {
                    setLoanDeactivateRecordId(params.row.id);
                    if(params.row.status != "Revoke") {
                        setDeleteModal(!deleteModal);
                    } else {
                        displayAlert("Record already deactivated.")
                    }
                };

                async function viewRecord() {
                    let tempurl = `loan/assignment/member?memberId=${params.row.memberId}`;
                    let response = await mainService.getRequest(tempurl, null, null);
                    let loanRec: any = "";
                    if(response.data.length > 0) {
                        setApplicationAssigned(true);
                        for (let s of response.data) {
                            if (params.row.id == s.loanApplication.applicationId) {
                                loanRec = s;
                                setLoanViewRecord(s);
                                setAssignmentViewModal(true);
                                break;
                            }
                        }
                    } 
                    else {
                        setApplicationAssigned(false);
                        setAssignmentViewModal(true);
                        let obj : any = "";
                        setLoanViewRecord(params.row);
                    }
                    if(loanRec) {
                        setApplicationAssigned(true);
                    } else {
                        setApplicationAssigned(false);
                        setAssignmentViewModal(true);
                        let obj : any = "";
                        setLoanViewRecord(params.row);
                    }
                    console.log("view",params.row)
                    if(params.row && params.row['guarantor']) {
                        setGuarantorExist(true);
                        setGuarantorList(params.row['guarantor']);
                    }
                }
                return (
                    <>
                        {!assignmentViewModal ? 
                        <FontAwesomeIcon className='fa-icon-table' title="View" icon={solid('eye')} onClick={() => viewRecord()} /> : <></> }
                        <button className="btn p-0" onClick={() => deActivateRecord()} title="Deactivate"><img className="mx-1" src="/assets/remove.svg" alt="" /></button>

                    </>
                );
            },
        },

    ];

    const handleLoanFilterType = (e: any) => {
        setLoanFilterType(e.target.value);
    }
    const handleMemberId = (e: any) => {
        setMemberId(e.target.value);
    }
    const handleLoanId = (e: any) => {
        setLoanId(e.target.value);
    }

    async function searchLoanPlan() {
        try {
            setPageSize(0);
            getRows(10, 0);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    function closeAlert() {
        setShowAlert(false);
    }

    function displayAlert(message: string) {
        setAlertMessage(message)
        setShowAlert(true);
        setTimeout(() => {
            setShowAlert(false);
        }, 5000);
    }

    async function getRows(rowSize: number, pageSize: number) {
        try {
            let url = "";
            let abc: any[] = [];
            let processResponse: any[] = [];

            if (loanFilterType == "") {
                return;
            }
            if (loanFilterType == "Get All") {
                url = `loan/application?size=${rowSize}&page=${pageSize}`;
                let response = await mainService.getRequest(url, null, null);
                // console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else if (loanFilterType == "Loan Application ID") {
                url = `loan/application/${loanId}`;
                let response = await mainService.getRequest(url, null, null);
                // console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse.push(response.data) ;
            } else if (loanFilterType == "Member ID") {
                url = `loan/application/member?id=${memberId}&page=${pageSize}&size=${rowSize}`;
                let response = await mainService.getRequest(url, null, null);
                console.log(response);
                setTotalElement(response.data.totalElements);
                setHasNext(response.data.hasNext);
                setHasPrevious(response.data.hasPrevious);
                setNumberOfRows(response.data.size);
                setRows([]);
                processResponse = response.data.content;
            } else {
            }
            console.log(processResponse)
            processResponse.forEach((element: any) => {
                let data: RowsObj = {
                    id: element.applicationId,
                    memberId: element.memberId,
                    reasonForLoan: element.reasonForLoan,
                    requiredLoanAmount: element.requiredLoanAmount,
                    tenure: element.tenure,
                    creditValidFrom: element.creditValidFrom,
                    creditLimit: element.creditLimit,
                    smAmount: element.smAmount,
                    remainingLoan: element.remainingLoan,
                    fdAmount: element.fdAmount,
                    dateOfAppointment: dateFormat(element.dateOfAppointment, "mmm d, yyyy HH:MM"),
                    createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                    modifiedOn: dateFormat(element.modifiedOn, "mmm d, yyyy HH:MM"),
                    createdBy: element.createdBy,
                    modifiedBy: element.createdBy,
                    status: element.status ? element.status : "Pending",
                    guarantor: element.guarantor
                }
                abc.push(data);
            });
            setRows(abc);
        }
        catch (e: any) {
            console.log(e);
        }
    }


    function txnDataNext() {
        setPageSize(pageSize + 1);
        getRows(recordsSize, pageSize + 1);
        setIsLoading(true);
    }

    function txnDataPrevious() {
        setPageSize(pageSize - 1);
        getRows(recordsSize, pageSize - 1);
        setIsLoading(true);
    }

    async function deactivateRecordOnConfirm(id: any) {
        console.log(id)
        let dataMemberId = "";
        let status = "";
        for(let s of rowsData) {
            console.log(s)
            if(s.id == id) {
                dataMemberId = s.memberId;
                status = s.status
            }
        }
        let data = [
            {
              "active": false,
              "applicationId": `${loanDeactivateRecordId}`,
              "memberId": dataMemberId,
              "status": "Revoke"
            }
          ]
        let url = `loan/assignment/status`;
        if(status == ""){
        try {
            let response = await mainService.postRequest(url, data, null);
        }
        catch (e: any) {
            console.log(e);
        }
    }
    }

    function ViewAssignmentModalView(props: any) {
        console.log("list",guarantorList);
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        View Loan Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block'>
                    {assignmentViewModal && !applicationAssigned ? <div>
                    <div className='row'>
                        <table className='guarantor-table'>
                            <tr>
                                <th className='text-center' colSpan={2}>Guarantor List</th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <th>Member Id</th>
                            </tr>
                            {
                                guarantorList.map((e: string)=> {
                                    let arr = e.split(" ");
                                    return <tr><td>{arr[1]?arr[1]:''} {arr[2]?arr[2]:''}</td>
                                    <td>{arr[0]?arr[0]:''}</td></tr>
                                })
                                // if(loanViewRecord && loanViewRecord['guarantor']) {

                                // }
                            }
                        </table>
                    </div><br/>
                    <h4>Loan Application not assigned to any scheme. Please Assign to view details.</h4>
                    </div>
                    : <></>
                    }
                    {assignmentViewModal && applicationAssigned ? <div>
                    <div className='row'>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['assignedAmount']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Assigned Tenure</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['assignedTenure']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Interest Rate</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['schemeId']['maxInterestRate']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Total Interest Amount</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['totalInterestAmount']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Balance Left</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['principleAmount']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme ID</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['schemeId']['schemeId']:""} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='pd-b-10'>
                                <label className="form-label">Scheme Name</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="memberId"
                                    name="memberId" disabled
                                    value={loanViewRecord?loanViewRecord['schemeId']['loanName']:""} />
                            </div>
                        </div>
                        <table>
                            <tr></tr>
                        </table>

                    </div>
                    <div className='row'>
                    <table className='guarantor-table'>
                            <tr>
                                <th className='text-center' colSpan={2}>Guarantor List</th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <th>Member Id</th>
                            </tr>
                            {
                                guarantorList.map((e: string)=> {
                                    let arr = e.split(" ");
                                    return <tr><td>{arr[1]?arr[1]:''} {arr[2]?arr[2]:''}</td>
                                    <td>{arr[0]?arr[0]:''}</td></tr>
                                })
                                // if(loanViewRecord && loanViewRecord['guarantor']) {

                                // }
                            }
                        </table>
                    </div>
                    </div>
                    : <></>
                    }
                    
                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setApplicationAssigned(false); setAssignmentViewModal(!assignmentViewModal) }}>Cancel</Button>
                    {/* <Button variant="danger" onClick={() => { deactivateRecordOnConfirm(loanDeactivateRecordId); setDeleteModal(!deleteModal); getRows(10, 0); }}>Delete</Button> */}
                </Modal.Footer>
            </Modal>
        );
    }

    function DeleteModalView(props: any) {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header className='d-block text-center'>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Are you sure want to <strong className='text-danger'>Delete</strong> the Loan Application.
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body className='d-block text-center'>
                    <p>
                        You are about to delete loan <strong>{loanDeactivateRecordId}</strong>. This process is irrevesable!
                    </p>
                </Modal.Body>
                <Modal.Footer className='d-block text-center'>
                    <Button variant="outline-secondary" onClick={() => { setDeleteModal(!deleteModal) }}>Cancel</Button>
                    <Button variant="danger" onClick={() => { deactivateRecordOnConfirm(loanDeactivateRecordId); setDeleteModal(!deleteModal); getRows(10, 0); }}>Delete</Button>
                </Modal.Footer>
            </Modal>
        );
    }

    return (
        <div>
            {
                deleteModal && <DeleteModalView show={deleteModal} onHide={() => setDeleteModal(false)} />
            }
            {
                showAlert ?
                    <div className="d-flex justify-content-end my-4 phx-pagination">
                        <div>
                            <div className="alert alert-success alert-notification alert-dismissible fade show" role="alert">
                                <span>{alertMessage}</span>
                                <button aria-label="Close" className='close close-position' type='button' data-dismiss="alert" onClick={() => closeAlert()}>&times;</button>
                            </div>
                        </div>
                    </div> : <></>
            }
            {
                assignmentViewModal && <ViewAssignmentModalView show={assignmentViewModal} onHide={() => setAssignmentViewModal(false)}/>
            }
            <div className="container-fluid">
                <div className='row'>
                    <div className='col-md-3'>
                        <div className="form-body">
                            <div className="row">
                                <div className="form-holder">
                                    <div className="form-content">
                                        <div className="form-items">
                                            <form className="requires-validation">
                                                <div className="col-md-12">
                                                    <label className='form-label color-white'>Filter Type</label>
                                                    <select className="form-select"
                                                        aria-label="Default select example"
                                                        id="loanFilterType" name="loanFilterType"
                                                        onChange={handleLoanFilterType}
                                                        value={loanFilterType}>
                                                        <option value="Select" key="Select">Select</option>
                                                        <option value="Get All" key="Get All">Get All</option>
                                                        <option value="Loan Application ID" key="Loan Application ID">Loan Application ID</option>
                                                        <option value="Member ID" key="Member ID">Member ID</option>
                                                    </select>
                                                </div>
                                                {
                                                    loanFilterType == "Member ID" ?
                                                        <div className="col-md-12">
                                                            <label className='form-label color-white'>Member ID</label>
                                                            <input className="form-control my-1 fs-6"
                                                                id="memberId"
                                                                name="memberId"
                                                                autoComplete='off'
                                                                type="text"
                                                                placeholder="Member ID"
                                                                onChange={handleMemberId}
                                                                value={memberId} />
                                                        </div> : <></>
                                                }
                                                {
                                                    loanFilterType == "Loan Application ID" ?
                                                        <div className="col-md-12">
                                                            <label className='form-label color-white'>Loan Application ID</label>
                                                            <input className="form-control my-1 fs-6"
                                                                id="loanId"
                                                                name="loanId"
                                                                type="text"
                                                                autoComplete='off'
                                                                placeholder="Loan Application ID"
                                                                onChange={handleLoanId}
                                                                value={loanId} />
                                                        </div> : <></>
                                                }


                                                <div className="form-button mt-3">
                                                    <button type="button" className="btn btn-outline-light"
                                                        onClick={() => searchLoanPlan()}>Search</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {
                        rowsData ? <div className='col-md-9 border-left'>
                            <br />
                            <div className='d-flex mb-2 flex-row-reverse'>
                                <div className="btn-group px-2" role="group" aria-label="Basic outlined example">
                                    <button type="button" className="btn btn-outline-light" disabled={!hasPrevious} onClick={() => txnDataPrevious()}>Previous</button>
                                    <button type="button" disabled={true} className="btn btn-outline-light px-1"><span className="text-white px-4 fs-5 text-center"> {pageSize + 1} </span></button>
                                    <button type="button" className="btn btn-outline-light" disabled={!hasNext} onClick={() => txnDataNext()}>Next</button>
                                </div>
                                <select className="form-select records-select" onChange={(e) => { setRecordsSize(Number(e.target.value)); getRows(Number(e.target.value), 0) }} value={recordsSize} aria-label="Default select example">
                                    <option value={5}>5</option>
                                    <option value={10}>10</option>
                                    <option value={25}>25</option>
                                    <option value={50}>50</option>
                                </select>
                            </div>
                            <div className="text-white bg-white grid-view" id='gridView'>
                                <DataGrid
                                    className=''
                                    rows={rowsData as any}
                                    columns={columnsList}
                                    pageSize={numberOfRows}
                                    getRowId={(row) => row.id}
                                    hideFooter={true}
                                />
                            </div>
                        </div> : <></>
                    }

                </div>
            </div>
        </div>
    );
}
