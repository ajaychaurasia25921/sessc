import React, { useState } from 'react';
import './loan.scss';
import MainService from '../../../services/main-service';
import { LoanCreation } from './loan-creation';
import { LoanApplication } from './loan-application';
import { LoanAssignment } from './loan-assignment';
import { LoanSearch } from './loan-search';
import { LoanBookKeeping } from './loan-book-keeping';
import { LoanCalculator } from './loan-calculator';


const mainService = new MainService("");


type Guarantor = {
  introducerId: number,
  name: string,
  personalNumber: string,
  ticketNumber: string,
  section: string,
  post: string
}

export const Loan = (props: any) => {
  var [currentLoanModule, setCurrentLoanModule] = React.useState('LoanApplication')

  return (
    <div>
      <ul className="nav nav-tabs" id="myTab" role="tablist">
        <li className="nav-item" role="presentation">
          <button className="nav-link active" 
          id="loanApplication-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanApplication" 
          type="button" role="tab" 
          aria-controls="loanApplication" 
          onClick={()=> setCurrentLoanModule('LoanApplication')}>
            Loan Application
          </button>
        </li>
        <li className="nav-item" role="presentation">
          <button className="nav-link" 
          id="loanCreation-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanCreation" 
          type="button" 
          role="tab" 
          aria-controls="loanCreation" 
          onClick={()=> setCurrentLoanModule('LoanCreation')}>
            Loan Scheme
            </button>
        </li>
        <li className="nav-item" role="presentation">
          <button className="nav-link" 
          id="loanAssignment-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanAssignment" 
          type="button" 
          role="tab" 
          aria-controls="loanAssignment"
          onClick={()=> setCurrentLoanModule('LoanAssignment')}>
            Loan Assignment
            </button>
        </li>
        <li className="nav-item" role="presentation">
          <button className="nav-link" 
          id="loanSearch-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanSearch" 
          type="button" 
          role="tab" 
          aria-controls="loanSearch"
          onClick={()=> setCurrentLoanModule('LoanSearch')}>
            Loan Search
            </button>
        </li>
        <li className="nav-item" role="presentation">
          <button className="nav-link" 
          id="loanBookKeeping-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanBookKeeping" 
          type="button" 
          role="tab" 
          aria-controls="loanBookKeeping"
          onClick={()=> setCurrentLoanModule('LoanBookKeeping')}>
            Loan Posting
            </button>
        </li>
        <li className="nav-item" role="presentation">
          <button className="nav-link" 
          id="loanCalculator-tab" 
          data-bs-toggle="tab" 
          data-bs-target="#loanCalculator" 
          type="button" 
          role="tab" 
          aria-controls="loanCalculator"
          onClick={()=> setCurrentLoanModule('LoanCalculator')}>
            Loan Calculator
            </button>
        </li>
      </ul>
      <div className="tab-content" id="myTabContent">
        <div className='loan-application tab-pane fade show active'
          id="loanApplication"
          role="tabpanel"
          aria-labelledby="loanApplication-tab">
          {
            currentLoanModule === "LoanApplication" ? <LoanApplication /> : <></>
          }
        </div>
        <div className="tab-pane fade"
          id="loanCreation"
          role="tabpanel"
          aria-labelledby="loanCreation-tab">
          {
            currentLoanModule === "LoanCreation" ? <LoanCreation /> : <></>
          }
        </div>
        <div className="tab-pane fade"
          id="loanAssignment"
          role="tabpanel"
          aria-labelledby="loanAssignment-tab">
          {
            currentLoanModule === "LoanAssignment" ? <LoanAssignment /> : <></>
          }
        </div>
        <div className="tab-pane fade"
          id="loanSearch"
          role="tabpanel"
          aria-labelledby="loanSearch-tab">
          {
            currentLoanModule === "LoanSearch" ? <LoanSearch /> : <></>
          }
        </div>
        <div className="tab-pane fade"
          id="loanBookKeeping"
          role="tabpanel"
          aria-labelledby="loanBookKeeping-tab">
          {
            currentLoanModule === "LoanBookKeeping" ? <LoanBookKeeping /> : <></>
          }
        </div>
        <div className="tab-pane fade"
          id="loanCalculator"
          role="tabpanel"
          aria-labelledby="loanCalculator-tab">
          {
            currentLoanModule === "LoanCalculator" ? <LoanCalculator /> : <></>
          }
        </div>
      </div>
    </div>


  )
}