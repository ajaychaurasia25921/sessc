import React from "react";
import Icon from "react-icons-kit";
import { plus } from "react-icons-kit/entypo/plus";
import { cross } from "react-icons-kit/entypo/cross";
import { save } from "react-icons-kit/entypo/save";
import { checkCircleO } from "react-icons-kit/fa/checkCircleO";
import { chevronLeft } from "react-icons-kit/fa/chevronLeft";
import { chevronRight } from "react-icons-kit/fa/chevronRight";
import "./members.scss";
import MainService from "../../../services/main-service";
import { useFormik } from "formik";
import dateFormat from "dateformat";
import { Button, Modal } from "react-bootstrap";
import relationArr from "../../../data/relation.json";
import stateArr from "../../../data/state.json";

type Member = {
  memberId: number;
  registrationId: string;
  personalDetail: {
    personalDetailId: number;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: string;
    nationality: string;
    category: string;
    fatherOrHusbandName: string;
    contactNumber: string;
    email: string;
    staffType: string;
    qualification: string;
  };
  address: [
    {
      addressId: number;
      addressLine1: string;
      addressLine2: string | null;
      postOrCity: string;
      district: string;
      state: string;
      country: string;
      pinCode: string;
      contact: string;
      type: string;
    },
    {
      addressId: number;
      addressLine1: string;
      addressLine2: null;
      postOrCity: string;
      district: string;
      state: string;
      country: string;
      pinCode: string;
      contact: string;
      type: string;
    }
  ];
  officialDetail: {
    officialDetailId: number;
    post: string;
    section: string;
    personalNumber: string;
    ticketNumber: string;
    grossSalary: string;
    appointmentDate: string;
    introducer: [
      {
        introducerId: number;
        name: string;
        personalNumber: string;
        ticketNumber: string;
        section: string;
        post: string;
      },
      {
        introducerId: number;
        name: string;
        personalNumber: string;
        ticketNumber: string;
        section: string;
        post: string;
      }
    ];
  };
  kycDetail: {
    aadhaarCard: string;
    panCard: string;
    isAadhaarVerified: boolean;
    aadhaarStatus: string;
    isPanVerified: boolean;
    panStatus: string;
    id: number;
  };
  account: [
    {
      accountId: string;
      type: string;
      accountBalance: number;
      block: false;
      createdOn: string;
      modifiedOn: string;
      createdBy: string;
      modifiedBy: string;
      transaction: [];
    },
    {
      accountId: string;
      type: string;
      accountBalance: number;
      block: boolean;
      createdOn: string;
      modifiedOn: string;
      createdBy: string;
      modifiedBy: string;
      transaction: [
        {
          transactionId: string;
          amount: number;
          balance: number;
          mode: string;
          indicator: string;
          notes: string;
          createdOn: string;
          modifiedOn: string;
          createdBy: string;
          modifiedBy: string;
        }
      ];
    }
  ];
  nominationDetail: [
    {
      nominationId: number;
      name: string;
      address: string;
      relation: string;
    },
    {
      nominationId: number;
      name: string;
      address: string;
      relation: string;
    }
  ];
  officialSecretaryAction: string;
  officialChairmanAction: string;
  createdOn: string;
  modifiedOn: string;
  createdBy: string;
  modifiedBy: string;
  active: boolean;
};
type GetMemberImage = {
  memberIdCard: string;
  signature: string;
  memberPhoto: string;
  aadhaar: string;
  pan: string;
  addressProof: string;
  serviceProof: string;
};

export const AddMemberSection = (props: any) => {
  const mainService = new MainService("todo-list");
  const [isAddingNewMember, setIsAddingNewMember] = React.useState(false);
  var [currentForm, setCurrentForm] = React.useState("Personal Details");
  var formArr = [
    "Personal Details",
    "Address Details",
    "Official Details",
    "KYC Details",
    "Nomination Details",
    "Opening Deposit",
  ];
  var [next, setNext] = React.useState(formArr[1]);
  var [previous, setPrevious] = React.useState("");
  var [sameAddress, setSameAddress] = React.useState(false);
  var [reload, setReload] = React.useState(false);
  var [memberList, setMemberList] = React.useState(Array<Member>());
  var [currentId, setCurrentId] = React.useState(0);
  var [currentDeletingEmployee, setCurrentDeletingEmployee] =
    React.useState<Member | null>();
  const [modalShow, setModalShow] = React.useState(false);
  const [deleteModal, setDeleteModal] = React.useState(false);
  const [memberImages, setMemberImages] = React.useState<GetMemberImage>();
  const [currentUserForEdit, setCurrentUserForEdit] = React.useState<Member>();
  var [pageSize, setPageSize] = React.useState(0);
  var [recordsSize, setRecordsSize] = React.useState(10);
  var [totalElement, setTotalElement] = React.useState(0);
  var [isLoading, setIsLoading] = React.useState(false);
  var [hasNext, setHasNext] = React.useState(false);
  var [hasPrevious, setHasPrevious] = React.useState(false);
  React.useEffect(() => {
    getMembersData(0, 10);
    console.log(relationArr);
  }, []);
  const nextBtn = () => {
    switch (currentForm) {
      case formArr[0]:
        setCurrentForm(formArr[1]);
        setNext(formArr[2]);
        setPrevious(formArr[0]);
        break;
      case formArr[1]:
        setCurrentForm(formArr[2]);
        setNext(formArr[3]);
        setPrevious(formArr[1]);
        break;
      case formArr[2]:
        setCurrentForm(formArr[3]);
        setNext(formArr[4]);
        setPrevious(formArr[2]);
        break;
      case formArr[3]:
        setCurrentForm(formArr[4]);
        setNext(formArr[5]);
        setPrevious(formArr[3]);
        break;
      case formArr[4]:
        setCurrentForm(formArr[5]);
        setNext("");
        setPrevious(formArr[4]);
        break;
      default:
        console.log("something wrong");
        break;
    }
  };

  const previousBtn = () => {
    switch (currentForm) {
      case formArr[1]:
        setPrevious("");
        setNext(formArr[1]);
        setCurrentForm(formArr[0]);
        break;
      case formArr[2]:
        setPrevious(formArr[0]);
        setNext(formArr[2]);
        setCurrentForm(formArr[1]);
        break;
      case formArr[3]:
        setPrevious(formArr[1]);
        setNext(formArr[3]);
        setCurrentForm(formArr[2]);
        break;
      case formArr[4]:
        setPrevious(formArr[2]);
        setNext(formArr[4]);
        setCurrentForm(formArr[3]);
        break;
      case formArr[5]:
        setPrevious(formArr[3]);
        setNext(formArr[5]);
        setCurrentForm(formArr[4]);
        break;

      default:
        console.log("something wrong");
        break;
    }
  };

  const personalDetails = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      gender: "",
      nationality: "",
      category: "",
      fatherOrHusbandName: "",
      contactNumber: "",
      email: "",
      staffType: "",
      qualification: "",
    },
    onSubmit: async (values: any) => {
      console.log(values);
    },
  });
  const addressDetails = useFormik({
    initialValues: {
      permanent: {
        addressLine1: "",
        postOrCity: "",
        district: "",
        state: "",
        country: "",
        pinCode: "",
        contact: "",
        type: "Permanent",
      },
      mailing: {
        addressLine1: "",
        postOrCity: "",
        district: "",
        state: "",
        country: "",
        pinCode: "",
        contact: "",
        type: "Mailing",
      },
    },
    onSubmit: async (values: any) => {
      console.log(values);
    },
  });

  function setSameAddressValue() {
    setSameAddress(!sameAddress);
    if (!sameAddress) {
      addressDetails.values.permanent.addressLine1 =
        addressDetails.values.mailing.addressLine1;
      addressDetails.values.permanent.postOrCity =
        addressDetails.values.mailing.postOrCity;
      addressDetails.values.permanent.district =
        addressDetails.values.mailing.district;
      addressDetails.values.permanent.state =
        addressDetails.values.mailing.state;
      addressDetails.values.permanent.country =
        addressDetails.values.mailing.country;
      addressDetails.values.permanent.pinCode =
        addressDetails.values.mailing.pinCode;
      addressDetails.values.permanent.contact =
        addressDetails.values.mailing.contact;
    } else {
      addressDetails.values.permanent.addressLine1 = "";
      addressDetails.values.permanent.postOrCity = "";
      addressDetails.values.permanent.district = "";
      addressDetails.values.permanent.state = "";
      addressDetails.values.permanent.country = "";
      addressDetails.values.permanent.pinCode = "";
      addressDetails.values.permanent.contact = "";
    }
  }
  const officialDetails = useFormik({
    initialValues: {
      post: "",
      section: "",
      personalNumber: "",
      ticketNumber: "",
      grossSalary: "",
      appointmentDate: "",
      introducer: [
        {
          name: "",
          personalNumber: "",
          ticketNumber: "",
          section: "",
          post: "",
        },
        {
          name: "",
          personalNumber: "",
          ticketNumber: "",
          section: "",
          post: "",
        },
      ],
    },
    onSubmit: (values: any) => {
      console.log(values);
    },
  });
  const kycDetails = useFormik({
    initialValues: {
      aadhaarCard: "",
      panCard: "",
    },
    onSubmit: (values: any) => {
      console.log(values);
    },
  });
  const nominationDetails = useFormik({
    initialValues: [
      {
        name: "",
        address: "",
        relation: "",
      },
      {
        name: "",
        address: "",
        relation: "",
      },
    ],
    onSubmit: (values: any) => {
      console.log(values);
    },
  });
  const openBalanceAndOtherDetails = useFormik({
    initialValues: {
      openBalance: "",
      mode: "",
      createdOn: "",
    },
    onSubmit: (values: any) => {
      console.log(values);
    },
  });

  const uploadImages = useFormik({
    initialValues: {
      member_photo: undefined,
      member_signature: undefined,
      member_id_card: undefined,
      member_address_proof: undefined,
      member_service_proof: undefined,
      pan_card: undefined,
      aadhaar_card: undefined,
    },
    onSubmit: (values: any) => {
      console.log(values);
      callPatchAPI(values);
    },
  });

  function checkFormSubmition() {
    switch (currentForm) {
      case formArr[0]:
        personalDetails.handleSubmit();
        break;
      case formArr[1]:
        addressDetails.handleSubmit();
        break;
      case formArr[2]:
        officialDetails.handleSubmit();
        break;
      case formArr[3]:
        kycDetails.handleSubmit();
        break;
      case formArr[4]:
        nominationDetails.handleSubmit();
        break;
      case formArr[5]:
        openBalanceAndOtherDetails.handleSubmit();
        break;
      default:
        console.log("something wrong");
        break;
    }
  }

  function addRowOfficeFunc() {
    officialDetails.values.introducer.push({
      name: "",
      personalNumber: "",
      ticketNumber: "",
      section: "",
      post: "",
    });
    setReload(!reload);
  }

  function removeRowOfficeFromArr(index: any) {
    if (index !== 0 && index != 1) {
      officialDetails.values.introducer.splice(
        officialDetails.values.introducer.indexOf(index),
        1
      );
      setReload(!reload);
    }
  }

  function addRowNominationFunc() {
    nominationDetails.values.push({ name: "", address: "", relation: "" });
    setReload(!reload);
  }

  function removeRowNominationFromArr(index: any) {
    if (index !== 0 && index != 1) {
      nominationDetails.values.splice(
        nominationDetails.values.indexOf(index),
        1
      );
      setReload(!reload);
    }
  }

  function setIntroducers(type: string, data: string, index: number) {
    switch (type) {
      case "name":
        officialDetails.values.introducer[index].name = data;
        break;
      case "personalNumber":
        officialDetails.values.introducer[index].personalNumber = data;
        break;
      case "ticketNumber":
        officialDetails.values.introducer[index].ticketNumber = data;
        break;
      case "section":
        officialDetails.values.introducer[index].section = data;
        break;
      case "post":
        officialDetails.values.introducer[index].post = data;
        break;

      default:
        break;
    }
    setReload(!reload);
  }

  function setNomination(type: string, data: string, index: number) {
    switch (type) {
      case "name":
        nominationDetails.values[index].name = data;
        break;
      case "address":
        nominationDetails.values[index].address = data;
        break;
      case "relation":
        nominationDetails.values[index].relation = data;
        break;

      default:
        break;
    }
    setReload(!reload);
  }

  function setFile(e: any, type: string) {
    if (e.target.files[0]) {
      switch (type) {
        case "member_photo":
          uploadImages.values.member_photo = e.target.files[0];
          break;
        case "member_signature":
          uploadImages.values.member_signature = e.target.files[0];
          break;
        case "member_id_card":
          uploadImages.values.member_id_card = e.target.files[0];
          break;
        case "member_address_proof":
          uploadImages.values.member_address_proof = e.target.files[0];
          break;
        case "member_service_proof":
          uploadImages.values.member_service_proof = e.target.files[0];
          break;
        case "pan_card":
          uploadImages.values.pan_card = e.target.files[0];
          break;
        case "aadhaar_card":
          uploadImages.values.aadhaar_card = e.target.files[0];
          break;
        default:
          break;
      }
    }
  }

  function submitAll() {
    openBalanceAndOtherDetails.handleSubmit();
    sendMembersData();
  }

  const sendMembersData = async () => {
    let data = {
      personalDetail: personalDetails.values,
      memberAddress: {
        permanent: addressDetails.values.permanent,
        mailing: addressDetails.values.mailing,
      },
      officialDetail: officialDetails.values,
      kycDetail: kycDetails.values,
      nominationDetail: nominationDetails.values,
      openBalance: openBalanceAndOtherDetails.values.openBalance,
      mode: openBalanceAndOtherDetails.values.mode,
      createdOn: openBalanceAndOtherDetails.values.createdOn,
    };
    console.log(data);
    try {
      let response = await mainService.postRequest(
        "member/onboard",
        data,
        null
      );
      console.log(response);
      closing();
    } catch (e) {
      console.log(e);
    }
  };
  const getMembersData = async (pageSize: number, recordsSize: number) => {
    try {
      let response = await mainService.getRequest(
        `member?page=${pageSize}&size=${recordsSize}`,
        null,
        null
      );
      setTotalElement(response.data.totalElements);
      setHasNext(response.data.hasNext);
      setHasPrevious(response.data.hasPrevious);
      setMemberList(response.data.content);
      setIsLoading(false);
    } catch (e) {
      console.log(e);
      setIsLoading(false);
    }
  };

  const callPatchAPI = async (values: any) => {
    console.log(currentId);
    let url = `member/${currentId}/onboard`;
    console.log(url);
    let data = new FormData();
    console.log(values);
    data.append("member_photo", values.member_photo);
    data.append("member_signature", values.member_signature);
    data.append("member_id_card", values.member_id_card);
    data.append("member_address_proof", values.member_address_proof);
    data.append("member_service_proof", values.member_service_proof);
    data.append("pan_card", values.pan_card);
    data.append("aadhaar_card", values.aadhaar_card);
    try {
      let response = await mainService.patchRequest(url, data, null);
      console.log(response);
      setModalShow(!modalShow);
    } catch (e) {
      console.log(e);
    }
  };

  async function uploadDocuments(id: number) {
    setCurrentId(id);
    let url = `member/${id}/doc`;
    try {
      let response = await mainService.getRequest(url, null, null);
      setMemberImages(response.data as GetMemberImage);
      setTimeout(() => {
        setModalShow(true);
      }, 100);
    } catch (e) {
      console.log(e);
    }
  }

  function MyVerticallyCenteredModal(props: any) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        dialogClassName="upload-images-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Upload Documents
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {memberImages ? (
            <form onSubmit={uploadImages.handleSubmit}>
              <div className="row g-3">
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.memberPhoto}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Member Photo</label>
                  <input
                    className="form-control my-1"
                    id="member_photo"
                    name="member_photo"
                    type="file"
                    onChange={(e) => setFile(e, "member_photo")}
                    required
                  />
                </div>
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.memberIdCard}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Member Id Card</label>
                  <input
                    className="form-control my-1"
                    id="member_id_card"
                    name="member_id_card"
                    type="file"
                    onChange={(e) => setFile(e, "member_id_card")}
                    required
                  />
                </div>
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.serviceProof}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Member Service Proof</label>
                  <input
                    className="form-control my-1"
                    id="member_service_proof"
                    name="member_service_proof"
                    type="file"
                    onChange={(e) => setFile(e, "member_service_proof")}
                    required
                  />
                </div>
              </div>
              <div className="row g-3">
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.addressProof}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Member Address Proof</label>
                  <input
                    className="form-control my-1"
                    id="member_address_proof"
                    name="member_address_proof"
                    type="file"
                    onChange={(e) => setFile(e, "member_address_proof")}
                    required
                  />
                </div>
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.signature}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Member Signature</label>
                  <input
                    className="form-control my-1"
                    id="member_signature"
                    name="member_signature"
                    type="file"
                    onChange={(e) => setFile(e, "member_signature")}
                    required
                  />
                </div>
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.pan}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Pan Card Photo</label>
                  <input
                    className="form-control my-1"
                    id="pan_card"
                    name="pan_card"
                    type="file"
                    onChange={(e) => setFile(e, "pan_card")}
                    required
                  />
                </div>
              </div>
              <div className="row g-3">
                <div className="col-md-4">
                  <img
                    className="uploaded-images"
                    src={`data:image/png;image/jpg;image/jpeg;base64,${memberImages.aadhaar}`}
                    alt=""
                    srcSet=""
                  />
                  <label htmlFor="title">Aadhar Card Photo</label>
                  <input
                    className="form-control my-1"
                    id="aadhaar_card"
                    name="aadhaar_card"
                    type="file"
                    onChange={(e) => setFile(e, "aadhaar_card")}
                    required
                  />
                </div>
              </div>
            </form>
          ) : (
            <></>
          )}
        </Modal.Body>
        <Modal.Footer className="d-block text-center">
          <Button onClick={() => uploadImages.handleSubmit()}>
            Upload Documents
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }

  function DeleteModalView(props: any) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header className="d-block text-center">
          <Modal.Title id="contained-modal-title-vcenter">
            Are you sure want to <strong className="text-danger">Delete</strong>{" "}
            the Employee.
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="d-block text-center">
          <p>
            You are about to delete{" "}
            <strong>
              {currentDeletingEmployee!.personalDetail.firstName.toUpperCase()}{" "}
              {currentDeletingEmployee!.personalDetail.lastName.toUpperCase()} (
              {currentDeletingEmployee!.memberId})
            </strong>
            . This process is irrevesable!
          </p>
        </Modal.Body>
        <Modal.Footer className="d-block text-center">
          <Button
            variant="outline-secondary"
            onClick={() => {
              setDeleteModal(!deleteModal);
              setCurrentDeletingEmployee(null);
            }}
          >
            Cancel
          </Button>
          <Button variant="danger" onClick={() => deactivateUser()}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }

  function closing() {
    setIsAddingNewMember(!isAddingNewMember);
    personalDetails.resetForm();
    addressDetails.resetForm();
    officialDetails.resetForm();
    kycDetails.resetForm();
    nominationDetails.resetForm();
    openBalanceAndOtherDetails.resetForm();
    setCurrentForm(formArr[0]);
    getMembersData(pageSize, recordsSize);
  }

  async function viewAndEdit(id: any) {
    console.log(id);
    let url = `member/${id}`;
    try {
      let response = await mainService.getRequest(url, null, null);
      setCurrentUserForEdit(response.data);
      setIsAddingNewMember(false);
      props.setIsEditing(true);
      props.setEditUserData(response.data);
    } catch (e) {
      console.log(e);
    }
  }

  function setDeactivateUser(user: any) {
    setCurrentDeletingEmployee(user);
    setDeleteModal(!deleteModal);
  }

  async function deactivateUser() {
    console.log(currentDeletingEmployee);
    let url = `member/deactivate/${currentDeletingEmployee?.memberId}`;
    console.log(url);
    try {
      let response = await mainService.patchRequest(url, null, null);
      console.log(response);
      setDeleteModal(!deleteModal);
      getMembersData(pageSize, recordsSize);
    } catch (e) {
      console.log(e);
    }
  }

  function toTitleCase(str: string) {
    return str.replace(/\w\S*/g, function (txt: string) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
  }

  function memberDataNext() {
    setPageSize(pageSize + 1);
    console.log(pageSize);
    getMembersData(pageSize + 1, recordsSize);
    setIsLoading(true);
  }

  function memberDataPrevious() {
    setPageSize(pageSize - 1);
    console.log(pageSize);
    getMembersData(pageSize - 1, recordsSize);
    setIsLoading(true);
  }

  return (
    <div>
      {!isAddingNewMember ? (
        <div className="member-list-view">
          <div className="row heading-section">
            <div className="col-md-5">
              <h3 className="heading m-0 lh-base">Members</h3>
            </div>
            <div className="col-md-7">
              <div className="d-flex flex-row-reverse">
                <button
                  className="btn btn-light add-member-btn rounded rounded-3"
                  onClick={() => {
                    setIsAddingNewMember(!isAddingNewMember);
                  }}
                >
                  <Icon icon={plus} size="25" />
                  Add New Members
                </button>

                <div
                  className="btn-group px-2"
                  role="group"
                  aria-label="Basic outlined example"
                >
                  <button
                    type="button"
                    className="btn btn-outline-light"
                    disabled={!hasPrevious}
                    onClick={() => memberDataPrevious()}
                  >
                    Previous
                  </button>
                  <button
                    type="button"
                    disabled={true}
                    className="btn btn-outline-light px-1"
                  >
                    <span className="text-white px-4 fs-5 text-center">
                      {" "}
                      {pageSize + 1}{" "}
                    </span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline-light"
                    disabled={!hasNext}
                    onClick={() => memberDataNext()}
                  >
                    Next
                  </button>
                </div>
                <select
                  className="form-select records-select"
                  onChange={(e) => {
                    setRecordsSize(Number(e.target.value));
                    getMembersData(0, Number(e.target.value));
                  }}
                  value={recordsSize}
                  aria-label="Default select example"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                </select>
              </div>
            </div>
          </div>
          <div className="table-view">
            <div className="table-view-head">
              <table className="table head mb-0">
                <thead className="table-header-view">
                  <tr>
                    <th className="col-2">Registration ID</th>
                    <th className="col-2">Member ID</th>
                    <th className="col-2">Member Name</th>
                    <th className="col-2">Created By</th>
                    <th className="col-2">Created Date</th>
                    <th className="col-2">
                      <div className="row">
                        <div className="col-4">KYC</div>
                        <div className="col-8">Option</div>
                      </div>
                    </th>
                  </tr>
                </thead>
              </table>
            </div>
            <div className="table-view-body">
              <table className="table body mb-0 position-relative">
                {memberList && memberList.length !== 0 ? (
                  <tbody className="table-body-view">
                    {memberList.map((data, index) => {
                      return (
                        <tr key={index}>
                          <td className="col-2">{data.registrationId}</td>
                          <td className="col-2">{data.memberId}</td>
                          <td className="col-2">
                            {toTitleCase(data.personalDetail.firstName)}{" "}
                            {toTitleCase(data.personalDetail.lastName)}
                          </td>
                          <td className="col-2">{data.createdBy}</td>
                          <td className="col-2">
                            {dateFormat(data.createdOn, "mmm d, yyyy")}
                          </td>
                          <td className="col-2">
                            <div className="row">
                              <div className="col-4">
                                <img src="/assets/red-cross.svg" alt="" />
                              </div>
                              <div className="col-8">
                                <div className="d-flex">
                                  <button
                                    className="btn p-0"
                                    onClick={() => {
                                      viewAndEdit(data.memberId);
                                    }}
                                  >
                                    <img
                                      className="mx-1"
                                      src="/assets/view.svg"
                                      alt=""
                                    />
                                  </button>
                                  <button
                                    className="btn p-0"
                                    data-bs-toggle="modal"
                                    data-bs-target="#memberDocModal"
                                    onClick={() => {
                                      uploadDocuments(data.memberId);
                                    }}
                                  >
                                    <img
                                      className="mx-1"
                                      src="/assets/upload-images.svg"
                                      alt=""
                                    />
                                  </button>
                                  <button
                                    className="btn p-0"
                                    onClick={() => setDeactivateUser(data)}
                                  >
                                    <img
                                      className="mx-1"
                                      src="/assets/remove.svg"
                                      alt=""
                                    />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                ) : (
                  <tbody>
                    <tr>
                      <td className="text-center">No Data Found</td>
                    </tr>
                  </tbody>
                )}
              </table>
            </div>
          </div>
          {/* <!-- Modal --> */}
          {modalShow ? (
            <MyVerticallyCenteredModal
              show={modalShow}
              onHide={() => setModalShow(false)}
            />
          ) : (
            <></>
          )}
          {deleteModal ? (
            <DeleteModalView
              show={deleteModal}
              onHide={() => setDeleteModal(false)}
            />
          ) : (
            <></>
          )}
        </div>
      ) : (
        <div className="adding-new-member-view">
          <div className="row heading-section">
            <div className="col-md-6">
              <h3 className="heading m-0 lh-base">Members</h3>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-row-reverse">
                <button
                  className="btn btn-outline-light  rounded rounded-3 ms-3"
                  onClick={() => {
                    closing();
                  }}
                >
                  <Icon icon={cross} size="25" />
                  <span className="ps-1">Close</span>
                </button>
                {currentForm === "Opening Deposit" ? (
                  <button
                    className="btn btn-outline-light  rounded rounded-3 ms-3"
                    type="submit"
                    onClick={() => {
                      submitAll();
                    }}
                  >
                    <Icon icon={save} size="25" />
                    <span className="ps-2">Save</span>
                  </button>
                ) : (
                  <></>
                )}
              </div>
            </div>
          </div>
          <div className="form-section">
            <div className="row">
              <div className="col-2 form-status-view">
                <ul className="form-status-list">
                  <li
                    className={
                      currentForm === formArr[0]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    {formArr.indexOf(currentForm) >
                    formArr.indexOf(formArr[0]) ? (
                      <Icon className="icon" icon={checkCircleO} size={25} />
                    ) : (
                      <></>
                    )}
                    Personal Details
                  </li>
                  <li
                    className={
                      currentForm === formArr[1]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    {formArr.indexOf(currentForm) >
                    formArr.indexOf(formArr[1]) ? (
                      <Icon className="icon" icon={checkCircleO} size={25} />
                    ) : (
                      <></>
                    )}
                    Address Details
                  </li>
                  <li
                    className={
                      currentForm === formArr[2]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    {formArr.indexOf(currentForm) >
                    formArr.indexOf(formArr[2]) ? (
                      <Icon className="icon" icon={checkCircleO} size={25} />
                    ) : (
                      <></>
                    )}
                    Official Details
                  </li>
                  <li
                    className={
                      currentForm === formArr[3]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    {formArr.indexOf(currentForm) >
                    formArr.indexOf(formArr[3]) ? (
                      <Icon className="icon" icon={checkCircleO} size={25} />
                    ) : (
                      <></>
                    )}
                    KYC Details
                  </li>
                  <li
                    className={
                      currentForm === formArr[4]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    {formArr.indexOf(currentForm) >
                    formArr.indexOf(formArr[4]) ? (
                      <Icon className="icon" icon={checkCircleO} size={25} />
                    ) : (
                      <></>
                    )}
                    Nomination Details
                  </li>
                  <li
                    className={
                      currentForm === formArr[5]
                        ? "list-items active"
                        : "list-items"
                    }
                  >
                    Opening Deposit{" "}
                  </li>
                </ul>
              </div>

              <div className="col-10 form-detail-view">
                <div className="personal-detail-form">
                  <div className="heading-details">
                    <div className="row">
                      <div className="col-6">
                        <h5 className="mb-0">{currentForm}</h5>
                      </div>
                      <div className="col-6 text-end">
                        {previous !== "" ? (
                          <button
                            type="button"
                            className="btn mx-1 form-controller-btn"
                            onClick={() => previousBtn()}
                          >
                            <Icon
                              icon={chevronLeft}
                              size="16"
                              className="pe-2"
                            />
                            Previous
                          </button>
                        ) : (
                          <></>
                        )}
                        {next !== "" ? (
                          <button
                            type="button"
                            className="btn mx-1 form-controller-btn"
                            onClick={() => {
                              nextBtn();
                              checkFormSubmition();
                            }}
                          >
                            Next
                            <Icon
                              icon={chevronRight}
                              size="16"
                              className="ps-2"
                            />
                          </button>
                        ) : (
                          <></>
                        )}
                      </div>
                    </div>
                  </div>
                  {currentForm === formArr[0] ? (
                    <form onSubmit={personalDetails.handleSubmit}>
                      <hr />
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">First Name</label>
                          <input
                            className="form-control my-1"
                            id="firstName"
                            name="firstName"
                            type="text"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.firstName}
                            placeholder="First Name"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Last Name</label>
                          <input
                            className="form-control my-1"
                            id="lastName"
                            name="lastName"
                            type="text"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.lastName}
                            placeholder="Last Name"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">DOB</label>
                          <input
                            className="form-control my-1"
                            id="dateOfBirth"
                            name="dateOfBirth"
                            type="Date"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.dateOfBirth}
                            placeholder="Date of Birth"
                            required
                          />
                        </div>
                      </div>
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Gender</label>

                          <div
                            className="mt-2"
                            role="group"
                            aria-labelledby="my-radio-group"
                          >
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="gender"
                                onChange={personalDetails.handleChange}
                                value="Male"
                                checked={
                                  personalDetails.values.gender === "Male"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio1"
                              >
                                Male
                              </label>
                            </div>
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="gender"
                                onChange={personalDetails.handleChange}
                                value="Female"
                                checked={
                                  personalDetails.values.gender === "Female"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio2"
                              >
                                Female
                              </label>
                            </div>
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="gender"
                                onChange={personalDetails.handleChange}
                                value="Others"
                                checked={
                                  personalDetails.values.gender === "Others"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio3"
                              >
                                Other
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Categories</label>
                          <div
                            className="mt-2"
                            role="group"
                            aria-labelledby="my-radio-group"
                          >
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="category"
                                onChange={personalDetails.handleChange}
                                value="General"
                                checked={
                                  personalDetails.values.category === "General"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio1"
                              >
                                GEN
                              </label>
                            </div>
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="category"
                                onChange={personalDetails.handleChange}
                                value="ST/SC"
                                checked={
                                  personalDetails.values.category === "ST/SC"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio2"
                              >
                                ST/SC
                              </label>
                            </div>
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="category"
                                onChange={personalDetails.handleChange}
                                value="OBC"
                                checked={
                                  personalDetails.values.category === "OBC"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio3"
                              >
                                OBC
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Nationality</label>

                          <div
                            className="mt-2"
                            role="group"
                            aria-labelledby="my-radio-group"
                          >
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="nationality"
                                onChange={personalDetails.handleChange}
                                value="Indian"
                                checked={
                                  personalDetails.values.nationality ===
                                  "Indian"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio1"
                              >
                                Indian
                              </label>
                            </div>
                            <div className="form-check form-check-inline">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="nationality"
                                onChange={personalDetails.handleChange}
                                value="NRI"
                                checked={
                                  personalDetails.values.nationality === "NRI"
                                }
                              />
                              <label
                                className="form-check-label"
                                htmlFor="inlineRadio2"
                              >
                                NRI
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Father / Husband Name</label>
                          <input
                            className="form-control my-1"
                            id="fatherOrHusbandName"
                            name="fatherOrHusbandName"
                            type="text"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.fatherOrHusbandName}
                            placeholder="Father / Husband Name"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Contact No</label>
                          <input
                            className="form-control my-1"
                            id="contactNumber"
                            name="contactNumber"
                            type="text"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.contactNumber}
                            placeholder="Phone no."
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Email</label>
                          <input
                            className="form-control my-1"
                            id="email"
                            name="email"
                            type="email"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.email}
                            placeholder="Your email id"
                            required
                          />
                        </div>
                      </div>
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Staff Type</label>
                          <select
                            className="form-select"
                            id="staffType"
                            name="staffType"
                            onChange={personalDetails.handleChange}
                            required
                            defaultValue={personalDetails.values.staffType}
                          >
                            <option value="">--Select--</option>
                            <option value="IES">IES</option>
                            <option value="Staff">Staff</option>
                          </select>
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Qualification</label>
                          <input
                            className="form-control my-1"
                            id="qualification"
                            name="qualification"
                            type="text"
                            onChange={personalDetails.handleChange}
                            value={personalDetails.values.qualification}
                            placeholder="Your highest Qualification"
                            required
                          />
                        </div>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                  {currentForm === formArr[1] ? (
                    <form onSubmit={addressDetails.handleSubmit}>
                      <hr />
                      <div className="row g-3">
                        <div className="col-md-6">
                          <div className="row">
                            <div className="col-12">
                              <label htmlFor="title">Mailing Address</label>
                              <input
                                className="form-control my-1"
                                id="mailing.addressLine1"
                                name="mailing.addressLine1"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={
                                  addressDetails.values.mailing.addressLine1
                                }
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">City</label>
                              <input
                                className="form-control my-1"
                                id="mailing.postOrCity"
                                name="mailing.postOrCity"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.mailing.postOrCity}
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">District</label>
                              <input
                                className="form-control my-1"
                                id="mailing.district"
                                name="mailing.district"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.mailing.district}
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">State</label>
                              {/* <input className="form-control my-1"
                                                                    id="mailing.state"
                                                                    name="mailing.state"
                                                                    type="text"
                                                                    onChange={addressDetails.handleChange}
                                                                    value={addressDetails.values.mailing.state}

                                                                    required
                                                                /> */}
                              <select
                                className="form-select"
                                id="mailing.state"
                                name="mailing.state"
                                onChange={addressDetails.handleChange}
                                required
                                value={addressDetails.values.mailing.state}
                              >
                                <option value="">--Select--</option>
                                {stateArr.map((element) => {
                                  return (
                                    <option value={element.state}>
                                      {element.state}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Country</label>
                              <input
                                className="form-control my-1"
                                id="mailing.country"
                                name="mailing.country"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value="India"
                                disabled
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Pincode</label>
                              <input
                                className="form-control my-1"
                                id="mailing.pinCode"
                                name="mailing.pinCode"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.mailing.pinCode}
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Contact No.</label>
                              <input
                                className="form-control my-1"
                                id="mailing.contact"
                                name="mailing.contact"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.mailing.contact}
                                required
                              />
                            </div>
                            <div className="col-12">
                              <input
                                type="checkbox"
                                name="sameAddress"
                                onChange={() => setSameAddressValue()}
                              />
                              <label
                                className="form-check-label ps-2"
                                htmlFor="inlineRadio1"
                              >
                                Keep Mailing Address as Permanent Address
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="row">
                            <div className="col-12">
                              <label htmlFor="title">Permanent Address</label>
                              <input
                                className="form-control my-1"
                                id="permanent.addressLine1"
                                name="permanent.addressLine1"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={
                                  addressDetails.values.permanent.addressLine1
                                }
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">City</label>
                              <input
                                className="form-control my-1"
                                id="permanent.postOrCity"
                                name="permanent.postOrCity"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={
                                  addressDetails.values.permanent.postOrCity
                                }
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">District</label>
                              <input
                                className="form-control my-1"
                                id="permanent.district"
                                name="permanent.district"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.permanent.district}
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">State</label>
                              {/* <input className="form-control my-1"
                                                                    id="permanent.state"
                                                                    name="permanent.state"
                                                                    type="text"
                                                                    onChange={addressDetails.handleChange}
                                                                    value={addressDetails.values.permanent.state}

                                                                    required
                                                                /> */}
                              <select
                                className="form-select"
                                id="mailing.state"
                                name="mailing.state"
                                onChange={addressDetails.handleChange}
                                required
                                value={addressDetails.values.permanent.state}
                              >
                                <option value="">--Select--</option>
                                {stateArr.map((element) => {
                                  return (
                                    <option value={element.state}>
                                      {element.state}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Country</label>
                              <input
                                className="form-control my-1"
                                id="permanent.country"
                                name="permanent.country"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value="India"
                                disabled
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Pincode</label>
                              <input
                                className="form-control my-1"
                                id="permanent.pinCode"
                                name="permanent.pinCode"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.permanent.pinCode}
                                required
                              />
                            </div>
                            <div className="col-6">
                              <label htmlFor="title">Contact No.</label>
                              <input
                                className="form-control my-1"
                                id="permanent.contact"
                                name="permanent.contact"
                                type="text"
                                onChange={addressDetails.handleChange}
                                value={addressDetails.values.permanent.contact}
                                required
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                  {currentForm === formArr[2] ? (
                    <form onSubmit={officialDetails.handleSubmit}>
                      <hr />
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Post</label>
                          <input
                            className="form-control my-1"
                            id="post"
                            name="post"
                            type="text"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.post}
                            placeholder="post"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Section</label>
                          <input
                            className="form-control my-1"
                            id="section"
                            name="section"
                            type="text"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.section}
                            placeholder="section"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Personal Number</label>
                          <input
                            className="form-control my-1"
                            id="personalNumber"
                            name="personalNumber"
                            type="text"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.personalNumber}
                            placeholder="Phone no."
                            required
                          />
                        </div>
                      </div>
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Ticket Number</label>
                          <input
                            className="form-control my-1"
                            id="ticketNumber"
                            name="ticketNumber"
                            type="text"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.ticketNumber}
                            placeholder="Ticket Number"
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Gross Salary</label>
                          <input
                            className="form-control my-1"
                            id="grossSalary"
                            name="grossSalary"
                            type="text"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.grossSalary}
                            placeholder="Gross Salary"
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Appointment Date</label>
                          <input
                            className="form-control my-1"
                            id="appointmentDate"
                            name="appointmentDate"
                            type="Date"
                            onChange={officialDetails.handleChange}
                            value={officialDetails.values.appointmentDate}
                            required
                          />
                        </div>
                      </div>

                      <div className="row">
                        <h4 className="mb-0">Introducer</h4>
                        {officialDetails.values.introducer.map(
                          (values, index) => {
                            return (
                              <div className="col-12" key={index}>
                                <div className="row g-3">
                                  <div className="col-md-4">
                                    <label htmlFor="title">Name</label>
                                    <input
                                      className="form-control my-1"
                                      id="name"
                                      name="name"
                                      type="text"
                                      onChange={(e) => {
                                        setIntroducers(
                                          "name",
                                          e.target.value,
                                          index
                                        );
                                      }}
                                      value={values.name}
                                      placeholder="Name"
                                      required
                                    />
                                  </div>
                                  <div className="col-md-4">
                                    <label htmlFor="title">
                                      Personal Number
                                    </label>
                                    <input
                                      className="form-control my-1"
                                      id="personalNumber"
                                      name="personalNumber"
                                      type="text"
                                      onChange={(e) => {
                                        setIntroducers(
                                          "personalNumber",
                                          e.target.value,
                                          index
                                        );
                                      }}
                                      value={values.personalNumber}
                                      placeholder="Personal Number"
                                      required
                                    />
                                  </div>
                                  <div className="col-md-4">
                                    <label htmlFor="title">Ticket Number</label>
                                    <input
                                      className="form-control my-1"
                                      id="ticketNumber"
                                      name="ticketNumber"
                                      type="text"
                                      onChange={(e) => {
                                        setIntroducers(
                                          "ticketNumber",
                                          e.target.value,
                                          index
                                        );
                                      }}
                                      value={values.ticketNumber}
                                      placeholder="Ticket Number"
                                      required
                                    />
                                  </div>
                                  <div className="col-md-4">
                                    <label htmlFor="title">Section</label>
                                    <input
                                      className="form-control my-1"
                                      id="section"
                                      name="section"
                                      type="text"
                                      onChange={(e) => {
                                        setIntroducers(
                                          "section",
                                          e.target.value,
                                          index
                                        );
                                      }}
                                      value={values.section}
                                      placeholder="Section"
                                      required
                                    />
                                  </div>
                                  <div className="col-md-4">
                                    <label htmlFor="title">Post</label>
                                    <input
                                      className="form-control my-1"
                                      id="post"
                                      name="post"
                                      type="text"
                                      onChange={(e) => {
                                        setIntroducers(
                                          "post",
                                          e.target.value,
                                          index
                                        );
                                      }}
                                      value={values.post}
                                      placeholder="post"
                                      required
                                    />
                                  </div>
                                  <div className="col-md-4">
                                    <div>&nbsp;</div>
                                    {index !== 0 && index !== 1 ? (
                                      <a
                                        className="btn btn-main"
                                        onClick={() =>
                                          removeRowOfficeFromArr(index)
                                        }
                                      >
                                        Delete
                                      </a>
                                    ) : (
                                      <></>
                                    )}
                                  </div>
                                </div>
                                <hr />
                              </div>
                            );
                          }
                        )}

                        <div className="add-more-btn text-center">
                          <a
                            className="btn btn-main"
                            onClick={() => addRowOfficeFunc()}
                          >
                            Add More
                          </a>
                        </div>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                  {currentForm === formArr[3] ? (
                    <form onSubmit={kycDetails.handleSubmit}>
                      <hr />
                      <div className="row g-3">
                        <div className="col-md-6">
                          <label htmlFor="title">Aadhaar Card Number</label>
                          <input
                            className="form-control my-1"
                            id="aadhaarCard"
                            name="aadhaarCard"
                            type="text"
                            onChange={kycDetails.handleChange}
                            value={kycDetails.values.aadhaarCard}
                            placeholder="aadhaarCard Number"
                            pattern="^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$"
                            required
                          />
                        </div>
                        <div className="col-md-6">
                          <label htmlFor="title">Pan Card Number</label>
                          <input
                            className="form-control my-1"
                            id="panCard"
                            name="panCard"
                            type="text"
                            onChange={kycDetails.handleChange}
                            value={kycDetails.values.panCard}
                            placeholder="PAN Card Number"
                            pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}"
                            required
                          />
                        </div>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                  {currentForm === formArr[4] ? (
                    <form>
                      <hr />
                      {nominationDetails.values.map((value, index) => {
                        return (
                          <div className="col-12" key={index}>
                            <div className="row g-3">
                              <div className="col-md-6">
                                <label htmlFor="title">Name</label>
                                <input
                                  className="form-control my-1"
                                  id={`name${index}`}
                                  name={`name${index}`}
                                  type="text"
                                  onChange={(e) => {
                                    setNomination(
                                      "name",
                                      e.target.value,
                                      index
                                    );
                                  }}
                                  value={value.name}
                                  placeholder="Name"
                                  required
                                />
                              </div>
                              <div className="col-md-6">
                                <label htmlFor="title">Address</label>
                                <input
                                  className="form-control my-1"
                                  id={`address${index}`}
                                  name={`address${index}`}
                                  type="text"
                                  onChange={(e) => {
                                    setNomination(
                                      "address",
                                      e.target.value,
                                      index
                                    );
                                  }}
                                  value={value.address}
                                  placeholder="Address"
                                  required
                                />
                              </div>
                              <div className="col-md-6">
                                <label htmlFor="title">Relation</label>
                                <select
                                  className="form-select"
                                  id={`relation${index}`}
                                  name={`relation${index}`}
                                  onChange={(e) => {
                                    setNomination(
                                      "relation",
                                      e.target.value,
                                      index
                                    );
                                  }}
                                  required
                                  value={
                                    nominationDetails.values[index].relation
                                  }
                                >
                                  <option value="">--Select--</option>
                                  {relationArr.map((element) => {
                                    return (
                                      <option value={element.relation}>
                                        {element.relation}
                                      </option>
                                    );
                                  })}
                                </select>
                              </div>
                              <div className="col-md-6">
                                <div>&nbsp;</div>
                                {index !== 0 && index !== 1 ? (
                                  <a
                                    className="btn btn-main"
                                    onClick={() =>
                                      removeRowNominationFromArr(index)
                                    }
                                  >
                                    Delete
                                  </a>
                                ) : (
                                  <></>
                                )}
                              </div>
                            </div>
                            <hr />
                          </div>
                        );
                      })}

                      <div className="add-more-btn text-center">
                        <a
                          className="btn btn-main"
                          onClick={() => addRowNominationFunc()}
                        >
                          Add More
                        </a>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                  {currentForm === formArr[5] ? (
                    <form onSubmit={openBalanceAndOtherDetails.handleSubmit}>
                      <hr />
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="title">Open Balance</label>
                          <input
                            className="form-control my-1"
                            id="openBalance"
                            name="openBalance"
                            type="number"
                            onChange={openBalanceAndOtherDetails.handleChange}
                            value={
                              openBalanceAndOtherDetails.values.openBalance
                            }
                            required
                          />
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Mode</label>
                          <select
                            className="form-select"
                            id="mode"
                            name="mode"
                            onChange={openBalanceAndOtherDetails.handleChange}
                            required
                            defaultValue={
                              openBalanceAndOtherDetails.values.mode
                            }
                          >
                            <option value="">--Select--</option>
                            <option value="Cash">Cash</option>
                            <option value="UPI">UPI</option>
                            <option value="Bank_Transfer">Bank Transfer</option>
                            <option value="Cheque">Cheque</option>
                            <option value="Cash_Transfer_Account">
                              Cash Transfer Account
                            </option>
                          </select>
                        </div>
                        <div className="col-md-4">
                          <label htmlFor="title">Entry Date</label>
                          <input
                            className="form-control my-1"
                            id="createdOn"
                            name="createdOn"
                            type="Date"
                            onChange={openBalanceAndOtherDetails.handleChange}
                            value={openBalanceAndOtherDetails.values.createdOn}
                            placeholder="Date of Birth"
                          />
                        </div>
                      </div>
                    </form>
                  ) : (
                    <></>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {isLoading ? (
        <div>
          <div className="loading-overlay">
            <div className="loader">
              <img src="/assets/rolling.svg" alt="" srcSet="" />
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}
    </div>
  );
};
