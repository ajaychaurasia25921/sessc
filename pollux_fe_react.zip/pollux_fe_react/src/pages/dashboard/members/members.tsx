import React from 'react'
import "./members.scss"
import { EditMemberSection } from './edit-member-section';
import { AddMemberSection } from './add-member-section';

const Members = (props: any) => {
    const [isEditing, setIsEditing] = React.useState(false);
    const [editUserData, setEditUserData] = React.useState();
    return (
        <div className='members'>
            
            {
                isEditing?
                <EditMemberSection setIsEditing={setIsEditing} editUserData={editUserData} />:<AddMemberSection setIsEditing={setIsEditing} setEditUserData={setEditUserData} />
            
            }
        </div>
    )
}

export default Members

