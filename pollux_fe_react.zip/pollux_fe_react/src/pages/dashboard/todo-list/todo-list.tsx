import { useFormik } from 'formik';
import React from 'react'
import { Icon } from 'react-icons-kit';
import "./todo-list.scss";
import Switch from '@mui/material/Switch';
import MainService from '../../../services/main-service';

interface todolist{
        ticketId: string,
        title: string,
        description: string,
        priority: string,
        date: Date,
        done: boolean,
        createdOn: string,
        modifiedOn: string,
        createdBy: string,
        modifiedBy: string
}

const TodoList = () => {
    const [checked, setChecked] = React.useState(false);
    var [todolistArr, setTodolistArr] = React.useState((Array<todolist>()));
    const mainService = new MainService("todo-list");
    const formik = useFormik({
        initialValues: {
            title: '',
            description: '',
            priority: '',
            date: '',
        },
        onSubmit: (values: any, {resetForm}) => {
            resetForm({values:''})
            sendTodoListData(JSON.stringify(values));
        }
    });

    React.useEffect(()=>{
        getTodoListData();
    },[])

    const getTodoListData = async () =>{
        try{
            let response = await mainService.getRequest("todo", null, null);
            setTodolistArr(response.data)
        }
        catch(e){
            console.log(e);
        }
    }
    
    const sendTodoListData = async (data:any) =>{
        try{
            let response = await mainService.postRequest("todo", data, null);
            console.log(response)
            setTodolistArr(todolistArr =>[...todolistArr,response.data])
        }
        catch(e){
            console.log(e);
        }
    }

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked(event.target.checked);
        console.log(event.target);
    };
    return (

        <div className='todo-list'>
            <div className="row heading-section">
                <div className="col-md-8"><h3 className="heading m-0 lh-base">Todo List</h3></div>
                <div className="col-md-4 d-flex flex-row-reverse">

                    <form className="d-flex" key={"todo-list-search"}>
                        <input className="form-control me-2  rounded rounded-3 search-input-width" type="search" placeholder="Search" aria-label="Search" />
                        <button className="btn btn-outline-light  rounded rounded-3" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <div className="todo-list-main-view">
                <div className="form-view">
                    <form className="row g-3 text-white" onSubmit={formik.handleSubmit}>
                        <div className="col-md-4 mt-1">
                            <input className="form-control my-1"
                                id="title"
                                name="title"
                                type="text"
                                onChange={formik.handleChange}
                                value={formik.values.title}
                                placeholder="Title"
                                required
                            />
                            <select className="form-select my-1" id="priority"
                                name="priority"
                                onChange={formik.handleChange}
                                value={formik.values.priority} required>
                                <option>--Select Priority--</option>
                                <option value={"low"}>Low</option>
                                <option value={"medium"}>Medium</option>
                                <option value={"high"}>High</option>
                            </select>
                        </div>
                        <div className="col-md-4 mt-1">
                            <textarea className="form-control" id="description"
                                name="description"
                                onChange={formik.handleChange}
                                value={formik.values.description}
                                placeholder="Short Description"
                                required
                                rows={3}
                            />

                        </div>
                        <div className="col-4 mt-1">
                        <input className="form-control" id="date"
                                name="date"
                                type="date"
                                onChange={formik.handleChange}
                                value={formik.values.date}
                                placeholder="Add Estimated Date" required/>
                                <button type="submit" className="btn btn-outline-light  rounded rounded-3 mt-2">Add List Item</button>
                        </div>
                    </form>
                    <div className='table-view'>
                        <div className='table-view-head'>
                            <table className="table head table-borderless mb-0">
                                <thead className='table-header-view'>
                                    <tr>
                                        <th className='col-1'>Ticket Id</th>
                                        <th className='col-1'>Title</th>
                                        <th className='col-2'>Short Description</th>
                                        <th className='col-1'>Priority</th>
                                        <th className='col-2'>Created Date</th>
                                        <th className='col-1'>Is Done</th>
                                        <th className='col-1'>Option</th>
                                    </tr>
                                </thead>

                            </table>
                        </div>
                        <div className="table-view-body">
                            <table className="table body mb-0">
                                <tbody className='table-body-view'>
                                    {
                                        todolistArr.map((element, index)=>{
                                        return <tr key={index}>
                                        <td className='col-1'>{element.ticketId}</td>
                                        <td className='col-1'>{element.title}</td>
                                        <td className='col-2'>{element.description}</td>
                                        <td className='col-1'>{element.priority}</td>
                                        <td className='col-2'>{element.date}</td>
                                        <td className='col-1'>
                                            <Switch
                                                size='small'
                                                checked={element.done}
                                                onChange={handleChange}
                                                inputProps={{ 'aria-label': 'controlled' }}
                                            />
                                        </td>
                                        <td className='col-1'>
                                            <div className="row">
                                                <div className="col-12"><div className="d-flex">
                                                    <button className='btn btn-primary-color border-0'><img className='mx-1' src="/assets/edit.svg" alt="" /></button>
                                                    <button className='btn btn-primary-color border-0'><img className='mx-1' src="/assets/remove.svg" alt="" /></button>
                                                </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                        })
                                    }

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>

        </div>

    )
}

export default TodoList