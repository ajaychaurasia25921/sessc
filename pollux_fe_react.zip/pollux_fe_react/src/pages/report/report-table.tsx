import { DataGrid, GridColDef } from '@mui/x-data-grid';
// import { DataGridPro } from '@mui/x-data-grid-pro';
import dateFormat from 'dateformat';
import { useFormik } from 'formik';
import React from 'react'
import Icon from 'react-icons-kit';
import { basic_notebook_pen } from 'react-icons-kit/linea/basic_notebook_pen';
import MainService from '../../services/main-service';
import "./report.scss";

// type reportDetail = {
//     memberId: number,
//     firstName: string,
//     lastName: string,
//     staffType: string,
//     personalNumber: string,
//     ticketNumber: string,
//     post: string,
//     section: string,
//     accountId: string,
//     accountType: string,
//     transactions: {
//         content: Array<transaction>,
//         pageable: {
//             sort: {
//                 empty: boolean,
//                 sorted: boolean,
//                 unsorted: boolean
//             },
//             offset: number,
//             pageNumber: number,
//             pageSize: number,
//             paged: boolean,
//             unpaged: boolean
//         },
//         last: boolean,
//         totalElements: number,
//         totalPages: number,
//         size: number,
//         number: number,
//         sort: {
//             empty: boolean,
//             sorted: boolean,
//             unsorted: boolean
//         },
//         first: boolean,
//         numberOfElements: number,
//         empty: boolean
//     },
// }

// type transaction = {
//     transactionId: string,
//     amount: number,
//     balance: number,
//     mode: string,
//     indicator: string,
//     notes: string,
//     createdOn: string,
//     modifiedOn: string,
//     createdBy: string,
//     modifiedBy: string,
//     accountId: string
// }

const columns: GridColDef[] = [
    { field: 'id', headerName: 'S.No', width: 50, resizable: true },
    { field: 'memberid', headerName: 'Member ID', width: 150, resizable: true },
    { field: 'name', headerName: 'Name', width: 150 },
    { field: 'section', headerName: 'Section', width: 150 },
    { field: 'post', headerName: 'Post', width: 150 },
    { field: 'pno', headerName: 'Personal Number', width: 150 },
    { field: 'rdBalance', headerName: 'RD Balance', width: 150 },
    { field: 'tf', headerName: 'Thrift Fund', width: 150 },
    // { field: 'pAmount', headerName: 'Principle Amount', width: 150 },
    // { field: 'interest', headerName: 'Interest', width: 150 },
    { field: 'balance', headerName: 'Loan Balance', width: 150 },
];

type userType = {
    accountId: string,
    fromDate: Date,
    toDate: Date
}

type Rows = {
    id: number,
    memberid: number,
    name: string,
    section: string,
    post: string,
    pno: string,
    rdBalance: number,
    tf: number,
    // pAmount: string,
    // interest: string,
    balance: number
}

let date = new Date();
let accountIdPlaceholder = "" as const;
let dataObj: any;
let showingReport = false;
export const ReportTable = (props: any) => {
    var [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [reload, setReload] = React.useState(false)
    var [hasPrevious, setHasPrevious] = React.useState(false);
    const [rowsData, setRows] = React.useState(Array);
    var [fromDate, setFromDate] = React.useState('');
    var [toDate, setToDate] = React.useState('');
    var [post, setPost] = React.useState('');
    var [section, setSection] = React.useState('');
    var [staffType, setStaffType] = React.useState('');
    var [memberId, setMemberId] = React.useState('');
    var [filterType, setFilterType] = React.useState('');

    var [lastUser, setLastUser] = React.useState<userType>({ accountId: accountIdPlaceholder, fromDate: date, toDate: date })
    const reportDetails = useFormik({
        initialValues: {
            accountId: "",
            fromDate: "",
            toDate: ""
        },
        onSubmit: (values: any, { resetForm }) => {
            // getRows(pageSize, recordsSize, values.accountId, values.fromDate, values.toDate)
            // resetForm();
        }
    });

    const handleFromDate = (e: any) => {
        setFromDate(e.target.value);
    }
    const handleFilterType = (e: any) => {
        setFilterType(e.target.value);
    }
    const handlePost = (e: any) => {
        setPost(e.target.value);
    }
    const handleSection = (e: any) => {
        setSection(e.target.value);
    }
    const handleStaffType = (e: any) => {
        setStaffType(e.target.value);
    }
    const handleMemberId = (e: any) => {
        setMemberId(e.target.value);
    }

    React.useEffect(() => {
        setHasNext(false);
        setHasPrevious(false);
    }, []);

    const mainService = new MainService("");

    // async function getRows(pageSize: number, recordsSize: number, id: string, fromDate: Date, toDate: Date) {
    //     console.log(pageSize, recordsSize, id, fromDate, toDate);
    //     setLastUser({ accountId: id, fromDate: fromDate, toDate: toDate })
    //     let abc: any[] = [];
    //     let url = `report/filter?page=${pageSize}&size=${recordsSize}`;
    //     let data = {
    //         "accountId": `${id}`,
    //         "fromDate": `${fromDate}`,
    //         "toDate": `${toDate}`
    //     }
    //     try {
    //         let response = await mainService.postRequest(url, data, null);
    //         console.log(response.data);
    //         dataObj = (response.data);

    //         if (dataObj.transactions.content.length != 0) {
    //             dataObj.transactions.content.forEach((element: any) => {
    //                 let finalData: Rows = {
    //                     id: element.transactionId,
    //                     memberid: element.memberid,
    //                     section: element.section,
    //                     post: element.post,
    //                     pno: element.pno,
    //                     rdMonthly: element.rdMonthly,
    //                     rdBalance: element.rdBalance,
    //                     tf: element.tf,
    //                     pAmount: element.pAmount,
    //                     interest: element.interest,
    //                     balance: element.balance
    //                 }
    //                 abc.push(finalData);
    //             });
    //         }
    //         setRows(abc);
    //         if (!dataObj.transactions.empty && dataObj.transactions.totalPages > 0) {
    //             setHasNext(true);
    //         } else {
    //             setHasNext(false);
    //         }
    //         setIsLoading(false);
    //         setReload(!reload);
    //     }
    //     catch (e: any) {
    //         console.log(e);
    //     }
    // }

    function getRowsTemp(dataObj: any) {
        let abc: any[] = [];
        try {
            let index = 1;
            if (dataObj.length != 0) {
                dataObj.forEach((element: any) => {
                    let tfBalance = 0;
                    let rdBalance = 0;
                    let loanBalance = 0;
                    for(let s of element.account) {
                        if(s.type == "Thrift_Fund") {
                            tfBalance = s.accountBalance;
                        }
                        if(s.type == "Recurring_Deposit") {
                            rdBalance = s.accountBalance;
                        }
                        if(s.type == "Loan") {
                            loanBalance = s.accountBalance;
                        }
                    }
                    let finalData: Rows = {
                        id: index,
                        memberid: element.memberId,
                        name: element.personalDetail.firstName+" "+element.personalDetail.lastName,
                        section: element.officialDetail.section,
                        post: element.officialDetail.post,
                        pno: element.officialDetail.personalNumber,
                        rdBalance: rdBalance,
                        tf: tfBalance,
                        // pAmount: element.pAmount,
                        // interest: element.interest,
                        balance: loanBalance
                    }
                    abc.push(finalData);
                    index++;
                });
            }
            console.log(abc[0].name)
            setRows(abc);
            // if (!dataObj.transactions.empty && dataObj.transactions.totalPages > 0) {
            //     setHasNext(true);
            // } else {
            //     setHasNext(false);
            // }
            // setIsLoading(false);
            // setReload(!reload);
        }
        catch (e: any) {
            console.log(e);
        }
    }


    function memberDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        // getRowsTemp(pageSize + 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function memberDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        // getRows(pageSize - 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function selectedReport(report: string) {
        showingReport = !showingReport;
        console.log(report, showingReport);
        setReload(!reload)
    }

    async function viewData() {
        if(filterType == "memberwise") {
            try {
                let url = `member/${memberId}`;
                let data = await mainService.getRequest(url, null, null);
                console.log(data)
                let newarr = [];
                newarr.push(data.data)
                getRowsTemp(newarr);
            } catch (e: any) {
                console.log(e)
            }
        }
    }

    function resetData() {

    }

    return (
        <div className='container-fluid'>
            <div className='row'>
                <div className="col-sm-2">
                    <label className='form-label color-white'>Filter Type</label>
                    <select className="form-select"
                        aria-label="Default select example"
                        id="RDFilterType" name="RDFilterType"
                        onChange={handleFilterType}
                        value={filterType}>
                        <option value="Select" key="Select">Select</option>
                        <option value="memberwise" key="Member-Wise">Member-Wise</option>
                        <option value="groupwise" key="Group-Wise">Group-Wise</option>
                    </select>
                </div>
                {filterType == "memberwise" ?
                    <div className="col-sm-2">
                        <div className='pd-b-10'>
                            <label className="form-label color-white">Member ID</label>
                            <input type="text" autoComplete='off'
                                className="form-control"
                                id="memberId"
                                name="memberId"
                                placeholder="Member ID"
                                onChange={handleMemberId}
                                value={memberId} />
                        </div>
                    </div> : <></>
                }
                {
                    filterType == "groupwise" ?
                        <div className='col-sm-2'>
                            <div className='pd-b-10'>
                                <label className="form-label color-white">Start Date</label>
                                <input className="form-control my-1"
                                    id="fromDate"
                                    name="fromDate"
                                    type="Date"
                                    autoComplete='off'
                                    onChange={handleFromDate}
                                    value={fromDate}
                                    placeholder="From"
                                />
                            </div></div> : <></>}
                {
                    filterType == "groupwise" ?
                        <div className="col-sm-2">
                            <div className='pd-b-10'>
                                <label className="form-label color-white">Section</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="section"
                                    name="section"
                                    placeholder="Section"
                                    onChange={handleSection}
                                    value={section} />
                            </div>
                        </div> : <></>}
                {
                    filterType == "groupwise" ?
                        <div className="col-sm-2">
                            <div className='pd-b-10'>
                                <label className="form-label color-white">Post</label>
                                <input type="text" autoComplete='off'
                                    className="form-control"
                                    id="post"
                                    name="post"
                                    placeholder="Post"
                                    onChange={handlePost}
                                    value={post} />
                            </div>
                        </div> : <></>}
                {
                    filterType == "groupwise" ?
                        <div className="col-sm-2">
                            <label htmlFor="title" className='color-white'>Staff Type</label>
                            <select className="form-select" id="staffType" value={staffType}
                                name="staffType" onChange={handleStaffType}>
                                <option value="">--Select--</option>
                                <option value="IES">IES</option>
                                <option value="Staff">Staff</option>
                            </select>
                        </div>
                        : <></>
                }
                <div className="col-sm-1">
                    <button type="button" className="btn btn-outline-light self-align-btn"
                        onClick={() => viewData()}>View</button>
                </div>
                <div className="col-sm-1">
                    <button type="button" className="btn btn-outline-light self-align-btn"
                        onClick={() => resetData()}>Reset</button>
                </div>
            </div>
            {
                rowsData ? 
                <div className='row'>
                <div className='col-sm-12'>
                    <div className="text-white bg-white grid-view" id='gridViewRD'>
                        <DataGrid
                            className=''
                            rows={rowsData as any}
                            columns={columns}
                            // pageSize={pageSize}
                            getRowId={(row) => row.id}
                            hideFooter={true}
                        />
                    </div>
                </div>
            </div>:<></>
            }

        </div>
    )
}
