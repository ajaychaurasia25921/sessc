import { DataGrid, GridColDef } from '@mui/x-data-grid';
import dateFormat from 'dateformat';
import { useFormik } from 'formik';
import React from 'react'
import Icon from 'react-icons-kit';
import {basic_notebook_pen} from 'react-icons-kit/linea/basic_notebook_pen';
import MainService from '../../services/main-service';
import { ReportTable } from './report-table';
import "./report.scss";

type reportDetail = {
    memberId: number,
    firstName: string,
    lastName: string,
    staffType: string,
    personalNumber: string,
    ticketNumber: string,
    post: string,
    section: string,
    accountId: string,
    accountType: string,
    transactions: {
        content: Array<transaction>,
        pageable: {
            sort: {
                empty: boolean,
                sorted: boolean,
                unsorted: boolean
            },
            offset: number,
            pageNumber: number,
            pageSize: number,
            paged: boolean,
            unpaged: boolean
        },
        last: boolean,
        totalElements: number,
        totalPages: number,
        size: number,
        number: number,
        sort: {
            empty: boolean,
            sorted: boolean,
            unsorted: boolean
        },
        first: boolean,
        numberOfElements: number,
        empty: boolean
    },
    memberPhoto: string,
    memberPhotoExt: string,
    signature: string,
    signatureExt: string
}

type transaction = {
    transactionId: string,
    amount: number,
    balance: number,
    mode: string,
    indicator: string,
    notes: string,
    createdOn: string,
    modifiedOn: string,
    createdBy: string,
    modifiedBy: string,
    accountId: string
}

const columns: GridColDef[] = [
    { field: 'id', headerName: 'Txn Id', width: 110 },
    { field: 'accountId', headerName: 'Account Id', width: 150 },
    { field: 'amount', headerName: 'Amount', width: 150 },
    { field: 'balance', headerName: 'Balance', width: 150 },
    { field: 'mode', headerName: 'Mode', width: 150 },
    { field: 'indicator', headerName: 'DR | CR.', width: 150 },
    { field: 'notes', headerName: 'Notes', width: 150 },
    { field: 'createdOn', headerName: 'Created On', width: 150 },
    { field: 'createdBy', headerName: 'Created By', width: 150 },

];

type userType = {
    accountId: string,
    fromDate: Date,
    toDate: Date
}

type Rows = { id: string, amount: number, balance: number, mode: string, indicator: string, notes: string, createdOn: string, createdBy: string, accountId: string }

let date = new Date();
let accountIdPlaceholder = "" as const;
let dataObj: reportDetail;
let showingReport = false;
export const Report = (props: any) => {
    var [pageSize, setPageSize] = React.useState(0);
    var [recordsSize, setRecordsSize] = React.useState(10);
    var [totalElement, setTotalElement] = React.useState(0);
    var [isLoading, setIsLoading] = React.useState(false);
    var [hasNext, setHasNext] = React.useState(false);
    var [reload, setReload] = React.useState(false)
    var [hasPrevious, setHasPrevious] = React.useState(false);
    const [rowsData, setRows] = React.useState(Array);
    var [lastUser, setLastUser] = React.useState<userType>({ accountId: accountIdPlaceholder, fromDate: date, toDate: date })
    const reportDetails = useFormik({
        initialValues: {
            accountId: "",
            fromDate: "",
            toDate: ""
        },
        onSubmit: (values: any, { resetForm }) => {
            getRows(pageSize, recordsSize, values.accountId, values.fromDate, values.toDate)
            // resetForm();
        }
    });

    React.useEffect(() => {
        props.headerFunc(true);
        props.footerFunc(true);
        setHasNext(false);
        setHasPrevious(false);
    }, []);

    const mainService = new MainService("");
    async function getRows(pageSize: number, recordsSize: number, id: string, fromDate: Date, toDate: Date) {
        console.log(pageSize, recordsSize, id, fromDate, toDate);
        setLastUser({ accountId: id, fromDate: fromDate, toDate: toDate })
        let abc: any[] = [];
        let url = `report/filter?page=${pageSize}&size=${recordsSize}`;
        let data = {
            "accountId": `${id}`,
            "fromDate": `${fromDate}`,
            "toDate": `${toDate}`
        }
        try {
            let response = await mainService.postRequest(url, data, null);
            console.log(response.data);
            dataObj = (response.data as reportDetail);

            if (dataObj.transactions.content.length != 0) {
                dataObj.transactions.content.forEach(element => {
                    let finalData: Rows = {
                        id: element.transactionId,
                        amount: element.amount,
                        balance: element.balance,
                        mode: element.mode,
                        indicator: element.indicator,
                        notes: element.notes,
                        createdOn: dateFormat(element.createdOn, "mmm d, yyyy HH:MM"),
                        createdBy: element.createdBy,
                        accountId: element.accountId
                    }
                    abc.push(finalData);
                });
            }
            setRows(abc);
            if (!dataObj.transactions.empty && dataObj.transactions.totalPages > 0) {
                setHasNext(true);
            } else {
                setHasNext(false);
            }
            setIsLoading(false);
            setReload(!reload);
        }
        catch (e: any) {
            console.log(e);
        }
    }

    function memberDataNext() {
        setPageSize(pageSize + 1);
        console.log(pageSize)
        getRows(pageSize + 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function memberDataPrevious() {
        setPageSize(pageSize - 1);
        console.log(pageSize)
        getRows(pageSize - 1, recordsSize, lastUser.accountId, lastUser.fromDate, lastUser.toDate);
        setIsLoading(true);
    }

    function selectedReport(report: string){
        showingReport = !showingReport;
        console.log(report, showingReport);
        setReload(!reload)
    }

    return (
        <div className='report'>
            <div className='main-view'>
                <div className="row heading-section">
                    <div className="col-6">
                        <h3 className="heading m-0 lh-base">Report</h3>
                    </div>
                    <div className="col-6">

                        <div className='d-flex flex-row-reverse'>
                            <form className="row g-3" onSubmit={reportDetails.handleSubmit}>
                                {
                                    !showingReport?
                                    <div className="col-auto">
                                    <button type='button' className="btn btn-outline-light lh-1 height-30 mx-1">Export</button>
                                    <button type='button' className="btn btn-outline-light lh-1 height-30 mx-1 ">Analytics</button>
                                </div>:
                                <div className="col-auto">
                                <button type='button' className="btn btn-outline-light lh-1 height-30 mx-1" onClick={()=>{showingReport=false; setReload(!reload)}}>Close</button>
                            </div>
                                }
                                
                                
                            </form>
                        </div>
                    </div>
                </div>
                <hr className='border border-light divider' />

                {!showingReport?<div className="row">
                    <div className="col-2">
                        <div className="card">
                            <button className="btn card-body" onClick={()=>{selectedReport("Demand-List-Report")}}>
                            <Icon icon={basic_notebook_pen} size={28}></Icon>
                               <p className='mb-0'>Demand-List-Report</p>
                            </button>
                        </div>
                    </div>
                 
                </div>:<ReportTable></ReportTable>
                }
                
            </div>
            {
                isLoading ? <div>
                    <div className='loading-overlay'>
                        <div className='loader'>
                            <img src="/assets/rolling.svg" alt="" srcSet="" />
                        </div>
                    </div>
                </div> : <></>
            }
        </div>
    )
}
