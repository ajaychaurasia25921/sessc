import React from 'react'
import axios from 'axios';

export class InterceptorService extends React.Component {
  constructor(prop: String) {
    super(prop);
  }

  myRequest() {
    // Add a request interceptor
    axios.interceptors.request.use((config: any) => {
      // Do something before request is sent
      //console.log(config);
      return config;
    }, (error: any) => {
      // Do something with request error
      console.log(error);
      return Promise.reject(error);
    });

  }

  myResponse() {
    // Add a response interceptor
    axios.interceptors.response.use((response: any) => {
      // Any status code that lie within the range of 2xx cause this function to trigger
      // Do something with response data
      //console.log(response);
      return response;
    }, (error: any) => {
      // Any status codes that falls outside the range of 2xx cause this function to trigger
      // Do something with response error
      console.log(error.response);
      return Promise.reject(error);
    });
  }


}

export default InterceptorService