import React from 'react'
import axios from 'axios';
export class MainService extends React.Component {


    joinURL(baseUrl: String, mainUrl: String) {
        return `${baseUrl}/${mainUrl}`;
    }

    getNormalConfig(params: any | null) {
        let token = String(localStorage.getItem('access_token'));
        let normalConfig = {
            headers: {
                Authorization: 'Bearer ' + token,
                "Content-Type": "application/json"
            },
            params: params
        };
        return normalConfig;
    }
    //domain: String = "https://pollux-dev.herokuapp.com/pollux/lv-0.1"
    domain: String = "http://admin:2012/pollux/lv-0.1"
    constructor(prop: string) {
        super(prop);
    }

    getRequest(apiUrl: String, data: any | null, params: any | null): any {

        const url = this.joinURL(this.domain, apiUrl)
        return new Promise((resolve, reject) => {
            axios.get(url, this.getNormalConfig(params))
                .then(res => {
                    // console.log(res)
                    resolve(res)
                })
                .catch(err => {
                    console.log(err)
                    reject(err.response)
                })
        })

    }

    postRequest(apiUrl: String, data: any | null, params: any | null): any {
        const url = this.joinURL(this.domain, apiUrl)
        return new Promise((resolve, reject) => {
            axios.post(url, data, this.getNormalConfig(params))
                .then(res => {
                    // console.log(res)
                    resolve(res)
                })
                .catch(err => {
                    console.log(err)
                    reject(err.response)
                })
        })

    }

    patchRequest(apiUrl: String, data: any | null, params: any | null): any {
        const url = this.joinURL(this.domain, apiUrl)
        return new Promise((resolve, reject) => {
            axios.patch(url, data, this.getNormalConfig(params))
                .then(res => {
                    // console.log(res)
                    resolve(res)
                })
                .catch(err => {
                    console.log(err)
                    reject(err.response)
                })
        })

    }

    putRequest(apiUrl: String, data: any | null, params: any | null): any {
        const url = this.joinURL(this.domain, apiUrl)
        return new Promise((resolve, reject) => {
            axios.put(url, data, this.getNormalConfig(params))
                .then(res => {
                    // console.log(res)
                    resolve(res)
                })
                .catch(err => {
                    console.log(err)
                    reject(err.response)
                })
        })
    }
}
export default MainService