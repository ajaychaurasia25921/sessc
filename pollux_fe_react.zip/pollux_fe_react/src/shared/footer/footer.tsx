import "./footer.scss";
const Footer = () =>{
return(<div className="copyright">Copyright 2017. All rights reserved. Powered by <a className="text-secondary" href="https://www.segmantech.com" target="_blank">Segman Technology Private Limited</a> </div>)
}

export default Footer;