import * as React from 'react';
import "./header.scss";
import { useLocation } from 'react-router-dom';

const Header = () => {
    let location = useLocation();
    let [currentPath, setCurrentPath] = React.useState("");
    React.useEffect(() => {
       console.log(location.pathname);
       setCurrentPath(location.pathname);
      }, [location]);
    return (
        <div className="header">
             <nav className="navbar navbar-expand-lg navbar-dark pollux-header">
            <div className="container-fluid p-0">
            <a className="navbar-brand m-0 bg-white project-name" href="/">
                    Pollux <span className="color-secondary">Lv 1</span>
                </a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
               
                <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul className="navbar-nav m-0 mx-auto navigation-links">
                        <li className="nav-item">
                            <a className={currentPath === "/"? "nav-link active":"nav-link"} aria-current="page" href="/">
                                <img src="/assets/home.svg" alt="" />
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className={currentPath === "/report"? "nav-link active":"nav-link"} ria-current="page" href="report">
                                <img src="/assets/report.svg" alt="" />
                                <span>Report</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className={currentPath === "/ledger"? "nav-link active":"nav-link"} aria-current="page" href="/ledger">
                                <img src="/assets/ledger.svg" alt="" />
                                <span>Ledger</span>
                            </a>
                        </li>
                        {/* <li className="nav-item">
                            <a className="nav-link" aria-current="page" href="#">
                                <img src="/assets/planner.svg" alt="" />
                                <span>Planner</span>
                            </a>
                        </li> */}
                        {/* <li className="nav-item">
                            <a className="nav-link" aria-current="page" href="#">
                                <img src="/assets/approvals.svg" alt="" />
                                <span>Approvals</span>
                            </a>
                        </li> */}
                    </ul>
                    <div className="d-flex flex-xs-row flex-sm-row flex-sm-row flex-lg-row-reverse flex-xl-row-reverse justify-content-center action-icons pr-2">
                    <a href="#"><img src="/assets/setting.svg" alt="" /></a>
                    {/* <a href="#"><img src="/assets/bell.svg" alt="" /></a>
                    <a href="#"><img src="/assets/message.svg" alt="" /></a>
                    <a href="#"><img src="/assets/search.svg" alt="" /></a> */}
                    </div>
                </div>
            </div>
        </nav>
        </div>
    )
}

export default Header;